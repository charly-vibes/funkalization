"""Explicitly non-decisive M4 -> M3 report adapter.
Does not modify M3 design and does not certify arbitrary obligation discharge.
"""
from contracts import Verdict

def report_to_m3(kernel, *, report_id: str, obligation: str, verdict: Verdict):
    from kernel import Report
    pol = {'pass':'support','fail':'refute','unknown':'unknown'}[verdict.status]
    report=Report(report_id,obligation,pol,'experimental.m4.'+verdict.fragment,
                  'model_generated',kernel.digest,verdict.fragment,
                  f'{verdict.reason}; witness={verdict.witness!r}; finite experimental checker',False)
    kernel.report(report)
    return report
