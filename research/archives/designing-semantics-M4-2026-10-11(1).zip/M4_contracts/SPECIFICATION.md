---
title: M4 Finite Assume/Guarantee Contract Profile
created: '2026-10-11'
model: OpenAI GPT-6
status: EXPERIMENTAL REFERENCE PROFILE, NOT A GENERAL COMPOSITION THEOREM
source_commits: UNKNOWN
provenance: user-supplied M3 and M1 archive, inspected in current session
---
# M4 — Contract semantics at the M3/M1 boundary

## TL;DR
M3 records *authorized design changes* and creates obligations. M4 gives a narrow, independently executable interpretation of two of them: finite contract substitutability and observable trace refinement. Its verdicts are exact only for explicit finite closed sets and their declared alphabet/horizon; they must not be read as verification of actual software, temporal liveness, asynchronous protocols, or unbounded behavior. A bridge publishes verdicts as **non-decisive** M3 evidence, because the M3 authority/trust boundary does not register M4 as a trusted built-in evaluator.

## Glossary
- **Contract**: declared allowed environment traces (assumptions) and allowed component traces (guarantees).
- **Closed**: the supplied finite trace set is asserted exhaustive *within the declared horizon*.
- **Horizon**: maximum number of observable actions represented.
- **Trace**: finite sequence of action labels; the empty trace is `()`.
- **Refinement**: permitted concrete observations form a subset of permitted abstract observations, within a stated finite fragment.
- **Observation map**: total function on actually present concrete event labels, to abstract labels or `None` for hidden events.
- **Vacuity**: seemingly valid inclusion caused by absence of qualifying models/traces.

## Semantic domain
For a finite alphabet Σ and horizon `h`, let `Σ^{≤h}` be all traces up to `h`. A closed contract is:

`C = (Σ, h, A, G, closed)` with `A,G ⊆ Σ^{≤h}`.

`A` lists permitted *environment* traces, `G` lists permitted *component* traces. **This profile does not couple environment and component traces or encode state-dependent rely/guarantee relations.** Consequently its substitutability test is deliberately a *sufficient finite inclusion policy* and is **not** a general assume/guarantee reasoning rule for an interactive system.

### Finite substitution policy
For provider `P` and consumer expectation `C`, using identical alphabet and horizon:

`compatible(P,C) := A_C ⊆ A_P ∧ G_P ⊆ G_C`

The first clause prohibits requiring more from the environment; the second prevents additional visible provider behaviors. Both are decidable by finite set inclusion, provided the declarations are truthful and exhaustive inside their declared horizon. Otherwise verdict `unknown`. Nonempty `A` and `G` prevent one common form of vacuity. Prefix closure is **not assumed**; if intended, it is a separate obligation.

This policy is conservative and may reject implementations acceptable under conditional assumptions. It does not prove realizability or progress, nor imply `G` is achievable under `A`.

### Composition
For disjoint action alphabets `Σ_A ∩ Σ_B = ∅`, define an illustrative interleaving operator on the **guarantee** traces. Enumerate shuffles of each pair of traces, truncate by horizon, and reject the empty set. Shared events return `unknown` pending explicit synchronization policy. This is a valid combinatorial operation on the finite trace sets, **not** proof that assumptions of the two components are mutually established. Composition of full contracts remains an open obligation.

### Observation and refinement
For closed concrete finite language `T_C`, abstract guarantee language `G_A`, and total map `μ:Σ_C → Σ_A ∪ {τ}`, remove hidden (`τ`) events and map remaining events in each concrete trace.

`refines(C,A,μ) := ∀t ∈ T_C, filter_map(μ,t) ∈ G_A`.

The check yields a concrete counterexample on failure. A successful check preserves **only finite observable trace inclusion under the chosen labels and bounds**. It does not preserve divergence, fairness, deadlock freedom, timing or liveness; abstraction-map adequacy needs independent justification. In the reference implementation `T_C` is an explicitly supplied finite trace set, without an independently verified closed-world marker, and must be treated as exhaustive **only if the caller establishes closure**. Thus a `pass` from the function is conditional on that external closure assumption.

## M3 integration
- Accepted `bind(C,P)` creates `assume_guarantee:C->P`, plus interface/effects obligations.
- Running `compatible(P,C)` provides a scoped result for `assume_guarantee:C->P`, NOT interface or effects discharge.
- Accepted `decompose(P,[children])` creates composition, observation, refinement, interference obligations. `compose_interleaving` tests a guarantee-only operator; `refine_traces` checks one observable inclusion relation. Neither discharges the full M3 decomposition obligations.
- `m3_bridge.report_to_m3` inserts result in `J` with digest and provenance through M3 `report`, not `decide`. It is non-decisive by design and must not claim trusted built-in evaluator status.
- On a change to accepted design, M3's conservative digest invalidation makes historical reports stale.

## M1 connection
M1's logical semantics requires actual signatures, translations and satisfaction preservation. M4 supplies a **candidate finite theory interpretation** for a common trace signature; its finite inclusion test is a relation within that one fragment. It does not instantiate a full institution with morphisms or prove the institution satisfaction condition. Extending beyond identical alphabets/horizons requires explicitly validated translation/reduct maps. Category-theoretic language should not be used to upgrade these checks to a universal theorem.

## Validation / falsifiable claims
- V1: With identical closed finite alphabets/horizons, substitutability passes iff the two inclusions hold.
- V2: Extra provider behavior or stronger provider assumptions yields a witness.
- V3: Missing closure, mismatched signatures, empty sets and missing mappings are unknown, not pass.
- V4: Interleaving of disjoint alphabets enumerates all order-preserving shuffles of paired finite traces.
- V5: A concrete trace whose mapped observation is absent in abstract guarantees fails with a witness.
- V6: M3 report insertion does not change commitments, revision or status to a decisive built-in proof.

## Critical known limitations
1. No actual adversarial independent oracle; tests are designed by the author of the model.
2. No coinductive or reactive assume/guarantee semantics; `A` and `G` are *independent languages*.
3. No fairness, divergence, progress, quiescence, deadlock or timing interpretation.
4. No realizability/nonblocking proof; nonempty `G` is necessary but not sufficient.
5. No guarantee that supplied traces are exhaustive at the selected horizon.
6. No enforcement that alphabet mappings preserve all relevant vocabulary.
7. No Specodelic parser, pack, lint or code-checker integration, and no Wanna runtime integration.
8. No general derivation of obligations for all architectural edit types.

## Design direction
Before extending further, choose a synchronized I/O transition-system profile, give conditional assumptions their intended semantics, and establish a machine-checkable *composition rule* with a counterexample for failed compatibility. The strongest next test is a mutually circular assumption where two individually acceptable components fail together. Avoid generalizing M4's finite-inclusion success to this case.

## Sources
- User-provided `designing-semantics-M3-2026-10-11.zip`: `M3_design_semantics/SPECIFICATION.md` and `kernel.py` (commit UNKNOWN).
- User-provided `categorical-design-substrate-2026-10-11(1).zip`: `categorical-design-substrate/SEMANTICS.md` (commit UNKNOWN).
- Executed files in this bundle: `contracts.py`, `test_contracts.py`, `m3_bridge.py`, `test_bridge.py`.
