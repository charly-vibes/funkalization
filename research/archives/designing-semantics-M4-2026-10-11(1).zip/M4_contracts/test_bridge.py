import unittest, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'M3_design_semantics'))
from kernel import Kernel, Component, Edit
from contracts import Verdict
from m3_bridge import report_to_m3
class BridgeTests(unittest.TestCase):
    def test_report_no_commit(self):
        k=Kernel(); k.propose('p',Edit('add_component',(Component('A'),)))
        k.decide('p','accept',authorized=True)
        digest=k.digest; rev=k.revision
        r=report_to_m3(k,report_id='r',obligation='assume_guarantee:C->P',verdict=Verdict('pass','finite-trace-contract'))
        self.assertFalse(r.decisive_for_fragment)
        self.assertEqual((k.digest,k.revision),(digest,rev))
    def test_fail_is_refutation_report_not_mutation(self):
        k=Kernel(); digest=k.digest
        r=report_to_m3(k,report_id='fail',obligation='assume_guarantee:C->P',verdict=Verdict('fail','finite-trace-contract',('bad',)))
        self.assertEqual((r.polarity,k.digest),('refute',digest))
if __name__=='__main__': unittest.main()
