"""M4 finite trace assume-guarantee profile. Standard library only, Python >=3.10.
Bounded CLOSED traces only. No unbounded correctness or liveness claims.
"""
from dataclasses import dataclass
from itertools import product
from typing import Optional

Trace = tuple[str, ...]

@dataclass(frozen=True)
class Contract:
    name: str
    alphabet: frozenset[str]
    assumptions: frozenset[Trace]  # environment traces permitted by the contract
    guarantees: frozenset[Trace]   # component traces permitted, given assumptions
    horizon: int
    closed: bool = True

    def validate(self):
        if not self.closed: raise ValueError('open contract: exhaustive check unsupported')
        if self.horizon < 0: raise ValueError('negative horizon')
        if not self.assumptions: raise ValueError('empty assumptions: vacuous')
        if not self.guarantees: raise ValueError('empty guarantees: vacuous')
        for t in self.assumptions | self.guarantees:
            if len(t) > self.horizon or not set(t) <= self.alphabet: raise ValueError('trace outside declared finite domain')
        return self

@dataclass(frozen=True)
class Verdict:
    status: str  # pass, fail, unknown
    fragment: str
    witness: Optional[Trace] = None
    reason: str = ''


def compatible(provider: Contract, consumer: Contract) -> Verdict:
    """Sufficient check for a simple SAME-ALPHABET protocol: provider assumptions
    must be no stronger; provider allowed traces must be subset of consumer guarantees.
    No claim about true component-environment assume-guarantee composition.
    """
    if not(provider.closed and consumer.closed): return Verdict('unknown','finite-trace-contract','', 'open input')
    if provider.horizon != consumer.horizon or provider.alphabet != consumer.alphabet:
        return Verdict('unknown', 'finite-trace-contract', None, 'requires common horizon/alphabet and translation')
    try: provider.validate(); consumer.validate()
    except ValueError as e: return Verdict('unknown','finite-trace-contract',None,str(e))
    if not consumer.assumptions <= provider.assumptions:
        return Verdict('fail','finite-trace-contract',min(consumer.assumptions-provider.assumptions), 'provider needs stronger environment assumptions')
    if not provider.guarantees <= consumer.guarantees:
        return Verdict('fail','finite-trace-contract',min(provider.guarantees-consumer.guarantees), 'provider admits behavior consumer excludes')
    return Verdict('pass','finite-trace-contract',None,'finite inclusion under common vocabulary')


def all_prefixes(traces: frozenset[Trace]) -> frozenset[Trace]:
    return frozenset(t[:i] for t in traces for i in range(len(t)+1))


def interleave(a: Trace,b: Trace) -> set[Trace]:
    if not a: return {b}
    if not b: return {a}
    return {(a[0],)+x for x in interleave(a[1:],b)} | {(b[0],)+x for x in interleave(a,b[1:])}


def compose_interleaving(a: Contract,b: Contract, horizon: int) -> tuple[Optional[frozenset[Trace]], Verdict]:
    if not(a.closed and b.closed): return None,Verdict('unknown','bounded-interleave',None,'open trace sets')
    try: a.validate();b.validate()
    except ValueError as e: return None,Verdict('unknown','bounded-interleave',None,str(e))
    if a.alphabet & b.alphabet: return None,Verdict('unknown','bounded-interleave',None,'shared actions require synchronization policy')
    # This operator composes GUARANTEE traces only; environmental rely conditions need another check.
    traces=frozenset(x for p in a.guarantees for q in b.guarantees for x in interleave(p,q) if len(x)<=horizon)
    if not traces: return None,Verdict('fail','bounded-interleave',None,'no composed traces within bound')
    return traces,Verdict('pass','bounded-interleave',None,'enumerated interleavings (no assume/guarantee theorem)')


def refine_traces(concrete: frozenset[Trace], abstract: Contract, mapping: dict[str, Optional[str]], *, max_concrete_length: int) -> Verdict:
    """Exact inclusion of PROVIDED CLOSED FINITE concrete traces with an explicit
    total map. Calls with open/partial data must not be described as proof."""
    if not abstract.closed: return Verdict('unknown','finite-observable-trace',None,'abstract trace set open')
    try: abstract.validate()
    except ValueError as e: return Verdict('unknown','finite-observable-trace',None,str(e))
    if not concrete: return Verdict('unknown','finite-observable-trace',None,'no concrete witnesses: vacuity')
    if any(len(t)>max_concrete_length for t in concrete): return Verdict('unknown','finite-observable-trace',None,'concrete bound exceeded')
    actions={x for t in concrete for x in t}
    if not actions <= mapping.keys(): return Verdict('unknown','finite-observable-trace',None,'incomplete observation map')
    if any(x is not None and x not in abstract.alphabet for x in mapping.values()):
        return Verdict('unknown','finite-observable-trace',None,'map codomain mismatch')
    for t in sorted(concrete):
        observed=tuple(mapping[x] for x in t if mapping[x] is not None)
        if observed not in abstract.guarantees:
            return Verdict('fail','finite-observable-trace',t,'observed '+repr(observed)+' excluded by abstract guarantees')
    return Verdict('pass','finite-observable-trace',None,'finite trace inclusion only; not divergence/liveness/deadlock')


def finite_language(alphabet: frozenset[str],horizon:int) -> frozenset[Trace]:
    return frozenset(t for n in range(horizon+1) for t in product(sorted(alphabet), repeat=n))
