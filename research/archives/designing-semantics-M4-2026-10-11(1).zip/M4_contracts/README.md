# M4 — Finite contract semantics (experimental)

**TL;DR:** A narrow finite-language interpretation of M3's contractual and refinement obligations, explicitly separated from general assume/guarantee composition. See `SPECIFICATION.md` for definitions, scope, provenance, falsification criteria and limitations.

Run from this folder with `python -m unittest discover -v`; the M3 bridge test resolves sibling `../M3_design_semantics/kernel.py`. The zip bundle includes a vendored copy of that file under `M3_design_semantics/` to allow independent testing. No third-party Python dependencies.

Source snapshot date: 2026-10-11. Model: GPT-6. Source commits: UNKNOWN. None of the source projects is claimed to implement M4.
