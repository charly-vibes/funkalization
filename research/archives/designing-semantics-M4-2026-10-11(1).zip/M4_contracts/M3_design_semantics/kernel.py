"""M3 design-activity semantics: narrow executable reference machine.

Three semantic event constructors: propose, decide, report.
Everything else is a *domain edit*, evaluator, or derived query. Not production code.
Python >= 3.10. No dependencies outside stdlib.
"""
from __future__ import annotations
from dataclasses import dataclass, field, replace
from typing import Any
from hashlib import sha256
import json


@dataclass(frozen=True)
class Component:
    name: str
    requires: frozenset[str] = frozenset()
    provides: frozenset[str] = frozenset()
    provides_complete: bool = False
    version: int = 1


@dataclass(frozen=True)
class Edit:
    op: str
    args: tuple[Any, ...]


@dataclass(frozen=True)
class Proposal:
    id: str
    base_revision: int
    edits: tuple[Edit, ...]
    rationale: str
    status: str = 'pending'


@dataclass(frozen=True)
class Requirement:
    id: str
    scope: str
    statement: str


@dataclass
class Design:
    components: dict[str, Component] = field(default_factory=dict)
    bindings: set[tuple[str, str]] = field(default_factory=set)
    decompositions: dict[str, tuple[str, ...]] = field(default_factory=dict)
    mappings: dict[str, tuple[tuple[str, str | None], ...]] = field(default_factory=dict)
    requirements: dict[str, Requirement] = field(default_factory=dict)
    transitions: set[tuple[str, str, str, str]] = field(default_factory=set)
    exclusions: set[tuple[str, str, str]] = field(default_factory=set)
    closure: set[tuple[str, str, str]] = field(default_factory=set)

    def clone(self) -> Design:
        return Design(self.components.copy(), set(self.bindings), self.decompositions.copy(),
                      self.mappings.copy(), self.requirements.copy(), set(self.transitions),
                      set(self.exclusions), set(self.closure))

    def serialization(self) -> dict[str, Any]:
        return {
            'components': [(c.name, sorted(c.requires), sorted(c.provides),
                            c.provides_complete, c.version)
                           for c in sorted(self.components.values(), key=lambda x: x.name)],
            'bindings': sorted(self.bindings),
            'decompositions': sorted((k, v) for k, v in self.decompositions.items()),
            'mappings': sorted((k, v) for k, v in self.mappings.items()),
            'requirements': sorted((r.id, r.scope, r.statement) for r in self.requirements.values()),
            'transitions': sorted(self.transitions),
            'exclusions': sorted(self.exclusions),
            'closure': sorted(self.closure),
        }

    def digest(self) -> str:
        return sha256(json.dumps(self.serialization(), sort_keys=True).encode('utf-8')).hexdigest()

    def classify_behavior(self, component: str, state: str, action: str) -> str:
        positive = any((c, s, a) == (component, state, action)
                       for c, s, a, _ in self.transitions)
        negative = (component, state, action) in self.exclusions
        if positive and negative:
            return 'conflict'
        if positive:
            return 'declared_possible'
        if negative or (component, state, action) in self.closure:
            return 'forbidden_in_declared_scope'
        return 'underspecified'


@dataclass(frozen=True)
class Obligation:
    key: str
    kind: str
    subject: str
    description: str


@dataclass(frozen=True)
class Report:
    id: str
    obligation: str
    polarity: str  # support/refute/unknown, NOT global truth
    method: str
    origin: str
    design_digest: str
    scope: str
    note: str
    decisive_for_fragment: bool = False


@dataclass(frozen=True)
class Preview:
    proposed_digest: str
    edits: tuple[Edit, ...]
    obligations: tuple[Obligation, ...]
    changed: bool


class Kernel:
    """Mutable driver of an append-only semantic event history.

    The snapshot API returns defensive copies. Conservative invalidation:
    ALL old reports become stale on ANY semantic edit. Selective dependency
    invalidation is deliberately not claimed.
    """
    def __init__(self) -> None:
        self._design = Design()
        self._revision = 0
        self._proposals: dict[str, Proposal] = {}
        self._reports: dict[str, Report] = {}
        self._history: list[tuple[str, str, int, str]] = []
        self._revision_digests: dict[int, str] = {0: self._design.digest()}
        self._view_revision = 0

    @property
    def revision(self) -> int:
        return self._revision

    @property
    def view_revision(self) -> int:
        return self._view_revision

    @property
    def digest(self) -> str:
        return self._design.digest()

    @property
    def history(self) -> tuple[tuple[str, str, int, str], ...]:
        return tuple(self._history)

    def snapshot(self) -> Design:
        return self._design.clone()

    def proposal(self, identifier: str) -> Proposal:
        return self._proposals[identifier]

    def reports(self) -> tuple[Report, ...]:
        return tuple(self._reports.values())

    # SEMANTIC PRIMITIVE 1: SUGGEST; never modifies accepted design.
    def propose(self, identifier: str, *edits: Edit, rationale: str = '') -> Proposal:
        if not identifier or identifier in self._proposals or not edits:
            raise ValueError('nonempty unique proposal and patch required')
        p = Proposal(identifier, self._revision, tuple(edits), rationale)
        self._proposals[identifier] = p
        self._history.append(('propose', identifier, self._revision, self.digest))
        return p

    # Derived query; intentionally no semantic mutation.
    def preview(self, identifier: str) -> Preview:
        p = self._proposals[identifier]
        if p.base_revision != self._revision:
            raise ValueError('stale proposal: preview requires explicit rebase')
        candidate = self._apply(self._design, p.edits)
        return Preview(candidate.digest(), p.edits, tuple(generate_obligations(candidate).values()),
                       candidate.digest() != self.digest)

    # SEMANTIC PRIMITIVE 2: DECIDE; only 'accept' may mutate accepted design.
    def decide(self, identifier: str, outcome: str, *, authorized: bool = False) -> None:
        p = self._proposals[identifier]
        if outcome not in ('accept', 'reject') or p.status != 'pending':
            raise ValueError('invalid or repeated decision')
        if not authorized:
            raise PermissionError('a decision requires an authorized actor')
        if outcome == 'accept':
            if p.base_revision != self._revision:
                raise ValueError('stale proposal: explicit rebase and review required')
            candidate = self._apply(self._design, p.edits)  # validate all first
            if candidate.digest() == self.digest:
                raise ValueError('empty semantic transaction')
            self._design = candidate
            self._revision += 1
            self._revision_digests[self._revision] = self.digest
        self._proposals[identifier] = replace(p, status='accepted' if outcome == 'accept' else 'rejected')
        self._history.append(('decide:'+outcome, identifier, self._revision, self.digest))

    # SEMANTIC PRIMITIVE 3: REPORT; cannot silently edit commitments.
    def report(self, value: Report) -> None:
        if value.decisive_for_fragment or value.method.startswith('builtin.'):
            raise PermissionError('user reports may not impersonate a built-in evaluator')
        if value.origin == 'model_generated' and value.method == 'independent_oracle':
            raise ValueError('model-generated evidence cannot declare independent oracle status')
        self._register_report(value)

    def _register_report(self, r: Report) -> None:
        if not r.id or r.id in self._reports or not r.scope or not r.origin:
            raise ValueError('report requires unique id, scope, and origin')
        if r.polarity not in {'support', 'refute', 'unknown'}:
            raise ValueError('invalid report polarity')
        if r.design_digest not in self._revision_digests.values():
            raise ValueError('report references unknown design snapshot')
        self._reports[r.id] = r
        self._history.append(('report', r.id, self._revision, self.digest))

    def evaluate_interface(self, consumer: str, provider: str) -> Report:
        """Derived, fixed-scope evaluator: advertised nominal capability sets only."""
        binding = (consumer, provider)
        if binding not in self._design.bindings:
            raise ValueError('binding is not accepted')
        cons = self._design.components[consumer]
        prov = self._design.components[provider]
        absent = cons.requires - prov.provides
        if not absent:
            polarity, decisive = 'support', True
        elif prov.provides_complete:
            polarity, decisive = 'refute', True
        else:
            polarity, decisive = 'unknown', False
        r = Report('nominal:%s->%s@%d' % (consumer, provider, self.revision),
                   'interface:%s->%s' % (consumer, provider), polarity,
                   'builtin.nominal-subset.v1', 'computed', self.digest,
                   'advertised nominal capability sets only',
                   'missing=%s; provider inventory complete=%s' %
                   (sorted(absent), prov.provides_complete), decisive)
        self._register_report(r)
        return r

    def obligations(self) -> dict[str, Obligation]:
        return generate_obligations(self._design)

    def obligation_status(self, key: str) -> str:
        if key not in self.obligations():
            raise KeyError('not an obligation in the current design (may be retired)')
        fresh = [r for r in self._reports.values()
                 if r.obligation == key and r.design_digest == self.digest]
        support = [r for r in fresh if r.polarity == 'support']
        refute = [r for r in fresh if r.polarity == 'refute']
        decisive_support = any(r.decisive_for_fragment for r in support)
        decisive_refute = any(r.decisive_for_fragment for r in refute)
        if decisive_support and decisive_refute:
            return 'conflicting_decisive_reports'
        if decisive_refute:
            return 'refuted_in_fragment'
        if decisive_support:
            return 'discharged_in_fragment'
        if support and refute:
            return 'contested'
        if refute:
            return 'challenged'
        if support:
            return 'supported_not_discharged'
        return 'open'

    def evidence_conflict(self, key: str) -> bool:
        fresh = [r for r in self._reports.values()
                 if r.obligation == key and r.design_digest == self.digest]
        return ({'support', 'refute'} <= {r.polarity for r in fresh})

    def report_freshness(self, identifier: str) -> str:
        return 'current' if self._reports[identifier].design_digest == self.digest else 'stale'

    def relayout(self, note: str = '') -> None:
        """Nonsemantic view operation; NOT a design-operation primitive."""
        self._view_revision += 1
        self._history.append(('view', note, self._revision, self.digest))

    @staticmethod
    def _apply(base: Design, edits: tuple[Edit, ...]) -> Design:
        d = base.clone()
        for edit in edits:
            a = edit.args
            if edit.op == 'add_component':
                (c,) = a
                if not isinstance(c, Component) or not c.name or c.name in d.components:
                    raise ValueError('bad or duplicate component')
                d.components[c.name] = c
            elif edit.op == 'revise_component':
                (c,) = a
                if not isinstance(c, Component) or c.name not in d.components:
                    raise ValueError('revision of unknown component')
                d.components[c.name] = replace(c, version=d.components[c.name].version + 1)
            elif edit.op == 'bind':
                consumer, provider = a
                if consumer == provider or consumer not in d.components or provider not in d.components or (consumer, provider) in d.bindings:
                    raise ValueError('invalid or duplicate binding')
                d.bindings.add((consumer, provider))
            elif edit.op == 'decompose':
                parent, children = a
                if (parent not in d.components or parent in d.decompositions or
                    not children or len(children) != len(set(children)) or
                    parent in children or any(c not in d.components for c in children)):
                    raise ValueError('invalid decomposition')
                # A decomposition hierarchy cannot contain cycles. Other
                # typed relations (bindings) may be cyclic by design.
                def reaches(start: str, wanted: str) -> bool:
                    fringe, visited = [start], set()
                    while fringe:
                        cur = fringe.pop()
                        if cur == wanted: return True
                        if cur in visited: continue
                        visited.add(cur)
                        fringe.extend(d.decompositions.get(cur, ()))
                    return False
                if any(reaches(child, parent) for child in children):
                    raise ValueError('cyclic decomposition')
                d.decompositions[parent] = tuple(children)
            elif edit.op == 'mapping':
                parent, pairs = a
                if parent not in d.decompositions or not pairs:
                    raise ValueError('cannot map undecomposed component or empty mapping')
                if len(set(x for x, _ in pairs)) != len(pairs):
                    raise ValueError('duplicate action mapping')
                d.mappings[parent] = tuple(pairs)
            elif edit.op == 'require':
                (r,) = a
                if not isinstance(r, Requirement) or not r.id or not r.statement or r.id in d.requirements:
                    raise ValueError('invalid or duplicate requirement')
                d.requirements[r.id] = r
            elif edit.op == 'revise_requirement':
                (r,) = a
                if not isinstance(r, Requirement) or r.id not in d.requirements:
                    raise ValueError('unknown requirement')
                d.requirements[r.id] = r
            elif edit.op == 'transition':
                name, source, action, target = a
                if name not in d.components or not all((source, action, target)):
                    raise ValueError('invalid transition')
                d.transitions.add((name, source, action, target))
            elif edit.op == 'exclude':
                name, source, action = a
                if name not in d.components:
                    raise ValueError('invalid exclusion')
                d.exclusions.add((name, source, action))
            elif edit.op == 'close':
                name, source, action = a
                if name not in d.components:
                    raise ValueError('invalid closure')
                d.closure.add((name, source, action))
            else:
                raise ValueError('unknown edit constructor: ' + edit.op)
        return d


def generate_obligations(d: Design) -> dict[str, Obligation]:
    """Local generation laws. Newly minted obligations are NEVER auto-proofs."""
    result: dict[str, Obligation] = {}
    def put(k: str, kind: str, target: str, desc: str) -> None:
        result[k] = Obligation(k, kind, target, desc)
    for consumer, provider in sorted(d.bindings):
        t = consumer + '->' + provider
        put('interface:' + t, 'nominal_interface', t, 'advertised requires subset of provides')
        put('assume_guarantee:' + t, 'contractual', t, 'check actual provider guarantees against consumer assumptions')
        put('effects:' + t, 'behavioral', t, 'specify interaction and failure/effect behavior')
    for parent, children in sorted(d.decompositions.items()):
        put('composition:' + parent, 'composition', parent, 'specify semantics of child composition')
        put('observation:' + parent, 'abstraction', parent,
            'check presence, coverage, and semantics of observation/hiding map; declaration alone is insufficient')
        put('refinement:' + parent, 'refinement', parent, 'show composed behavior refines parent under declared observations')
        put('interference:' + parent, 'interference', parent, 'check shared effects and child assumptions')
    for r in sorted(d.requirements.values(), key=lambda x: x.id):
        put('requirement:' + r.id, 'requirement', r.scope, 'establish requirement: ' + r.statement)
    for component, source, action, target in sorted(d.transitions):
        if (component, source, action) in d.exclusions:
            put(f'conflict:{component}:{source}:{action}', 'declaration_conflict', component,
                'positive and negative behavior declarations coexist')
    return result


def bounded_trace_check(abstract: dict[str, tuple[tuple[str,str], ...]],
                        concrete: dict[str, tuple[tuple[str,str], ...]],
                        mapping: dict[str, str | None] | None, depth: int,
                        initial: str = 'Created') -> tuple[str, tuple[str, ...] | None]:
    """Illustrative finite, depth-bounded, trace-safety-only evaluator."""
    if mapping is None or depth < 0:
        return 'unknown', None
    if any(action not in mapping for outgoing in concrete.values() for action, _ in outgoing):
        return 'unknown', None
    def paths(g: dict, obs_map: dict | None) -> set[tuple[str,...]]:
        frontier = [(initial, ())]
        paths_found = {()}
        for _ in range(depth):
            next_frontier = []
            for current, trace in frontier:
                for action, next_state in g.get(current, ()):
                    observed = action if obs_map is None else obs_map[action]
                    new_trace = trace if observed is None else trace + (observed,)
                    paths_found.add(new_trace)
                    next_frontier.append((next_state, new_trace))
            frontier = next_frontier
        return paths_found
    diff = paths(concrete, mapping) - paths(abstract, None)
    if diff:
        return 'counterexample_within_bound', sorted(diff, key=lambda x: (len(x), x))[0]
    return 'no_counterexample_within_bound', None
