import unittest
from contracts import *
class ContractTests(unittest.TestCase):
    def setUp(self):
        A=frozenset({'pay','ship'})
        self.A=Contract('abstract',A,finite_language(A,2),frozenset({(),('pay',),('pay','ship')}),2)
    def test_equal(self): self.assertEqual(compatible(self.A,self.A).status,'pass')
    def test_stronger_assumption_fails(self):
        c=Contract('provider',self.A.alphabet,frozenset({()}),self.A.guarantees,2)
        self.assertEqual(compatible(c,self.A).status,'fail')
    def test_extra_behavior_fails(self):
        c=Contract('provider',self.A.alphabet,self.A.assumptions,self.A.guarantees|{('ship',)},2)
        self.assertEqual(compatible(c,self.A).witness,('ship',))
    def test_better_provider(self):
        c=Contract('provider',self.A.alphabet,self.A.assumptions,frozenset({(),('pay',)}),2)
        self.assertEqual(compatible(c,self.A).status,'pass')
    def test_open_unknown(self):
        c=Contract('provider',self.A.alphabet,self.A.assumptions,self.A.guarantees,2,False)
        self.assertEqual(compatible(c,self.A).status,'unknown')
    def test_vocab_unknown(self):
        c=Contract('other',frozenset({'p'}),frozenset({()}),frozenset({()}),2)
        self.assertEqual(compatible(c,self.A).status,'unknown')
    def test_vacuous_unknown(self):
        c=Contract('empty',self.A.alphabet,frozenset(),self.A.guarantees,2)
        self.assertEqual(compatible(c,self.A).status,'unknown')
    def test_refine_good(self):
        c=frozenset({(),('auth',),('auth','capture'),('auth','capture','send')})
        m={'auth':None,'capture':'pay','send':'ship'}
        self.assertEqual(refine_traces(c,self.A,m,max_concrete_length=3).status,'pass')
    def test_refine_bad(self):
        c=frozenset({('auth','send')});m={'auth':None,'send':'ship'}
        r=refine_traces(c,self.A,m,max_concrete_length=3)
        self.assertEqual((r.status,r.witness),('fail',('auth','send')))
    def test_incomplete_mapping_unknown(self):
        self.assertEqual(refine_traces(frozenset({('auth','capture')}),self.A,{'auth':None},max_concrete_length=2).status,'unknown')
    def test_empty_concrete_unknown(self):
        self.assertEqual(refine_traces(frozenset(),self.A,{},max_concrete_length=2).status,'unknown')
    def test_interleave(self):
        a=Contract('A',frozenset({'a'}),frozenset({()}),frozenset({('a',)}),1)
        b=Contract('B',frozenset({'b'}),frozenset({()}),frozenset({('b',)}),1)
        traces,v=compose_interleaving(a,b,2)
        self.assertEqual((v.status,traces),('pass',frozenset({('a','b'),('b','a')})))
    def test_shared_sync_unknown(self):
        a=Contract('A',frozenset({'a'}),frozenset({()}),frozenset({('a',)}),1)
        self.assertEqual(compose_interleaving(a,a,2)[1].status,'unknown')
    def test_prefix_is_not_automatic(self):
        self.assertNotEqual(all_prefixes(frozenset({('pay','ship')})),frozenset({('pay','ship')}))
    def test_horizon_mismatch_unknown(self):
        c=Contract('short',self.A.alphabet,frozenset({()}),frozenset({()}),1)
        self.assertEqual(compatible(c,self.A).status,'unknown')
    def test_invalid_action_domain(self):
        c=Contract('bad',self.A.alphabet,frozenset({()}),frozenset({('refund',)}),2)
        self.assertEqual(compatible(c,self.A).status,'unknown')
if __name__=='__main__': unittest.main()
