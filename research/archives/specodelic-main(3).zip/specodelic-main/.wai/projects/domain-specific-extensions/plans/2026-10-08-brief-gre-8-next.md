---
tags: [pipeline-run:epic-orchestrator-2026-10-08-specodelic-gre-8-derived-diagrams-stable-under-prose-perturbation-task-2-7, pipeline-step:select-ticket]
---

BRIEF gre.8 next
