---
tags: [pipeline-run:epic-orchestrator-2026-10-09-specodelic-lf4b-7-cold-reader-glossary-page, pipeline-step:write-brief]
---

BRIEF: .wai/projects/domain-specific-extensions/briefs/specodelic-lf4b.7.md
