# M3 Specification — Minimal operational semantics of designing

**Status:** Candidate normative rules for an experimental reference machine. Not an accepted standard or a general formal theory of all design work.

## 1. Scope and meaning

The object under study is the **act of producing and revising a design**, not only the semantics of the resulting software. A design may be partial, overconstrained, contradictory or unrealizable. The semantic system must allow such intermediate situations without mistakenly declaring them verified.

A *system model* denotes possible behavior under a chosen semantic interpretation. A *design process* includes choices, proposals, evidence and knowledge about the model. M3 describes the process; the earlier M1 institution-style semantics can potentially interpret qualified subsets of accepted descriptions. That bridge is not implemented here.

An **accepted design** means authorized, not proven. An **obligation** is a condition still needing specified evidence. A **report** is an evidence item with a method and scope; an arbitrary report must not be promoted into proof. A **revision** identifies a particular accepted design snapshot. An **abstraction mapping** associates concrete events with abstract observable events or hiding (`None`). A **model-only tracer** is a narrow simulation that uses the model as its source; it is not an independent oracle.

## 2. State and design edits

Let the design situation be

\[
W = (D, P, J, H, r)
\]

- `D` is the accepted design. It has components, nominal contract declarations, bindings, decompositions, optional abstraction maps, requirements, positive and excluded transitions, and local closed-world declarations.
- `P` maps unique proposal IDs to `(base_revision, typed_patch, rationale, status)`.
- `J` contains immutable reports `(claim/obligation, outcome, method, origin, digest, scope, note)`.
- `H` is an append-only event history. A faithful persistent replay engine is **NOT IMPLEMENTED** (a running in-memory sequence is stored).
- `r` is the accepted semantic revision. Workspace/view revision is independent.

The **semantic digest** hashes a canonical serialization of `D`; it excludes proposal candidates, evaluator reports and layout. The report's `design_digest` is compared against the current accepted digest. Current M3 adopts **conservative global invalidation**: every accepted semantic edit stales all reports from different digests. This may over-invalidate unrelated evidence, but avoids claiming sound selective invalidation from an incomplete dependency graph. A production system must also include semantic profile versions and evaluator configuration in relevant cache keys; this reference code does not.

A patch is a nonempty finite sequence `δ = [e1,...,en]` of typed edits. Each edit is a *partial function* over designs, `e : D ⇀ D'`; applying a patch is a sequential composition, undefined if any guard fails. M3 supports: `add_component`, `revise_component`, `bind`, `decompose`, `mapping`, `require`, `revise_requirement`, `transition`, `exclude` and `close`. `revise_component` is a **complete replacement** of a component's declared contract, not a merge patch. Each compound patch is validated on a private copy before publishing any mutation.

A composition `decompose(parent, children)` is a hierarchical relation (acyclic) with explicit endpoints; it does not define the runtime behavior of the composite. A binding is a structural declaration and may refer to an incompatible contract. This is intentional: recording a problematic binding is a useful design fact, not a correctness certificate.

## 3. Primitive events

The proposed primitive event signature is:

```
propose(id, typed_patch, base_revision, rationale)
decide(id, accept|reject, authority)
report(evidence_with_scope_and_snapshot)
```

### Proposal

Given a unique ID and nonempty patch, with current accepted revision `r`:

\[
(D,P,J,H,r)\xrightarrow{propose(i,\delta)}
(D,P\cup\{i\mapsto(r,\delta,pending)\},J,H\cdot event,r).
\]

`D` is observationally unchanged. A `preview` is a **pure derived query**: attempt to apply patch to a copy, show resulting design and obligations, but do not accept them. A stale proposal cannot be previewed as a fresh revision without explicit rebase.

### Decision

For `decide(i, accept, authority)`, require a pending proposal, adequate authority, matching `base_revision` and a successful nonempty atomic patch application. Then:

\[
D' = \operatorname{apply}(D,\delta_i),\quad r'=r+1.
\]

Mark proposal accepted, publish `D'`, append an event; obligations will be recomputed for the new accepted design. **No condition demands that all generated obligations are discharged first.** This separation is what allows exploratory architecture work to proceed without asserting proof. A rejected proposal changes its status and history only. Invalid and unauthorized decisions have no state effect.

### Report

`report(j)` appends evidence referring to a known accepted snapshot, but never modifies `D`. Its author-declared origin is not independently authenticated by this reference machine. Reserved built-in evaluator labels and decisive status cannot be supplied through the public `report` entry point. `evaluate_interface`, a derived evaluator, computes a deliberately narrow advertised-capability inclusion result and internally records it.

Formal report truth is **method-indexed**, not a single unqualified Boolean. A negative test on one example is a challenge; a witness emitted by a trusted, sound fragment checker may refute its specific fragment. Positive bounded exploration is not a universal correctness proof. `report` admits contradictory evidence without rewriting old entries.

## 4. Why precisely these three primitives? A conditional minimality argument

For this **design workflow specification**, there are three distinct and non-collapsible observed effects:

1. **Consider without accepting:** a recorded counterfactual proposal must exist while `D` remains unchanged.
2. **Exercise decision authority:** a separate authorized action changes accepted commitment and must be rejectable.
3. **Learn without rewriting:** a supporting observation or falsifying counterexample must change the knowledge/evidence record without automatically changing `D`.

One can always encode the three as a single universal `append_event(payload)` operation, or split them into many more operations. Thus **three is a minimal meaningful *typed public-event basis under the chosen separation of concerns***, NOT a mathematically minimal number of machine instructions or a canonical basis. A future problem that cannot be expressed by `propose/decide/report` plus typed edits and derived queries would falsify this basis.

`fork`, `compare`, `simulate`, `challenge`, `revise`, `undo`, `verify` and `compose` are considered as follows:

| Design act | Construction | Limit |
|---|---|---|
| `constrain` | proposal with `require`, then accepted decision | Only statement registration; satisfaction remains open |
| `compose/bind` | proposal with `bind`; generate interface and behavior obligations | Declaring a binding is not proving it compatible |
| `decompose` | proposal with `decompose`; generate mapping/refinement obligations | No automatic preservation theorem |
| `revise` | proposal with typed replacement edit, accepted decision | Prior reports stale; explicit full replacement |
| `challenge` | report with negative/supporting testimony or checker counterexample | Does not force accepted change |
| `compare` | previews of alternative patches + declared criteria | Automated quality ordering NOT IMPLEMENTED |
| `simulate` | evaluator over chosen partial/closed behavior | Model-internal only, not empirical validity |
| `explore alternative` | multiple proposals sharing an accepted base revision | True long-lived branch merge NOT IMPLEMENTED |
| `undo` | new compensating proposal, with authorization | Arbitrary inverse/rollback of effects NOT IMPLEMENTED |
| `view / zoom` | presentation layer projection, independent revision | Not a design semantic event |

`interview stakeholder`, `interpret informal statements` and `discover missing concepts` are not magical semantic primitives: they are human/agent activities that output candidate edits or reports. The interpretation error risk must remain in provenance and uncertainty.

## 5. Obligation-generation calculus

Write `D ⊢ o` when an **accepted** declaration causes a new obligation. The current finite set of rules is deliberately incomplete and should be extensible by semantic profiles.

### Binding

\[
\frac{bind(C,P)\in D}
{D\vdash Interface(C,P),\; AssumeGuarantee(C,P),\; Effects(C,P)}
\quad (BIND)
\]

- `Interface(C,P)` asks whether the declared nominal requirements of consumer `C` appear in the advertised capabilities of provider `P`.
- `AssumeGuarantee(C,P)` asks whether the *actual* provider guarantees under assumptions discharge what the consumer requires, under an explicit contractual semantics.
- `Effects(C,P)` asks whether interaction, concurrency, failure and effect semantics are compatible.

The Python checker computes only **nominal subset inclusion**. If an advertised provider capability list is explicitly complete, a missing required symbol refutes nominal inclusion in this fragment. If the provider list is open/incomplete, missing evidence is `unknown`, not `refuted`. If all requirements are advertised, nominal inclusion is discharged **in the advertised syntactic fragment only**. Real contract compliance remains open.

### Decomposition

\[
\frac{decompose(C,[C_1,\ldots,C_n])\in D}
{D\vdash Compose(C),\; Observe(C),\; Refine(C),\; Interfere(C)}
\quad (DECOMPOSE)
\]

- `Compose`: name how children interact.
- `Observe`: define, check coverage of and justify the concrete-to-abstract observation/hiding map.
- `Refine`: show the composed behavior preserves the *specified* parent behavior (e.g. observable trace inclusion under assumptions) and guard against vacuity.
- `Interfere`: check shared state, effects and assumptions across children.

**Important:** Adding a `mapping` edit **does not discharge** `Observe`. Mapping existence, totality/coverage and preservation are distinct obligations. The earlier M2 model lacked this distinction.

### Requirement

\[
\frac{require(R,scope,text)\in D}
{D\vdash Satisfy(R,scope)}\quad (REQUIRE)
\]

A committed requirement adds an obligation. Its authorization does not discharge it.

### Contradictory behavioral declarations

\[
\frac{possible(c,s,a,t)\in D\quad excluded(c,s,a)\in D}
{D\vdash Conflict(c,s,a)}\quad (CONTRADICTION)
\]

Both declarations remain visible. Under an open-world behavioral profile, absence of a transition is `underspecified`. Explicit exclusion or local closure is required to call it forbidden. The reference code does not attempt logical explosion or automatically choose which declaration wins.

### Diagnostic and discharge status

`Generate(D)` returns the active obligation keys. `Diagnose(D,J)` produces a **status per active obligation** by considering evidence whose digest equals the current accepted design digest:

- `open`: no fresh relevant affirmative/negative evidence (or only unknown evidence).
- `supported_not_discharged`: positive but non-decisive report.
- `challenged`: negative but non-decisive report.
- `contested`: opposed non-decisive reports; keep both.
- `discharged_in_fragment`: positive decisive built-in checker, **only in its declared fragment**.
- `refuted_in_fragment`: negative decisive built-in checker, only in its declared fragment.
- `conflicting_decisive_reports`: mutually opposing decisive reports (should trigger evaluator audit).

A separate `evidence_conflict(key)` retains knowledge that both supporting and opposing reports exist, even if a decisive result establishes a narrow fragment. A report never gets retroactively reclassified as independent or universally sound. If an obligation key disappears following an explicit design edit, it is **retired by revision**, not proved. Historical events and reports must remain inspectable.

## 6. Candidate laws and validation boundaries

These are *proposed correctness conditions for a design-event implementation*, NOT empirically proven universal laws:

- **A1 Proposal safety:** proposal, rejection, report and view edits preserve accepted `D` and its digest.
- **A2 Authority separation:** only authorized accepted decisions change `D`.
- **A3 Atomicity:** an invalid compound patch cannot partially apply to accepted `D`.
- **A4 Concurrency/optimism:** stale proposals cannot overwrite the current accepted revision; an explicit rebase must be reviewed.
- **A5 Evidence specificity:** reports are tied to a known design digest, method, scope and origin.
- **A6 Evidence freshness:** any semantic revision invalidates previous report applicability, conservatively.
- **A7 Unknown preservation:** absent behavior/advertised capabilities remain unknown absent appropriate closure.
- **A8 Conflict retention:** opposite declarations or reports cannot cancel each other implicitly.
- **A9 Obligation generation:** decomposition, binding and requirements create specific new obligations.
- **A10 No false refinement:** parent-child decomposition or declared observation map cannot discharge semantic refinement.
- **A11 Fragment fidelity:** a decisive nominal-subset checker result can only settle that finite symbol-inclusion claim.
- **A12 View independence:** layout changes preserve accepted semantic identity and current evidential status.
- **A13 Typed patch composition:** concatenation of well-defined independent patches is associative (ordinary sequence concatenation); **order is not commutative** and partiality matters.
- **A14 Semantic vs logical correctness:** accepting inconsistent requirements is permitted; it creates explicit diagnostic obligations and does not establish satisfiability.

Proof obligations for a later formal semantics: prove small-step preservation of A1–A4 under all typed constructors; define an evaluator-calculus soundness theorem relative to one chosen model fragment; specify semantic dependency extraction for selective invalidation; specify replay and branch merge invariants; and establish that reporting counterexamples cannot silently mutate normative commitments. None of those theorems have been proven in this package.

## 7. Categorical interpretation — optional and precise

`Design` objects and valid typed edit sequences yield a category of *partial* design transformations only after domain/typing conditions are made explicit (for example as morphisms `D→D′` with composable patches). The identity is the empty patch in the mathematical patch algebra, even though the **user-facing commit API disallows no-op commits**. The associativity of patch-list concatenation is a syntactic fact, not a theorem about preserving software behavior. `propose`, `decide`, and `report` belong to a different event/workflow layer than accepted-design morphisms; not every event is a refinement arrow.

A designated class of interpretation-preserving arrows would require a relation between semantic interpretations of source and target designs and a proof of chosen property preservation. M1's institution can offer a target interpretation for suitable well-formed fragments, but partial raw descriptions, method-specific evidence and revision history are not automatically ordinary institution sentences. The present reference machine **has no institution implementation, functor, or general soundness theorem**. Do not add categorical machinery unless it buys a concrete checking/translation guarantee.

## 8. Worked derivation: refinement is an obligation, not an inference

Suppose a parent `Payment` has abstract event `pay`, and it is decomposed into `Authorize` and `Capture`. The accepted edit creates `Compose(Payment)`, `Observe(Payment)`, `Refine(Payment)`, and `Interfere(Payment)`. An observation map might hide `authorize` and map `capture` to `pay`. **That does not establish refinement.** The child system might permit `capture` twice, `ship` before payment or a diverging authorization loop. The included `bounded_trace_check` can find certain finite safety counterexamples under a user-provided map. It reports `no_counterexample_within_bound`, never `proved_refinement`.

## 9. Commit criteria for an M4 revision

Proceed to a more expressive semantic profile only if a structured external scenario corpus is available; independent human-designed examples discriminate valid behavior from model-generated agreement. Compare M3 against at least one rival model (e.g. plain graph editing + comments + tests) using measured outcomes: time to expose conflict, unauthorized contract mutations prevented, false proof promotions, explanations of invalidated evidence, number of necessary user interventions, ability to compare alternatives, and first end-to-end tracer coverage. This is a **proposal for a study**, not a result of one.
