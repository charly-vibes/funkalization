"""Tiny bounded exhaustive event-sequence exploration of M3 invariants.

NOT model checking arbitrary designs, and not a proof of the algebra.
Explores event sequences length <= 4 from a fixed 7-event alphabet.
"""
from itertools import product
from kernel import Kernel, Component, Edit, Report

ACTIONS = ('pose_A','pose_B','accept_A','accept_B','reject_A','reject_B','report')


def check_sequence(seq):
    k=Kernel()
    for action in seq:
        old_rev, old_digest, old_hist = k.revision, k.digest, k.history
        try:
            if action=='pose_A':
                k.propose('A',Edit('add_component',(Component('A'),)))
            elif action=='pose_B':
                k.propose('B',Edit('add_component',(Component('B'),)))
            elif action in ('accept_A','accept_B','reject_A','reject_B'):
                outcome, name=action.split('_')
                k.decide(name, 'accept' if outcome=='accept' else 'reject', authorized=True)
            elif action=='report':
                k.report(Report('report@'+str(len(k.reports())), 'uninterpreted_claim',
                                'unknown','scenario','model_generated',k.digest,
                                'bounded exploration only','no oracle'))
        except (ValueError, KeyError, PermissionError):
            # Rejected action is transactional at the semantic/event level.
            assert (k.revision,k.digest,k.history)==(old_rev,old_digest,old_hist), (seq,action,'bad rollback')
            continue
        if action.startswith('accept'):
            assert k.revision==old_rev+1 and k.digest!=old_digest, (seq,action,'bad commit')
        else:
            assert k.revision==old_rev and k.digest==old_digest, (seq,action,'non-decision mutation')
        assert len(k.history)==len(old_hist)+1, (seq, action, 'missing history event')
        assert len(k._revision_digests)==k.revision+1, (seq,action,'inconsistent revision digests')
    return True


def main():
    count=0
    for n in range(5):
        for seq in product(ACTIONS, repeat=n):
            check_sequence(seq)
            count+=1
    print(f'Explored {count} fixed-alphabet event sequences (lengths 0..4), all invariants passed.')


if __name__=='__main__':
    main()
