"""Independent-by-construction examples? NO: these are author-created design regression tests.
They test M3 implementation consistency, not empirical fit or independent oracles.
"""
import unittest
from kernel import (Kernel, Component, Edit, Requirement, Report,
                    bounded_trace_check)


def add(name, requires=(), provides=(), complete=False):
    return Edit('add_component', (Component(name, frozenset(requires), frozenset(provides), complete),))


def bind(c, p):
    return Edit('bind', (c, p))


def accept(k, key, *edits):
    k.propose(key, *edits)
    k.decide(key, 'accept', authorized=True)


def external(k, key, target, polarity, *, method='scenario', scope='specific example', digest=None):
    value = Report(key, target, polarity, method, 'externally_supplied', digest or k.digest,
                   scope, 'provenance is self-declared and not independently authenticated')
    k.report(value)
    return value


class Events(unittest.TestCase):
    def test_proposal_does_not_edit_accepted_design(self):
        k = Kernel(); old = k.digest
        k.propose('p', add('A'))
        self.assertEqual(k.digest, old)
        self.assertNotIn('A', k.snapshot().components)
        self.assertEqual(k.revision, 0)

    def test_rejection_requires_authorization(self):
        k = Kernel(); k.propose('p', add('A'))
        with self.assertRaises(PermissionError):
            k.decide('p', 'reject')
        k.decide('p', 'reject', authorized=True)
        self.assertEqual(k.digest, Kernel().digest)

    def test_accept_requires_authorization(self):
        k = Kernel(); k.propose('p', add('A'))
        with self.assertRaises(PermissionError):
            k.decide('p', 'accept')
        self.assertEqual(k.revision, 0)
        k.decide('p', 'accept', authorized=True)
        self.assertEqual(k.revision, 1)
        self.assertIn('A', k.snapshot().components)

    def test_rejected_cannot_be_accepted(self):
        k = Kernel(); k.propose('p', add('A')); k.decide('p', 'reject', authorized=True)
        with self.assertRaises(ValueError):
            k.decide('p', 'accept', authorized=True)

    def test_stale_alternative_requires_rebase(self):
        k = Kernel(); k.propose('A', add('A')); k.propose('B', add('B'))
        k.decide('A', 'accept', authorized=True)
        with self.assertRaisesRegex(ValueError, 'stale'):
            k.decide('B', 'accept', authorized=True)
        self.assertEqual(set(k.snapshot().components), {'A'})

    def test_batch_validation_atomic(self):
        k = Kernel(); k.propose('p', add('A'), bind('A', 'missing'))
        before = (k.digest, k.revision, k.history)
        with self.assertRaises(ValueError):
            k.decide('p', 'accept', authorized=True)
        self.assertEqual((k.digest, k.revision, k.history), before)
        self.assertEqual(k.proposal('p').status, 'pending')

    def test_preview_is_pure_and_obligation_aware(self):
        k = Kernel(); accept(k, 'init', add('A'), add('B'))
        k.propose('what-if', bind('A', 'B'))
        before = (k.digest, k.history, k.revision)
        pv = k.preview('what-if')
        self.assertIn('interface:A->B', [o.key for o in pv.obligations])
        self.assertEqual((k.digest, k.history, k.revision), before)

    def test_invalid_preview_is_pure(self):
        k = Kernel(); k.propose('p', bind('nonexistent', 'else'))
        before = (k.digest, k.history)
        with self.assertRaises(ValueError):
            k.preview('p')
        self.assertEqual((k.digest, k.history), before)

    def test_algebra_of_independent_patch_concatenation(self):
        # Restricted associativity in a typed patch monoid, not general edit commutativity.
        A, B, C = ((add(x),) for x in 'ABC')
        left = A + (B + C)
        right = (A + B) + C
        x, y = Kernel(), Kernel()
        accept(x, 'left', *left); accept(y, 'right', *right)
        self.assertEqual(x.digest, y.digest)

    def test_stale_preview_rejected(self):
        k = Kernel(); k.propose('p', add('A')); k.propose('q', add('B'))
        k.decide('p', 'accept', authorized=True)
        with self.assertRaisesRegex(ValueError, 'stale'):
            k.preview('q')

    def test_patches_not_globally_commutative(self):
        k = Kernel(); k.propose('p', bind('A', 'B'), add('A'), add('B'))
        with self.assertRaises(ValueError):
            k.preview('p')
        x = Kernel(); accept(x, 'accepted', add('A'), add('B'), bind('A', 'B'))
        self.assertIn(('A', 'B'), x.snapshot().bindings)

    def test_report_cannot_be_privileged_built_in(self):
        k = Kernel(); e = Report('bad', 'x', 'support', 'builtin.fake', 'user', k.digest,
                                 'everything', 'fake', True)
        with self.assertRaises(PermissionError):
            k.report(e)

    def test_model_generated_cannot_claim_independence(self):
        k = Kernel()
        with self.assertRaises(ValueError):
            k.report(Report('fake','any','support','independent_oracle',
                            'model_generated',k.digest,'example','not independent'))

    def test_external_report_does_not_change_design(self):
        k = Kernel(); accept(k, 'req', Edit('require', (Requirement('R1','Payment','pay once'),)))
        before = k.digest
        external(k, 'e', 'requirement:R1', 'refute')
        self.assertEqual(k.digest, before)
        self.assertEqual(k.obligation_status('requirement:R1'), 'challenged')

    def test_report_cannot_reference_fabricated_snapshot(self):
        k = Kernel()
        with self.assertRaises(ValueError):
            external(k, 'fake', 't', 'support', digest='fake-digest')

    def test_external_support_not_promoted_to_proof(self):
        k = Kernel(); accept(k, 'req', Edit('require', (Requirement('R','System','durability'),)))
        external(k, 'external-support', 'requirement:R', 'support')
        self.assertEqual(k.obligation_status('requirement:R'), 'supported_not_discharged')

    def test_conflicting_reports_remain_contested(self):
        k = Kernel(); accept(k, 'req', Edit('require', (Requirement('R','System','availability'),)))
        external(k, 'plus', 'requirement:R', 'support')
        external(k, 'minus', 'requirement:R', 'refute')
        self.assertEqual(k.obligation_status('requirement:R'), 'contested')
        self.assertEqual(len(k.reports()), 2)

    def test_any_semantic_edit_stales_old_evidence_conservatively(self):
        k = Kernel(); accept(k, 'req', Edit('require', (Requirement('R','System','availability'),)))
        external(k, 'e', 'requirement:R', 'support')
        accept(k, 'new-component', add('Unrelated'))
        self.assertEqual(k.report_freshness('e'), 'stale')
        self.assertEqual(k.obligation_status('requirement:R'), 'open')

    def test_proposal_rejection_view_are_semantic_identity(self):
        k = Kernel(); accept(k, 'req', Edit('require', (Requirement('R','System','availability'),)))
        external(k, 'e', 'requirement:R', 'support')
        before = k.digest
        k.propose('candidate', add('Extra'))
        k.decide('candidate', 'reject', authorized=True)
        k.relayout('move box')
        self.assertEqual(k.digest, before)
        self.assertEqual(k.report_freshness('e'), 'current')
        self.assertEqual(k.view_revision, 1)

    def test_obligation_retired_not_called_proved(self):
        # An obligation can disappear under an explicit parent requirement revision.
        # Existing evidence survives in append-only history and becomes stale.
        k = Kernel(); accept(k, 'req', Edit('require', (Requirement('R','A','one'),)))
        external(k, 'e', 'requirement:R', 'support')
        accept(k, 'revision', Edit('revise_requirement', (Requirement('R','A','two'),)))
        self.assertEqual(k.obligation_status('requirement:R'), 'open')
        self.assertEqual(k.report_freshness('e'), 'stale')
        self.assertIn(('report','e',1,k._revision_digests[1]), k.history)


class ContractsAndDecomposition(unittest.TestCase):
    def setup_binding(self, *, complete, good=False):
        k = Kernel()
        advertised = ('atomic_write',) if good else ('eventual_write',)
        accept(k, 'components', add('Processor', requires=('atomic_write',)),
               add('Storage', provides=advertised, complete=complete), bind('Processor','Storage'))
        return k

    def test_binding_generates_distinct_obligations(self):
        k = self.setup_binding(complete=True)
        self.assertEqual(set(k.obligations()), {
            'interface:Processor->Storage','assume_guarantee:Processor->Storage','effects:Processor->Storage'})

    def test_informal_counterclaim_cannot_erase_decisive_nominal_result(self):
        k = self.setup_binding(complete=True)
        k.evaluate_interface('Processor','Storage')
        external(k,'user-claims-it-works','interface:Processor->Storage','support')
        self.assertEqual(k.obligation_status('interface:Processor->Storage'),'refuted_in_fragment')
        self.assertTrue(k.evidence_conflict('interface:Processor->Storage'))

    def test_closed_missing_capability_is_refuted_nominally(self):
        k = self.setup_binding(complete=True)
        r = k.evaluate_interface('Processor', 'Storage')
        self.assertEqual(r.polarity, 'refute')
        self.assertEqual(k.obligation_status(r.obligation), 'refuted_in_fragment')
        self.assertEqual(k.snapshot().components['Processor'].requires, frozenset({'atomic_write'}))
        self.assertEqual(k.obligation_status('assume_guarantee:Processor->Storage'), 'open')

    def test_open_capability_list_missing_is_unknown(self):
        k = self.setup_binding(complete=False)
        r = k.evaluate_interface('Processor', 'Storage')
        self.assertEqual(r.polarity, 'unknown')
        self.assertEqual(k.obligation_status(r.obligation), 'open')

    def test_capability_inclusion_does_not_prove_behavior(self):
        k = self.setup_binding(complete=True, good=True)
        r = k.evaluate_interface('Processor', 'Storage')
        self.assertEqual(k.obligation_status(r.obligation), 'discharged_in_fragment')
        self.assertEqual(k.obligation_status('assume_guarantee:Processor->Storage'), 'open')
        self.assertEqual(k.obligation_status('effects:Processor->Storage'), 'open')

    def test_fix_is_explicit_revised_contract(self):
        k = self.setup_binding(complete=True)
        old = k.evaluate_interface('Processor', 'Storage')
        accept(k,'revise',Edit('revise_component',
              (Component('Storage', provides=frozenset({'atomic_write'}), provides_complete=True),)))
        self.assertEqual(k.report_freshness(old.id), 'stale')
        self.assertEqual(k.obligation_status('interface:Processor->Storage'), 'open')
        new = k.evaluate_interface('Processor', 'Storage')
        self.assertEqual(k.obligation_status(new.obligation), 'discharged_in_fragment')
        self.assertEqual(k.snapshot().components['Storage'].version, 2)

    def test_decomposition_creates_four_proof_obligations(self):
        k = Kernel(); accept(k,'parts',add('Payment'),add('Authorize'),add('Capture'))
        accept(k,'decomp',Edit('decompose',('Payment',('Authorize','Capture'))))
        self.assertEqual(set(k.obligations()), {'composition:Payment','observation:Payment',
            'refinement:Payment','interference:Payment'})
        self.assertEqual(k.obligation_status('refinement:Payment'), 'open')

    def test_mapping_does_not_discharges_its_own_adequacy_obligation(self):
        k = Kernel(); accept(k,'parts',add('Payment'),add('Authorize'),add('Capture'))
        accept(k,'decomp',Edit('decompose',('Payment',('Authorize','Capture'))))
        accept(k,'map',Edit('mapping',('Payment',(('authorize',None),('capture','pay')))))
        self.assertIn('observation:Payment', k.obligations())
        self.assertEqual(k.obligation_status('observation:Payment'), 'open')
        self.assertEqual(k.obligation_status('refinement:Payment'), 'open')

    def test_decomposition_needs_resolved_endpoints(self):
        k = Kernel(); accept(k,'parent',add('Parent'))
        k.propose('bad',Edit('decompose',('Parent',('Missing',))))
        with self.assertRaises(ValueError):
            k.decide('bad','accept',authorized=True)

    def test_decomposition_cycle_rejected(self):
        k = Kernel(); accept(k,'x',add('A'),add('B'),Edit('decompose',('A',('B',))))
        k.propose('bad',Edit('decompose',('B',('A',))))
        with self.assertRaisesRegex(ValueError,'cyclic'):
            k.decide('bad','accept', authorized=True)
        self.assertNotIn('B',k.snapshot().decompositions)

    def test_rejected_conflict_does_not_rewrite_parent(self):
        k = self.setup_binding(complete=True)
        k.evaluate_interface('Processor','Storage')
        k.propose('relax', Edit('revise_component',
                  (Component('Processor', requires=frozenset({'eventual_write'})),)))
        k.decide('relax','reject',authorized=True)
        self.assertEqual(k.snapshot().components['Processor'].requires, frozenset({'atomic_write'}))
        self.assertEqual(k.obligation_status('interface:Processor->Storage'),'refuted_in_fragment')

    def test_alternative_adapter_and_relaxation_coexist(self):
        k = self.setup_binding(complete=True)
        k.propose('adapter', add('AtomicAdapter', provides=('atomic_write',), complete=True))
        k.propose('relax-parent', Edit('revise_component',
                  (Component('Processor', requires=frozenset({'eventual_write'})),)))
        self.assertNotEqual(k.preview('adapter').proposed_digest,
                            k.preview('relax-parent').proposed_digest)
        self.assertEqual(k.proposal('adapter').status, 'pending')
        self.assertEqual(k.proposal('relax-parent').status, 'pending')

    def test_extension_preserves_declared_stable_core_under_addition(self):
        # Test only this change scenario, not a universal OCP guarantee.
        k = Kernel(); accept(k, 'core', add('Processor',requires=('write',)),
             add('BackendA',provides=('write',),complete=True),bind('Processor','BackendA'))
        before = k.snapshot().components['Processor']
        accept(k,'extension', add('BackendB',provides=('write',),complete=True))
        self.assertEqual(k.snapshot().components['Processor'],before)
        self.assertEqual(k.snapshot().components['Processor'].version,1)

    def test_requirement_acceptance_does_not_discharge_it(self):
        k=Kernel(); accept(k,'r', Edit('require',(Requirement('R','WholeSystem','no data loss'),)))
        self.assertEqual(k.obligation_status('requirement:R'),'open')


class BehaviorsAndValidation(unittest.TestCase):
    def test_missing_behavior_is_not_forbidden(self):
        k=Kernel(); accept(k,'x', add('Order'))
        self.assertEqual(k.snapshot().classify_behavior('Order','Cancelled','ship'),'underspecified')

    def test_explicit_exclusion_forbids_within_scope(self):
        k=Kernel(); accept(k,'x',add('Order'),Edit('exclude',('Order','Cancelled','ship')))
        self.assertEqual(k.snapshot().classify_behavior('Order','Cancelled','ship'),
                         'forbidden_in_declared_scope')

    def test_positive_and_negative_are_not_dropped(self):
        k=Kernel(); accept(k,'x',add('Order'),Edit('transition',('Order','Cancelled','ship','Shipped')),
                            Edit('exclude',('Order','Cancelled','ship')))
        self.assertEqual(k.snapshot().classify_behavior('Order','Cancelled','ship'),'conflict')
        self.assertIn('conflict:Order:Cancelled:ship',k.obligations())

    def test_local_closure_justifies_forbidden(self):
        k=Kernel(); accept(k,'x',add('Order'),Edit('close',('Order','Cancelled','ship')))
        self.assertEqual(k.snapshot().classify_behavior('Order','Cancelled','ship'),
                         'forbidden_in_declared_scope')

    def test_bounded_trace_check_finds_counterexample(self):
        abstract={'Created':(('pay','Paid'),)}
        concrete={'Created':(('authorize','Authorized'),),
                  'Authorized':(('capture','Paid'),),'Paid':(('ship','Shipped'),)}
        result, trace = bounded_trace_check(abstract, concrete,
                                    {'authorize':None,'capture':'pay','ship':'ship'},3)
        self.assertEqual(result,'counterexample_within_bound')
        self.assertEqual(trace,('pay','ship'))

    def test_no_counterexample_is_not_a_universal_proof(self):
        abstract={'Created':(('pay','Paid'),)}
        concrete={'Created':(('authorize','Authorized'),),
                  'Authorized':(('capture','Paid'),)}
        r, _=bounded_trace_check(abstract,concrete,{'authorize':None,'capture':'pay'},3)
        self.assertEqual(r,'no_counterexample_within_bound')

    def test_missing_observation_map_makes_refinement_unknown(self):
        result,_=bounded_trace_check({'Created':(('pay','Paid'),)},
             {'Created':(('capture','Paid'),)},None,2)
        self.assertEqual(result,'unknown')

    def test_unmapped_action_makes_refinement_unknown(self):
        result,_=bounded_trace_check({'Created':(('pay','Paid'),)},
             {'Created':(('capture','Paid'),)}, {}, 2)
        self.assertEqual(result,'unknown')

    def test_external_case_not_proof_and_model_check_distinct(self):
        k=Kernel(); accept(k,'x',add('Order'),Edit('require',
                 (Requirement('S','Order','shipping requires authorization'),)))
        external(k,'conform','requirement:S','support',method='hand-curated scenario')
        external(k,'model-failure','requirement:S','refute',method='bounded model search')
        self.assertEqual(k.obligation_status('requirement:S'),'contested')
        self.assertEqual({r.method for r in k.reports()},
                         {'hand-curated scenario','bounded model search'})


if __name__=='__main__':
    unittest.main(verbosity=2)
