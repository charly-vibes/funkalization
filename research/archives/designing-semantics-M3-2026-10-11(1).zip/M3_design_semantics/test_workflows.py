"""Scenario walks exercising design DIRECTIONS; scenarios are author constructed,
not independently gathered evidence about human design quality.
"""
import unittest
from kernel import Kernel, Component, Edit, Requirement, Report
from test_kernel import add, bind, accept, external


class Directions(unittest.TestCase):
    def test_top_down_start_with_goal_then_decompose(self):
        k=Kernel()
        accept(k,'goal',Edit('require',(Requirement('order-safe','Order','order must not be duplicated'),)))
        self.assertEqual(k.obligation_status('requirement:order-safe'),'open')
        accept(k,'parts',add('Order'),add('Ingest'),add('Process'),add('Store'))
        accept(k,'architecture',Edit('decompose',('Order',('Ingest','Process','Store'))))
        self.assertIn('refinement:Order',k.obligations())
        self.assertEqual(k.obligation_status('refinement:Order'),'open')

    def test_bottom_up_observation_challenges_design_without_rewriting(self):
        k=Kernel()
        accept(k,'components',add('Processor',requires=('atomic_write',)),
               add('Db',provides=('eventual_write',),complete=True),bind('Processor','Db'))
        k.evaluate_interface('Processor','Db')
        external(k,'implementation-observation','assume_guarantee:Processor->Db','refute',
                 method='bench-observed',scope='one observed configuration')
        self.assertEqual(k.obligation_status('interface:Processor->Db'),'refuted_in_fragment')
        self.assertEqual(k.obligation_status('assume_guarantee:Processor->Db'),'challenged')
        self.assertEqual(k.snapshot().components['Processor'].requires, frozenset({'atomic_write'}))

    def test_exploration_previews_multiple_alternatives_without_commit(self):
        k=Kernel(); accept(k,'system', add('Storage'))
        k.propose('local',add('LocalBackend',provides=('write',)))
        k.propose('remote',add('RemoteBackend',provides=('write',)))
        a,b=k.preview('local'),k.preview('remote')
        self.assertNotEqual(a.proposed_digest,b.proposed_digest)
        self.assertEqual(k.revision,1)
        k.decide('local','accept', authorized=True)
        with self.assertRaises(ValueError):
            k.decide('remote','accept',authorized=True)
        self.assertEqual(k.proposal('remote').status,'pending')
        self.assertNotIn('RemoteBackend',k.snapshot().components)

    def test_evolutionary_revision_invalidates_old_judgment(self):
        k=Kernel(); accept(k,'system',add('Service',requires=('write',)),
                   add('Store',provides=('write',),complete=True),bind('Service','Store'))
        old=k.evaluate_interface('Service','Store')
        accept(k,'evolution',Edit('revise_component',(Component('Store',
                 provides=frozenset({'eventual_write'}),provides_complete=True),)))
        self.assertEqual(k.report_freshness(old.id),'stale')
        self.assertEqual(k.obligation_status('interface:Service->Store'),'open')
        k.evaluate_interface('Service','Store')
        self.assertEqual(k.obligation_status('interface:Service->Store'),'refuted_in_fragment')

    def test_outside_in_trace_expectation_not_automatic_impl_proof(self):
        k=Kernel(); accept(k,'outcome', Edit('require',
                   (Requirement('refund','Order','a paid order can be refunded'),)),add('Order'))
        external(k,'user-story','requirement:refund','support',method='independently_authored_case',
                 scope='one refund example')
        self.assertEqual(k.obligation_status('requirement:refund'),'supported_not_discharged')
        self.assertEqual(len(k.snapshot().transitions),0)

    def test_inside_out_capability_without_justified_product_goal(self):
        k=Kernel(); accept(k,'technology', add('VectorEngine', provides=('cosine_similarity',),complete=True))
        self.assertFalse(k.snapshot().requirements)
        self.assertFalse(k.obligations())
        k.propose('product-goal',Edit('require',
                 (Requirement('useful-search','Search','find related documents'),)))
        self.assertFalse(k.snapshot().requirements)

    def test_middle_out_design_contract_then_expand_up_and_down(self):
        k=Kernel(); accept(k,'seed',add('Payment',provides=('pay',)))
        accept(k,'expand',add('Order',requires=('pay',)),add('Authorize'),add('Capture'),
               bind('Order','Payment'),Edit('decompose',('Payment',('Authorize','Capture'))))
        self.assertIn('assume_guarantee:Order->Payment',k.obligations())
        self.assertIn('refinement:Payment',k.obligations())
        self.assertEqual(k.obligation_status('refinement:Payment'),'open')

if __name__ == '__main__':
    unittest.main()
