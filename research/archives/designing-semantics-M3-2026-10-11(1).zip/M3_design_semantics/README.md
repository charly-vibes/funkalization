---
title: "M3 — Semantics of Designing: a minimal design-event algebra and obligation calculus"
date: "2026-10-11"
model: "OpenAI GPT-6"
prov:wasGeneratedBy: "Local analysis and Python executable reference experiment"
prov:wasAttributedTo: "OpenAI GPT-6"
prov:used:
  - "software-design-substrate-2026-10-11(3).zip"
  - "categorical-design-substrate-2026-10-11(1).zip"
  - "designing-semantics-M2-2026-10-11.md"
  - "specodelic-main(2).zip (context only; integration not attempted)"
  - "wanna-main(1).zip (context only; integration not attempted)"
source_commits: "UNKNOWN: uploaded zip archives do not authenticate Git HEAD"
status: "DESIGN PROPOSAL, runnable reference and bounded internal tests; NOT verified production semantics"
---

# TL;DR

**Question:** Can the act of designing software be modeled using a small operational vocabulary that preserves uncertainty, authorization, composition obligations and evidence, regardless of whether work begins top-down or bottom-up?

**M3 candidate answer:** A design situation has an accepted description `D`, an optional-proposal registry `P`, an evidence registry `J`, and a history `H`. Three distinguished semantic event constructors are `propose`, `decide`, and `report`. They operate on different kinds of state. Domain design operations (such as decomposition, binding and changing contracts) are **typed edits** inside proposals, not independent state-transition primitives. Obligations are derived by rules from the accepted design and diagnosed using evidence. A proposed design move can succeed administratively and still create an inconsistent, unsupported or unimplementable architecture.

**What was run:** `python -m unittest discover -v` ran **50 tests, 50 passed**. `python explore.py` examined **2,801 event sequences** of lengths 0–4 drawn from a fixed 7-event alphabet, checking local invariants. This is evidence of consistency of the reference implementation on these examples, not an independent validation of usefulness, soundness or completeness.

**Recommendation:** Keep this three-event candidate for the next stage. Do not call the kernel complete. The next necessary development is (1) a typed assumption/guarantee and behavior profile, (2) explicit judgment capability and trust boundaries, (3) semantic-dependency provenance for sound selective invalidation, and (4) externally authored scenarios with real implementation tracers.

## Files and execution

| File | Contents |
|---|---|
| `SPECIFICATION.md` | Self-contained formal definitions, inference rules, minimum-primitive argument, obligations and derived operations |
| `VALIDATION.md` | Scenario-by-scenario coverage, independent validation gaps, negative results and limitations |
| `kernel.py` | Runnable reference machine (Python stdlib) |
| `test_kernel.py` | Unit tests for all three primitives and core derived operations |
| `test_workflows.py` | Top-down, bottom-up, middle-out, outside-in, inside-out, exploratory and evolutionary workflows |
| `explore.py` | Bounded event-sequence state exploration |
| `run_results.txt` | Actual command outputs captured when creating this package |
| `manifest.json` | Provenance metadata and file hashes |

Reproduce from the unpacked directory (Python 3.10 or newer):

```bash
python -m unittest discover -v
python explore.py
```

No Specodelic or Wanna CLI was invoked in these validation commands. No claim of actual integration or third-party oracle independence is made.

## Concrete example: bottom-up conflict

The desired processor contract requires `atomic_write`; the storage candidate declares a **complete** nominal capability inventory containing only `eventual_write`.

1. `propose` creates a candidate binding; accepted design stays unchanged.
2. `decide(..., accept)` (authorized) adds the binding to the accepted design. That generates **three separate obligations**: nominal interface inclusion, behavioral assumption/guarantee, and interaction/effects.
3. `evaluate_interface` computes nominal inclusion on current accepted values: it reports missing `atomic_write`. This **refutes nominal inclusion within the declared closed-inventory fragment**, but does not prove anything about physical storage behavior.
4. The processor's requirement does not change. A designer can separately propose an adapter, a different backend or relaxing the requirement.
5. A revised backend contract invalidates the previous report. New checking must be run; merely advertising a capability still does not verify its implementation.

This distinction is more useful than automatically fixing the diagram: the model exposes what changed, which assumption failed, what must be investigated and who can authorize a change.

## Vocabulary, in one paragraph

A **commitment** is a description a designer has accepted for a particular candidate system; acceptance does not imply truth. A **proposal** is a possible modification not yet accepted. An **obligation** is an explicit condition required to establish a particular architectural or behavioral claim. A **report** is scoped evidence or a counterexample, with a stated origin and method. **Refinement** means that a more detailed model preserves the specified properties of a more abstract model under an explicit observation relation; structural decomposition alone cannot establish it. **A tracer** is a narrow end-to-end example used to exercise a design or implementation. **Open-world** means undeclared behavior is not presumed impossible. **Non-vacuity** means checking that a purported refinement does not succeed merely because the concrete model has no valid executions.

## Integrity

The empirical fit of this algebra to real design work is **UNKNOWN**. The specification is intentionally falsifiable: examples of missing transformations or a genuine need to maintain parallel accepted branches could force an extension of the primitive vocabulary. Read `VALIDATION.md` for a specific acceptance and falsification plan.
