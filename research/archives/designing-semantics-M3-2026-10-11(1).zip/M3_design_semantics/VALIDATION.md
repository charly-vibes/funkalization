# M3 Validation, falsification and next experiments

## TL;DR

The **reference machine** demonstrates a conditional separation of (1) hypothetical ideas, (2) authorized decisions and (3) evidence, while making selected design operations generate checkable obligations. Its tests cover useful distinctions for the original ten scenarios. The machine **has not been independently validated** as a semantic theory of human software designing, nor integrated with Specodelic or Wanna.

### Executed checks

| Kind | Method | Result | What it does **not** show |
|---|---|---|---|
| 50 unit tests | `python -m unittest discover -v` | 50 passed | Soundness, usability, complete scenario coverage |
| Bounded event exploration | `python explore.py` | 2,801 finite event sequences pass chosen invariants | Correctness of untested events, larger state spaces, concurrency |
| Checker fragment | Nominal `requires ⊆ provides` with explicit provider closedness | Correctly distinguishes support/refute/unknown in fixtures | Real API contracts or actual storage guarantees |
| Bounded behavior | Trace inclusion on finite labeled transition graphs | Detects a chosen `pay,ship` counterexample | Refinement beyond chosen depth; liveness, fairness or deadlock |
| Seven movement scripts | `test_workflows.py` | 7 passed | Real-world ergonomic usefulness or independent validation |

All fixtures are written by the same author/model as the reference code: they are **not independent oracles**. In particular, tests passing cannot establish that the semantics are adequate for real developers.

## Design directions: coverage and limits

| Entry direction | Executed experiment | Validated narrow rule | Remaining gap |
|---|---|---|---|
| **Top-down** | Goal → components → decomposition | Accepted goal creates obligation; decomposition creates more | Does not synthesize a correct decomposition |
| **Bottom-up** | Discover unsupported storage contract | Detects nominal mismatch and challenge without rewriting the parent | No true assume/guarantee implementation |
| **Middle-out** | Define payment seam; expand parent consumer and children | Both binding and refinement obligations coexist | No composition of concrete behavioral semantics |
| **Outside-in** | End-user refund example before implementation | Example evidence remains scoped, no claimed program proof | No independent source authentication |
| **Inside-out** | Discovered vector similarity capability | Capability does not automatically imply a product goal | No measures of desirability or usefulness |
| **Exploratory** | Preview two backend alternatives | Neither accepted until explicit decision; stale alternative not silently merged | No long-lived branch rebasing/merge or criteria-weighted comparison |
| **Evolutionary** | Revise existing storage contract | Old checker result stales; recheck can find new incompatibility | No implementation or migration evidence |

### Ten original design-substrate scenarios

Source of identifiers: `software-design-substrate/SCENARIOS.md` in the supplied baseline archive. The codes are user-provided **design scenarios**, not guaranteed acceptance results.

| ID | Original intent | M3 reference evidence | Assessment |
|---|---|---|---|
| E01 | Greenfield top-down with bottom-up backend correction | `test_bottom_up_observation_challenges_design_without_rewriting`, `test_rejected_conflict_does_not_rewrite_parent` | **Partial:** precise nominal mismatch; no verified adapter feasibility |
| E02 | Semantic zoom / refinement | `test_decomposition_creates_four_proof_obligations`, bounded trace tests, observation-map non-discharge regression | **Partial:** obligation discipline; no general composition/refinement |
| E03 | Model-only tracer + external cases | Local behavior classifier; bounded finite trace evaluator | **Partial:** not an end-to-end composed tracer or spk conform replay |
| E04 | Oracle independence | `test_model_generated_cannot_claim_independence`; external support does not discharge requirement | **Partial:** cannot authenticate genuine independence, no external oracle |
| E05 | Open/Closed extension | `test_extension_preserves_declared_stable_core_under_addition` | **Partial:** one selected extension leaves processor unchanged; not general OCP |
| E06 | Geometry versus semantic editing | `test_proposal_rejection_view_are_semantic_identity` | **Partial:** state/view separation, no actual renderer round-trip |
| E07 | Implementation tracer | Report fields, current-digest association, method separation | **Not executed:** no runtime adapter/build trace |
| E08 | Human interaction/recovery | Authorization, rejection, revision guard | **Partial:** no durable restore or actual Wanna integration |
| E09 | Modularity is not visual grouping | Decomposition generates interface/interference obligations; no inference from layout | **Partial:** no typed coupling metric or modularity theorem |
| E10 | Model check versus conformance | `test_external_case_not_proof_and_model_check_distinct` | **Partial:** conceptual distinction only, no real spk conform/model_check execution |

A large majority of the ten scenarios remain *partially covered*, intentionally. Treating a regression test for a vocabulary distinction as complete end-to-end validation would be a false positive.

## Counterexamples and boundaries found while building M3

1. **A mapping is not a proof.** An early draft removed `Observe(parent)` when a mapping existed, even if the mapping did not cover all concrete events. Revised: `Observe` remains active; presence/coverage/semantic adequacy must be evaluated separately. Test `test_mapping_does_not_discharges_its_own_adequacy_obligation`.
2. **A decisive checker fragment cannot be casually erased by testimony.** An early draft reported `contested` even when a decisive nominal checker refuted a closed capability inventory and an informal comment supported it. Revised: preserve `refuted_in_fragment` and separately expose an evidence conflict flag. This does not authorize promoting the checker to a behavioral theorem.
3. **Stale previews are deceptive.** An early preview applied an old patch to a new accepted state without an explicit rebase. Revised: stale preview requires explicit rebase. No rebase facility is implemented yet.
4. **Decomposition is not arbitrary graph connectivity.** A draft allowed `A` to decompose into `B` while `B` decomposed into `A`. Revised: this hierarchical edit forbids cycles; general cyclic dependencies remain expressible through bindings.
5. **Missing is not forbidden.** Partial transition listings without declared closure yield `underspecified`. Explicit exclusions and local closure justify `forbidden_in_declared_scope` in the toy profile.
6. **A green bounded test is not a refinement theorem.** For payment, no counterexample to depth 3 remains exactly `no_counterexample_within_bound`. Adding a disallowed `ship` action produces a counterexample.
7. **A successful commit can leave obligations open.** Otherwise the process would conflate changing intentions with proving technical feasibility and halt legitimate exploration.
8. **Global invalidation is conservative.** All older reports go stale on any semantic change; this avoids claiming sound impact analysis before modeling every semantic dependency. Selective invalidation remains a research problem.

## Falsifiable hypotheses, rivals and evaluation protocol

- **H1 (separation):** `propose/decide/report` meaningfully prevents silent commitment changes relative to an edit-everything graph. Falsification: comparable unauthorized mutations occur in realistic instrumented sessions.
- **H2 (obligations):** automatic obligation generation increases detection of missing compositional assumptions without impractical noise. Falsification: a substantial number of critical obligations are absent or most generated items are unhelpful in independent scenarios.
- **H3 (minimality):** no additional *state-event* primitive is needed to express normal day-to-day design sessions. Falsification: independently collected design moves cannot be represented naturally or faithfully without adding an operation (e.g. stable branch merges with multiple simultaneous accepted designs).
- **H4 (epistemic accuracy):** the evidence vocabulary reduces incorrect promotions of sketches, simulations or model-generated examples to proof. Falsification: an instrumented population of agents/developers still regularly makes such invalid inferences, or the model itself does so.
- **H5 (directions):** top-down, bottom-up, outside-in, inside-out, middle-out, exploratory and evolutionary tasks can share the three-event semantics without direction-dependent exceptions. Falsification: required effects depend on direction and break the core laws.

**Suggested rival:** baseline graph/spec editor supporting arbitrary edits + comments + tests, plus a basic proposal/review workflow. Use identical tasks, time boxes, access to oracles and usability constraints. Compare: detection latency of contradictions, silent parent rewrites, spurious claims of proof, ability to explain stale evidence, number of undecided or unsupported assertions, amount of manual ceremony and time to first independent tracer. Do not declare superiority until this experiment runs.

**Independent scenarios to solicit:** a real feature change across two services, a concurrency or latency-driven decomposition, a security boundary refactor, a backend swap under a hard guarantee, a rollback with irreversible operational effects, simultaneous branch edits, and a code-first reverse-engineered design. At least one scenario should be deliberately hostile to the M3 assumptions.

## Limits and unresolved decisions

- The Python machine is mutable with defensive snapshot copies; it is **not** an immutable, crash-consistent, cryptographically audited event store.
- Report `origin` is a human/agent assertion, not authenticated identity or cryptographic source provenance. The public method prevents an obvious source/method inconsistency and privileged evaluator impersonation, not all fabricated evidence.
- Authority is represented by a caller-supplied `authorized=True` flag, not a security authorization system. It demonstrates separation, not secure access control.
- Reports tie to a global design digest; a production evaluator must additionally bind to evaluator implementation and semantic-profile versions, completeness declarations, configuration and environment.
- `Component.provides` is a nominal set of advertised labels. In the code, `provides_complete` means **the list is complete for the advertised nominal fragment**, not a closed-world assertion about system behavior in general.
- The behavior model is deliberately narrow: no concurrency, exceptions, effects, time, probability, fairness, divergence, true assumption/guarantee checking, compositional model checking, or satisfiability.
- A real model of responsibility allocation, quality trade-offs, social negotiation, or collaborative decision-making may need additional entities and actions.
- Evidence dependency completeness is unknown; selective freshness invalidation is intentionally not implemented.
- There are no persistent parallel accepted branches, merges, undo of external side effects, proof-carrying transformations, rule-versioned evaluators, or actual rendering.
- `Specodelic` and `Wanna` source archives were context inputs. This report does not claim their APIs are compatible with these example records or that any plugin/pack has been compiled or linted.
- Source Git commit IDs are **UNKNOWN**, and all provenance to uploaded ZIPs is archival, not Git attestation.

## Minimum next deliverable for M4

Choose one narrowly scoped *assume/guarantee contract profile*, rather than generalizing category theory further. In that profile, formalize environment assumptions, provider guarantees, observable actions and effects; implement a sound-within-fragment composition check and at least one meaningful simulation/counterexample; include independent cases and one actual tool adapter. Specify evaluator competence as versioned data. If a task requires a fourth semantic event constructor, document the irreducibility with an explicit counterexample before adding it.
