import unittest
from design_semantics_m2 import (DesignSituation,Component,Judgment,PartialBehavior,bounded_trace_inclusion)

class DesigningSemanticsTests(unittest.TestCase):
    def new_world(self):
        w=DesignSituation()
        w.propose('a','add',Component('processor',requires=frozenset({'atomic_write'})))
        w.commit('a',authorized=True)
        w.propose('b','add',Component('storage',provides=frozenset({'eventual_write'})))
        w.commit('b',authorized=True)
        return w

    def test_proposal_does_not_modify_design(self):
        w=DesignSituation(); d=w.semantic_digest()
        w.propose('a','add',Component('a'))
        self.assertEqual(w.semantic_digest(),d)

    def test_rejection_does_not_modify_design(self):
        w=DesignSituation(); w.propose('a','add',Component('a'))
        w.reject('a'); self.assertNotIn('a',w.components)
        with self.assertRaises(ValueError): w.commit('a',authorized=True)

    def test_commit_requires_explicit_authority(self):
        w=DesignSituation(); w.propose('a','add',Component('a'))
        with self.assertRaises(PermissionError): w.commit('a')
        self.assertNotIn('a',w.components)

    def test_stale_proposal_does_not_overwrite(self):
        w=DesignSituation(); w.propose('old','add',Component('old'))
        w.propose('new','add',Component('new')); w.commit('new',authorized=True)
        with self.assertRaises(ValueError): w.commit('old',authorized=True)
        self.assertNotIn('old',w.components)

    def test_binding_surfaces_bottom_up_conflict(self):
        w=self.new_world(); w.propose('bind','bind','processor','storage'); w.commit('bind',authorized=True)
        o=w.obligations['compat:processor->storage']
        self.assertEqual(o.result,'mismatch')
        self.assertIn('atomic_write',o.reason)
        self.assertEqual(w.components['processor'].requires,frozenset({'atomic_write'}))

    def test_explicit_contract_revision_resolves_only_toy_check(self):
        w=self.new_world(); w.propose('bind','bind','processor','storage'); w.commit('bind',authorized=True)
        w.propose('rev','revise','storage',(),('atomic_write',)); w.commit('rev',authorized=True)
        self.assertEqual(w.obligations['compat:processor->storage'].result,'syntactically_satisfied')

    def test_decomposition_creates_open_refinement_obligation(self):
        w=DesignSituation()
        for c in ('payment','authorize','capture'):
            w.propose('add_'+c,'add',Component(c));w.commit('add_'+c,authorized=True)
        w.propose('split','decompose','payment',('authorize','capture'))
        w.commit('split',authorized=True)
        self.assertEqual(w.obligations['refine:payment'].result,'open')

    def test_evidence_is_revision_sensitive(self):
        w=self.new_world()
        w.record_judgment(Judgment('j','compatibility','consistent','toy_check','model_generated',(('storage',1),),'capability-set'))
        self.assertEqual(w.judgment_status('j'),'consistent')
        w.propose('change','revise','storage',(),('atomic_write',));w.commit('change',authorized=True)
        self.assertEqual(w.judgment_status('j'),'stale')

    def test_transitive_evidence_stale_on_provider_change(self):
        w=self.new_world()
        w.propose('bind','bind','processor','storage');w.commit('bind',authorized=True)
        w.record_judgment(Judgment('j','processor','consistent','toy_check','model_generated',(('processor',1),),'toy composition'))
        w.propose('change','revise','storage',(),('atomic_write',));w.commit('change',authorized=True)
        self.assertEqual(w.judgment_status('j'),'stale')

    def test_new_binding_invalidates_prior_processor_evidence(self):
        w=self.new_world()
        w.record_judgment(Judgment('j','processor','consistent','toy_check','model_generated',(('processor',1),),'toy composition'))
        w.propose('bind','bind','processor','storage');w.commit('bind',authorized=True)
        self.assertEqual(w.judgment_status('j'),'stale')

    def test_invalid_commit_is_atomic(self):
        w=self.new_world(); before=(w.semantic_digest(),w.revision)
        w.propose('bad','bind','processor','nonexistent')
        with self.assertRaises(ValueError):w.commit('bad',authorized=True)
        self.assertEqual((w.semantic_digest(),w.revision),before)
        self.assertEqual(w.proposals['bad'].status,'pending')

    def test_view_relayout_preserves_semantic_digest_and_evidence(self):
        w=self.new_world()
        w.record_judgment(Judgment('j','c','consistent','toy_check','model_generated',(('storage',1),),'x'))
        digest=w.semantic_digest();rev=w.revision
        w.layout('move node 100px')
        self.assertEqual((w.semantic_digest(),w.revision,w.judgment_status('j')),(digest,rev,'consistent'))

    def test_generated_cases_cannot_claim_independent_oracle(self):
        w=self.new_world()
        with self.assertRaises(ValueError):
            w.record_judgment(Judgment('j','x','consistent','independent_oracle','model_generated',(),'finite fixture'))

    def test_absence_is_unknown_and_explicit_denial_forbidden(self):
        b=PartialBehavior(frozenset({('Created','pay','Paid')}),frozenset(),frozenset())
        self.assertEqual(b.classify('Cancelled','ship'),'underspecified')
        b=PartialBehavior(b.positive,frozenset({('Cancelled','ship')}),frozenset())
        self.assertEqual(b.classify('Cancelled','ship'),'forbidden_in_scope')

    def test_conflicting_pos_and_neg_not_erased(self):
        b=PartialBehavior(frozenset({('Cancelled','ship','Shipped')}),frozenset({('Cancelled','ship')}),frozenset())
        self.assertEqual(b.classify('Cancelled','ship'),'conflict')

    def test_observation_refinement_good_bad_and_unknown(self):
        abstract={'Requested':(('pay','Paid'),)}
        concrete={'Requested':(('authorize','Authorized'),),'Authorized':(('capture','Paid'),)}
        self.assertEqual(bounded_trace_inclusion(abstract,concrete,{'authorize':None,'capture':'pay'},depth=3)[0], 'no_counterexample_within_bound')
        bad={**concrete,'Paid':(('ship','Shipped'),)}
        self.assertEqual(bounded_trace_inclusion(abstract,bad,{'authorize':None,'capture':'pay','ship':'ship'},depth=3), ('refuted',('pay','ship')))
        self.assertEqual(bounded_trace_inclusion(abstract,concrete,None,depth=3)[0],'unknown')

if __name__ == '__main__':unittest.main(verbosity=2)
