---
title: "M2 — Operational semantics of software designing: candidate and executable validation"
date: "2026-10-11"
model: "OpenAI GPT-6"
prov:wasGeneratedBy: "Analysis of user-provided design archives and self-contained local Python fixture"
prov:wasAttributedTo: "OpenAI GPT-6"
prov:used:
  - "software-design-substrate-2026-10-11(3).zip"
  - "categorical-design-substrate-2026-10-11(1).zip"
  - "specodelic-main(2).zip"
  - "wanna-main(1).zip"
  - "semantic_model_context_evaluation_2026-10-11.md"
source_git_commits: "UNKNOWN: the uploaded archives do not establish Git HEAD revisions"
status: "DESIGN PROPOSAL + 16 EXECUTED TOY TESTS; not a production design kernel or formal proof"
---

# TL;DR

**Hypothesis M2:** Software *designing* is a revisable, history-preserving process of introducing candidate commitments, transforming them under explicit rules, and gathering scoped evidence about the resulting design. It is not reducible to graph editing, proof searching, requirements approval, or implementation. A good semantic model separates (1) what a proposed system does, (2) what its designer has committed to, (3) what remains uncertain, (4) the alternatives and transformations being considered, and (5) what has actually been established by evidence.

**Initial validation:** A deliberately limited Python reference machine and 16 unit tests ran successfully in this session. They validate core *operational distinctions* (propose versus commit; conflict versus silent rewrite; decomposition versus refinement; scoped evidence and invalidation; geometry versus meaning). They do **not** validate the model's empirical adequacy for human design work, its cross-language expressive power, integration with Specodelic/Wanna, or any general formal theorem.

**Recommended next focus:** Specify design commitments and obligations rigorously, with a small typed contract language; then validate design moves against E01–E10 using both toy fixtures and examples provided independently of the model.

## 1. Definitions and boundaries

- **Designed-system semantics:** Interpretation of a candidate software system's behavior, contracts, effects and observable properties.
- **Designing semantics:** Meaning of changes to the design *situation*: proposing, considering, comparing, challenging, decomposing, composing, revising, testing, deciding.
- **Commitment:** A recorded, current design requirement or decision. It may be inconsistent, unimplementable, or insufficiently supported; acceptance is not proof.
- **Proposal:** A hypothetical change not yet part of the committed design. Competing proposals may coexist.
- **Obligation:** A check, question, missing mapping, assumption discharge, or conflict that must be addressed for a *specified claim* to be established. An open obligation is not automatically a contradiction.
- **Judgment:** A scoped outcome of an evaluator or observation, with provenance, assumptions, and dependencies. Judgments may be stale or contradicted; method matters.
- **Design transformation:** A typed operation with preconditions, atomic effects, newly introduced obligations, and evidence impact.
- **Scenario:** Inputs, initial conditions, actions, expected/observed outcomes and provenance. Model-generated scenarios are not independent oracles.

No universal, single Boolean meaning is assigned to 'design is valid'. At least *syntactically formed*, *jointly satisfiable*, *scenario-consistent*, *refinement-supported*, *architecturally compliant under declared assumptions*, *independently validated* and *implemented and exercised* differ.

## 2. Candidate semantic state

Let `W = (D, P, O, J, H)`:

- `D`: current *accepted* design description, including partial typed entities, contracts, assumptions, architecture relations and behavioral declarations. Because it is partial, it need not have a fully defined denotation.
- `P`: proposals/alternatives with base revision, author, status, intended effect and unresolved impact.
- `O`: obligations and conflicts with typed origin, scope, dependencies and possible discharge criteria.
- `J`: judgments and evidence (not synonymous with facts or accepted policy).
- `H`: append-only provenance/events and revision parentage, including discarded alternatives.

A `View` is a projection with its own revision and is not automatically a semantic component of `D`. A runtime/implementation is a source of evidence against `D`, not the source of truth for commitments. A commit may be made without proof; the resulting obligations record what is not yet established.

We propose a semantic interpretation `[[D]]_I` of a sufficiently well-formed `D` in interpretation `I`. If definitions are missing, return `unsupported`/`partial` rather than pretending `[[D]]_I` is total. If `D` expresses an unsatisfiable theory, surface inconsistency independently from a vacuous refinement test.

**Information versus acceptance:** A proposition may have evidence *for* and *against* it simultaneously. An information-oriented classification is `{neither, for-only, against-only, both}`, with evidence lists; it is not automatically a four-valued *truth logic*. Independently, a claim may be proposed, committed, challenged or superseded. Keeping these axes independent prevents 'approved' from being misread as 'true'.

## 3. Semantics of operations

Represent a design operation `a` as a *partial*, guarded transition:

`apply_a : W -> Result[W', effects, new_obligations, affected_judgments]`

The following operations are candidates. An open question is whether each must be primitive or can be derived compositionally; **do not prematurely freeze the API**.

| Move | Intended effect | Obligations/guarantees | Negative case |
|---|---|---|---|
| Externalize / propose | Record optional hypothesis in `P` | No change in accepted `D` | Suggestion silently changes contract |
| Commit | Accept specific proposed delta at expected revision | Requires authority and atomicity; may add obligations | Rejected/stale change applies |
| Decompose | Record parent-child boundary and mapping intention | Creates preservation/refinement obligation | Box split implies behavior proven |
| Compose / bind | Create explicit interface/connection relation | Check advertised capabilities, assumptions, synchronization semantics; surface gaps | Incompatible backend silently relaxes guarantee |
| Constrain | Introduce scoped obligation or exclusion | Determine what is asserted vs merely guessed | Missing action interpreted as forbidden |
| Challenge | Introduce counterexample or conflicting claim | Retain both sides and provenance; require disposition | Negative finding silently discarded |
| Compare | Relate alternatives by explicit criteria/evidence | Uncompared or incomparable results possible | Force a single unqualified ranking |
| Reconcile / revise | Propose then accept chosen resolution | Invalidate affected judgments; retain old claim/history | Parent rewritten automatically to fit implementation |
| Simulate | Generate traces from selected model | Demonstrates *model-internal* possibilities only | Generated cases called independent validation |
| Observe / check | Record method-specific evidence and scope | Cannot promote bounded exploration to universal proof | One test success implies all properties hold |
| Transform view | Change layout/filter only | Preserve semantic identity and existing evidence | Drag movement invalidates system proof |
| Undo / branch | Recover/revise previously accepted decision | Explicit inverse/compensating effect and version history | Delete audit trail; un-apply irreversible effect silently |

A *design move* is not guaranteed to make a system better: it can introduce contradictions, expose contradictions, or trade one quality objective for another. Improvements must be judged against explicit goals and evidence, not by monotonic reduction in the number of obligations.

## 4. Worked E01 example

**Goal:** Processing must rely on a replaceable storage contract requiring `atomic_write`. A candidate backend advertises only `eventual_write`.

1. Propose processor and storage backend: two hypothetical component records. No accepted change yet.
2. Commit both descriptions: two accepted design commitments, not verification of implementability.
3. Bind processor to backend: structural relationship recorded. Contract inclusion in the *toy capability logic* fails (`{'atomic_write'} ⊄ {'eventual_write'}`). The resulting obligation is `mismatch`.
4. The parent processor still requires `atomic_write`: the mismatch does *not* automatically weaken it.
5. A designer can investigate: add an adapter, choose another backend, or explicitly propose relaxing the parent requirement. These are competing alternatives, not interchangeable automatic fixes.
6. If a provider contract is revised to advertise `atomic_write`, the toy inclusion check becomes syntactically satisfied. This **does not** show the backend actually performs atomic writes.
7. Previously recorded evidence dependent on this backend, or on a processor that relies on it, becomes stale under the reference model's declared dependency closure.

### Why this matters

Top-down and bottom-up are *directions of information flow*, not separate modes of correctness. The decisive semantic act is producing a challenge without either discarding the new fact or rewriting an existing commitment without authorization.

## 5. Worked decomposition/refinement example (E02)

`Payment` is decomposed into `Authorize` and `Capture`.

- Merely committing that decomposition creates an **open behavioral refinement obligation**.
- An explicit abstraction map might hide `authorize` and interpret `capture` as `pay`.
- On a finite *closed* transition graph, observable trace inclusion is checkable to a specified depth. A matching depth-bounded fixture returns `no_counterexample_within_bound`, not 'proved equivalent'.
- Adding observable `ship` after `pay` to the concrete graph produces `('pay','ship')` as a counterexample against the chosen abstract graph.
- Omitting the abstraction map yields `unknown`, not pass/fail.
- Under an open-world behavioral description, absence of `Cancelled --ship--> ...` is *underspecification*. Explicit exclusion makes it forbidden within scope. Positive and negative assertions together produce a conflict.

The model needs different refinement notions for safety, liveness, fairness, deadlock/refusal, contextual equivalence or concurrency. This toy test concerns only bounded observable finite traces under its selected graph interpretation.

## 6. Laws to validate

These are proposed kernel acceptance properties, not theorems about all design processes:

| ID | Candidate law | Reference test |
|---|---|---|
| D01 | Proposal alone does not change accepted design | `test_proposal_does_not_modify_design` |
| D02 | Rejected proposal has no semantic effect | `test_rejection_does_not_modify_design` |
| D03 | Commit requires explicit authorization | `test_commit_requires_explicit_authority` |
| D04 | Stale proposal cannot overwrite a newer revision without rebase | `test_stale_proposal_does_not_overwrite` |
| D05 | Invalid commit fails atomically | `test_invalid_commit_is_atomic` |
| D06 | Incompatible binding preserves parent contract and surfaces conflict | `test_binding_surfaces_bottom_up_conflict` |
| D07 | Contract revision may change only the declared toy syntactic compatibility result | `test_explicit_contract_revision_resolves_only_toy_check` |
| D08 | Decomposition is not automatically behavioral refinement | `test_decomposition_creates_open_refinement_obligation` |
| D09 | Evidence becomes stale on direct dependency revision | `test_evidence_is_revision_sensitive` |
| D10 | Transitive provider revision invalidates consumer evidence | `test_transitive_evidence_stale_on_provider_change` |
| D11 | Adding a binding can invalidate existing evidence | `test_new_binding_invalidates_prior_processor_evidence` |
| D12 | Presentation-only changes preserve semantic digest and evidence | `test_view_relayout_preserves_semantic_digest_and_evidence` |
| D13 | Model-generated cases cannot be labeled independent oracles | `test_generated_cases_cannot_claim_independent_oracle` |
| D14 | Absent behavior is unknown unless explicitly excluded/closed | `test_absence_is_unknown_and_explicit_denial_forbidden` |
| D15 | Contradictory positive/negative behavior remains visible | `test_conflicting_pos_and_neg_not_erased` |
| D16 | Bounded inclusion requires a map and can produce counterexamples | `test_observation_refinement_good_bad_and_unknown` |

Execution: `python -m unittest -v test_design_semantics_m2` from the directory containing both `design_semantics_m2.py` and `test_design_semantics_m2.py`. In this session: **16 tests run, 16 passed**. Run output was local, not issued by Specodelic.

## 7. Coverage against the original ten scenarios

| Original scenario | M2 reference coverage | Crucial missing validation |
|---|---|---|
| E01 Top-down/bottom-up conflict | Toy capability inclusion and challenge | Meaningful assumptions/guarantees with adapters and feasibility oracle |
| E02 Semantic zoom/refinement | Open obligation; bounded finite graph inclusion | General mapping/refinement under partial behavior and time |
| E03 Model-only tracer | Partial behavior classifier, small step semantics | Scenario replay/branching over composed model |
| E04 Independent oracle | Provenance guard | Real externally authored examples, experimental independence |
| E05 OCP extension | Not tested | Stable-core impact for a typed extension class |
| E06 Geometry vs semantic | Digest/view regression | Full render, round-trip and schema invariance |
| E07 Implementation tracer | Evidence vocabulary only | Runtime observer, adapter losses, real executable case |
| E08 Interaction/recovery | Authorization, rejection, stale guard | Wanna effect/recovery integration, durable event replay |
| E09 Modularity not shape | Principle only | Typed dependency completeness and anti-coupling policy |
| E10 Model check vs conform | Separate finite check and evidence | Actual Specodelic CLI + distinct independent corpus |

A green test suite for this reference machine **does not imply E01–E10 are solved**.

## 8. Category-theoretic interpretation: useful, not ornamental

- **Objects:** Design situations (or accepted design theories, in a separate category).
- **Arrows:** Accepted, typed design transformations with explicit preconditions and recorded provenance.
- **Composition:** Sequentially compatible accepted transformations; the composite accumulates obligations, effects and evidence impact.
- **Identity:** No-op design transformation. Do not confuse it with a view re-layout (which is a nontrivial workspace edit but semantically identity on the designed theory).
- **Soundness condition:** If an arrow is marked as preservation of a chosen property under specified interpretation, it must actually preserve that property; arbitrary design arrows make no preservation promise.

A category of version-to-version edit histories is straightforward; **that alone proves no software property**. Formal value comes from stating which arrows are *refinements*, which commute with interpretation, and which generate obligations. Institution-based system semantics (M1) can interpret the accepted design `D`. Designing semantics (M2) govern movement between interpretations; some moves cannot be semantically interpreted yet.

More advanced constructs (double categories, indexed categories, lenses, rewrite systems, institutions) should be adopted only if a concrete operation or law demands them. A simpler small-step operational semantics is the reference baseline.

## 9. What we should not treat as primitive yet

- A universal `DesignQuality` scalar: there are multiple conflicting quality objectives; improvement is contextual.
- A universal theorem prover: ordinary requirements, interface assumptions and behavioral traces need different semantic fragments.
- Arbitrary natural-language claims as decidable constraints: interpretation can fail/need user input.
- `Alternative` as merely a node in the accepted system: comparing architectures requires parallel hypothetical branches or deltas.
- `Complete` status for an entire project: closure is scope-specific and can be invalidated by new observations.
- `User approved` as evidence of correctness: authorization and evaluation are orthogonal.

## 10. Unresolved design decisions (deliberately open)

1. **Commitment semantics.** Distinguish normative requirement, architectural choice, empirical fact, assumption, and inferred hypothesis; which kinds can be accepted without independent evidence?
2. **Branch/merge semantics.** Does an alternative exist as a delta over a common base, a full theory branch, or a theory morphism? How are conflicts represented?
3. **Obligation calculus.** Precisely which transformations produce which proof/test/clarification obligations, and what discharges each obligation?
4. **Compositionality.** How do local behavioral judgments compose while preserving soundness, especially with asynchronous effects and shared mutable state?
5. **Knowledge semantics.** Should contradictory evidence be represented with a provenance-indexed information lattice, a paraconsistent logic, or simply immutable separate judgments?
6. **Design success.** Which measurable outcomes demonstrate that this model improves how humans/agents design? Candidate metrics: time to expose contradiction; number of silent assumption changes; time to produce the first falsifiable tracer slice; correct explanation of invalidated evidence.
7. **Integration.** What actual Specodelic export and evaluator contracts preserve this model without conflating syntactic graph relations and architectural semantics? What Wanna event contracts are suitable for revision/authority?

## 11. Integrity limitations

- This is a **candidate semantics**, not a finding that all human design is captured by this state machine.
- Python `Component.requires/provides` uses nominal set inclusion, **not** real assume/guarantee reasoning, protocol subtyping, security/effects or temporal guarantees. An advertised capability is not an observed capability.
- The reference machine records user-supplied `Judgment`s; it is **not a trusted evaluator**. Test results refer to its own rules. Real acceptance requires signed/typed evaluator provenance and declared method capability.
- The reference freshness fingerprint follows only its modeled `consumer -> provider` and `parent -> child` edges. Real dependency extraction must be more comprehensive; missing edges can make evidence invalidation unsound.
- The finite graph trace checker uses a selected initial state, specified observation map and depth bound. It is not general refinement, and absence of a bounded counterexample is not proof.
- The reference machine does not yet persist or replay committed event streams, apply undo transactions, implement full branches, check real language implementations, enforce every OCP policy, or execute Specodelic/Wanna.
- No upstream Git commit, CLI compatibility, third-party independent oracle or empirical human-design study was verified in this session. Marked **UNKNOWN**.

## 12. Provenance and reproduction

Uploaded file SHA-256 (confirmed locally):

- `software-design-substrate-2026-10-11(3).zip`: `54af2c389fb346e6580199b74084365ebef6643473f14b921d92daf3c97a9486`
- `categorical-design-substrate-2026-10-11(1).zip`: `08cbd5752370c17daaa290004df6bdd98d8f11bfe0fea18e884250eab61ecaba`
- `specodelic-main(2).zip`: `040d0f3673adf7fd084d40bb0b03473c9d1548530bad293bf4d7862dd2a1ac69`
- `wanna-main(1).zip`: `aeb3cb57f4f79f33b49141263d3d8d24d433d66a631407b282e89e651a1e9569`

Main source anchors in the uploaded archives:

- `software-design-substrate/DESIGN-ACTIVITY.md` — directions and cognitive acts.
- `software-design-substrate/SCENARIOS.md` — original E01–E10 counterexamples.
- `software-design-substrate/ARCHITECTURE.md` — existing minimal design objects.
- `categorical-design-substrate/SEMANTICS.md` — M1 institution/refinement/evidence boundary.
- `categorical-design-substrate/SPECIFICATION.md` — normative proposed SEM-001–SEM-028.
- `semantic_model_context_evaluation_2026-10-11.md` — prior assessment.

The demonstration does not assert it implements or passes the Specodelic / Wanna source snapshots. The code and tests in this bundle are the entirety of the executed implementation used for the results described above.
