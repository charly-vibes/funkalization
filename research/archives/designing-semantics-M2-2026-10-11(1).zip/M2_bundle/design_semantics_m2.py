"""M2: tiny executable *reference example* of design-activity semantics.

Not a production implementation of Specodelic/Wanna or a general-purpose logic.
The capability-set contracts and finite transition model deliberately have narrow scope.
"""
from dataclasses import dataclass, field, replace
from typing import Any, FrozenSet, Mapping, Optional
from hashlib import sha256
import json


@dataclass(frozen=True)
class Component:
    name: str
    requires: FrozenSet[str] = frozenset()
    provides: FrozenSet[str] = frozenset()
    version: int = 1


@dataclass(frozen=True)
class Proposal:
    id: str
    base_revision: int
    operation: str
    args: tuple
    status: str = "pending"


@dataclass(frozen=True)
class Obligation:
    id: str
    kind: str
    subject: str
    result: str       # open, syntactically_satisfied, mismatch
    reason: str


@dataclass(frozen=True)
class Judgment:
    id: str
    claim: str
    outcome: str     # consistent, refuted, unresolved: NEVER a universal proof
    method: str      # toy_check, scenario, runtime, etc.
    origin: str      # model_generated, independent, implementation
    dependencies: tuple[tuple[str, int], ...]
    scope: str
    context_digest: str = ""


class DesignSituation:
    """Minimal state machine for revision-controlled designing.

    This mutable Python object represents a sequence of immutable snapshots
    conceptually; mutation is confined to explicit operations for this demo.
    """
    def __init__(self) -> None:
        self.components: dict[str, Component] = {}
        self.bindings: set[tuple[str, str]] = set()
        self.decompositions: dict[str, tuple[str, ...]] = {}
        self.proposals: dict[str, Proposal] = {}
        self.obligations: dict[str, Obligation] = {}
        self.judgments: dict[str, Judgment] = {}
        self.history: list[str] = []
        self.revision = 0
        self.view_revision = 0

    def semantic_digest(self) -> str:
        payload = {
            'components': [(n,sorted(c.requires),sorted(c.provides),c.version)
                           for n,c in sorted(self.components.items())],
            'bindings': sorted(self.bindings),
            'decompositions': sorted(self.decompositions.items()),
        }
        return sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()

    def propose(self, id: str, operation: str, *args: Any) -> None:
        if id in self.proposals:
            raise ValueError('proposal id already exists')
        if operation not in {'add', 'bind', 'decompose', 'revise'}:
            raise ValueError('unsupported design operation')
        self.proposals[id] = Proposal(id, self.revision, operation, args)
        self.history.append('proposed '+id)

    def reject(self, id: str) -> None:
        p = self.proposals[id]
        if p.status != 'pending':
            raise ValueError('proposal not pending')
        self.proposals[id] = replace(p, status='rejected')
        self.history.append('rejected '+id)

    def commit(self, id: str, *, authorized: bool = False) -> None:
        p = self.proposals[id]
        if not authorized:
            raise PermissionError('commit needs explicit authorization')
        if p.status != 'pending':
            raise ValueError('proposal not pending')
        if p.base_revision != self.revision:
            raise ValueError('proposal is stale; explicit rebase required')
        op, a = p.operation, p.args
        # Validate all preconditions BEFORE mutating anything.
        if op == 'add':
            (component,) = a
            if not isinstance(component, Component) or component.name in self.components:
                raise ValueError('invalid component insertion')
        elif op == 'bind':
            consumer, provider = a
            if consumer not in self.components or provider not in self.components:
                raise ValueError('unresolved binding endpoint')
            if (consumer, provider) in self.bindings:
                raise ValueError('binding already exists')
        elif op == 'decompose':
            parent, children = a
            if parent not in self.components or any(c not in self.components for c in children):
                raise ValueError('unresolved decomposition endpoint')
            if parent in self.decompositions or len(set(children)) != len(children):
                raise ValueError('ambiguous decomposition')
        elif op == 'revise':
            name, new_requires, new_provides = a
            if name not in self.components:
                raise ValueError('unknown component to revise')
        # Apply: a challenged binding remains visible, not silently corrected.
        if op == 'add':
            self.components[component.name] = component
        elif op == 'bind':
            self.bindings.add((consumer, provider))
        elif op == 'decompose':
            self.decompositions[parent] = tuple(children)
        elif op == 'revise':
            old = self.components[name]
            self.components[name] = replace(old, requires=frozenset(new_requires),
                   provides=frozenset(new_provides), version=old.version+1)
        self.revision += 1
        self.proposals[id] = replace(p, status='accepted')
        self.history.append('committed '+id)
        self.reassess_obligations()

    def reassess_obligations(self) -> None:
        self.obligations.clear()
        for c, p in sorted(self.bindings):
            missing = self.components[c].requires - self.components[p].provides
            key = f'compat:{c}->{p}'
            # This check is syntactic capability inclusion ONLY.
            self.obligations[key] = Obligation(key, 'capability_inclusion', key,
                'mismatch' if missing else 'syntactically_satisfied',
                f"missing={sorted(missing)}" if missing else 'requirements subset of advertised capabilities')
        for parent, children in self.decompositions.items():
            key = f'refine:{parent}'
            self.obligations[key] = Obligation(key, 'behavioral_refinement', parent,
                'open', f'composition, observation map, and preservation evidence required: {children}')

    def _context_digest(self, dependencies: tuple[tuple[str, int], ...]) -> str:
        """Conservative fingerprint: named roots + provider/child closure.

        Real adapters need a typed semantic dependency graph, not just these
        two hardcoded edge categories. A missing relation is a soundness gap.
        """
        roots = {name for name, _ in dependencies}
        visited: set[str] = set()
        frontier = list(roots)
        while frontier:
            name = frontier.pop()
            if name in visited:
                continue
            visited.add(name)
            frontier.extend(p for c, p in self.bindings if c == name)
            frontier.extend(self.decompositions.get(name, ()))
        payload = {
            'roots': sorted(roots),
            'components': [(name, self.components[name].version,
                            sorted(self.components[name].requires),
                            sorted(self.components[name].provides))
                           for name in sorted(visited) if name in self.components],
            'bindings': sorted((c, p) for c,p in self.bindings if c in visited),
            'decompositions': sorted((p, self.decompositions[p]) for p in visited
                                     if p in self.decompositions),
        }
        return sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()

    def record_judgment(self, judgment: Judgment) -> None:
        if judgment.id in self.judgments:
            raise ValueError('judgment already exists')
        if judgment.origin == 'model_generated' and judgment.method == 'independent_oracle':
            raise ValueError('model-generated sample is not an independent oracle')
        if not judgment.scope or judgment.outcome not in {'consistent','refuted','unresolved'}:
            raise ValueError('scope/outcome invalid')
        for name, version in judgment.dependencies:
            if name not in self.components or self.components[name].version != version:
                raise ValueError('evidence does not reference current dependency versions')
        self.judgments[judgment.id] = replace(judgment, context_digest=self._context_digest(judgment.dependencies))

    def judgment_status(self, id: str) -> str:
        j = self.judgments[id]
        if any(name not in self.components or self.components[name].version != version
               for name,version in j.dependencies):
            return 'stale'
        return 'stale' if j.context_digest != self._context_digest(j.dependencies) else j.outcome

    def layout(self, note: str) -> None:
        self.view_revision += 1
        self.history.append('view-only '+note)


@dataclass(frozen=True)
class PartialBehavior:
    """Explicit pos/neg facts; missing != forbidden unless scope closed."""
    positive: FrozenSet[tuple[str,str,str]]
    excluded: FrozenSet[tuple[str,str]]
    closed: FrozenSet[tuple[str,str]]

    def classify(self, state: str, action: str) -> str:
        has_positive = any(s==state and a==action for s,a,_ in self.positive)
        forbidden = (state,action) in self.excluded
        if has_positive and forbidden:
            return 'conflict'
        if has_positive:
            return 'declared_possible'
        if forbidden or (state,action) in self.closed:
            return 'forbidden_in_scope'
        return 'underspecified'


def bounded_trace_inclusion(abstract_steps: Mapping[str,tuple[tuple[str,str], ...]],
                            concrete_steps: Mapping[str,tuple[tuple[str,str], ...]],
                            observation_map: Optional[Mapping[str,Optional[str]]],
                            *, depth: int) -> tuple[str,Optional[tuple[str,...]]]:
    """Tiny CLOSED finite graph checker, not a general refinement proof.

    All actions must be mapped, depth is finite, and deadlock/liveness excluded.
    A null observation is treated as internal/stuttering.
    """
    if observation_map is None or depth < 0:
        return 'unknown', None
    actions = {a for es in concrete_steps.values() for a,_ in es}
    if any(a not in observation_map for a in actions):
        return 'unknown', None
    def traces(graph, initial, translation=None):
        frontier = [(initial,())]
        result = {()}
        for _ in range(depth):
            nxt=[]
            for state,path in frontier:
                for a, dest in graph.get(state, ()):
                    obs = a if translation is None else translation[a]
                    t = path if obs is None else path + (obs,)
                    result.add(t)
                    nxt.append((dest,t))
            frontier=nxt
        return result
    a = traces(abstract_steps, 'Requested')
    c = traces(concrete_steps, 'Requested', observation_map)
    mismatch = sorted(c-a, key=lambda x:(len(x),x))
    return ('refuted',mismatch[0]) if mismatch else ('no_counterexample_within_bound',None)
