---
title: "Categorical semantics for a software design substrate — consolidated specification and design review"
created: "2026-10-11T15:56:43+00:00"
model: "OpenAI GPT-6"
prov:wasGeneratedBy: "Interactive synthesis and local archive inspection; no automated semantic implementation"
prov:used:
  - "user-supplied software-design-substrate-2026-10-11(2).zip"
  - "user-supplied specodelic-main(1).zip"
  - "discussion of M0, M1, packs, extraction, and Rule of 5 review"
prov:wasAttributedTo: "OpenAI GPT-6"
specodelic_source_version: "0.8.0 (Cargo.toml in uploaded ZIP)"
specodelic_source_commit: "UNKNOWN"
baseline_source_commit: "UNKNOWN"
status: "DESIGN PROPOSAL — not implemented, linted or proved"
---
# ADR-001 — Semantic profiles and delayed extraction

**Status:** PROPOSED. **Decision:** Add a semantic contract/evaluator boundary within Specodelic first; extract it to a shared library once its language-neutral API has a second working consumer.

## Alternatives evaluated

| Approach | Advantages | Failure mode | Assessment |
|---|---|---|---|
| Pack-only | Reuse authoring/namespace/dependencies; low initial integration | Declared terms are not interpreted or proved by mere manifest registration | Insufficient **as currently implemented** |
| Direct modification of Specodelic core | Source access, efficient reuse, CLI/report integration | Coupling semantic meaning to Markdown/5-kind schema; increasing core complexity | Good incubation phase |
| Shared kernel extracted immediately | Client-neutral contract for UI/TUI/agents | Premature API and incidental Specodelic assumptions become public | Risky until semantics proven |
| **Incremental typed boundary, then extraction** | Testable mathematical contracts; reuse; postpone package boundaries | Needs deliberate adapter design and validation | **Recommended** |

## Existing source facts

- `src/packs.rs:42–43` states pack checkers ship as declarations with an empty checked-set; messages near `:536` and `:664` confirm this at activation [S1]. The pack vocabulary comprises Sections, Kinds, References, Checkers, Floors, Requires. The manifest does not constitute an arbitrary semantic interpreter.
- `src/acset/schema.rs` holds the closed typed structural schema and reference refinements [S2]. This is a good *structural engine*, not a proof of institution satisfaction or behavioral refinement.
- `src/model_check.rs` distinguishes `exploration_only` and `no_counterexample` [S3].
- `src/conform.rs` implements source-specific external-oracle verdicts and open-world treatment [S4].
- The source declares version `0.8.0`; precise Git commit UNKNOWN [S0].

## Proposed runtime boundaries

```text
Specodelic documents & CLI ───────────┐
Design UI / TUI / AI agents ───────────┤ (later clients)
                                      v
        Presentation-to-theory adapters + traceability
                                      v
                 Semantic contract API
       signatures | interpretations | judgments
                   ^                 ^
                   |                 |
          Semantic packs       Evaluators
        (portable declarations) (bounded/full/etc.)
                   \                 /
                    Typed structural services
                   (existing ACSet where useful)
```

Dependency direction: shared semantic API must never import Markdown, CLI commands, source spans, UI layouts, filesystem discovery or Specodelic `Spec` types. Adapters carry such data separately. A semantic pack refers to stable qualified evaluator capability IDs, checks versions and required trust, and must not silently run untrusted code. A versioned evaluator states support scope, assumptions, proof method, limits, failure conditions and evidence format.

## Pack declaration versus execution

A pack **can** describe a new typed vocabulary and desired semantic obligations. It cannot by declaration alone make a theorem true, solve arbitrary refinement, or guarantee evaluation of prose. Some finite laws may use existing registered predicates; general model/refinement reasoning needs dedicated interpreters/algorithms and sometimes solvers. Pack reference naming is not a satisfaction proof. Capability injection, isolation, authorization, audit and semantics versioning are security boundaries, not just feature plumbing.

### Illustrative manifest sketch — NOT accepted by current pack parser

```yaml
profile: architecture.behavior
semantic_revision: 1
signature: behavior.lts.v1
observation: weak-traces.v1
refinement: trace-inclusion.v1
obligations: [signature_compatible, concrete_satisfiable, traces_preserved]
requires_evaluator: behavior.refinement.v1
judgment_scope: explicit
```

## Extraction candidacy (audit first)

Likely candidates: schema types in `src/acset/schema.rs`, structural instances in `src/acset/instance.rs`, generic traversal in `src/acset/query.rs`, generic predicate interfaces from `src/kernel.rs`, generic judgment outcomes and provenance envelopes from `src/conform.rs` / `src/model_check.rs`. These modules currently contain Specodelic couplings; **do not simply move their files**. Keep `packs.rs` manifest reading, Markdown parsing, source spans, CLI, writer/merge, and Specodelic reports at the application boundary.

## Reversal and migration

Implement an in-process API first with compatibility tests against current graph/lint/conform output. Add a second independent in-memory consumer. Only then extract a crate in the same Rust workspace, preserving semantic identities and serialized evidence. Independent repo/versioning can follow validated cross-project need.
