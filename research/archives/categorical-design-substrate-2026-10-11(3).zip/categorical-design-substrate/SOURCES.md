---
title: "Categorical semantics for a software design substrate — consolidated specification and design review"
created: "2026-10-11T15:56:43+00:00"
model: "OpenAI GPT-6"
prov:wasGeneratedBy: "Interactive synthesis and local archive inspection; no automated semantic implementation"
prov:used:
  - "user-supplied software-design-substrate-2026-10-11(2).zip"
  - "user-supplied specodelic-main(1).zip"
  - "discussion of M0, M1, packs, extraction, and Rule of 5 review"
prov:wasAttributedTo: "OpenAI GPT-6"
specodelic_source_version: "0.8.0 (Cargo.toml in uploaded ZIP)"
specodelic_source_commit: "UNKNOWN"
baseline_source_commit: "UNKNOWN"
status: "DESIGN PROPOSAL — not implemented, linted or proved"
---
# Evidence ledger, assumptions and open questions

## Primary inputs

- **S0** Uploaded `/mnt/data/specodelic-main(1).zip`, SHA-256 `040d0f3673adf7fd084d40bb0b03473c9d1548530bad293bf4d7862dd2a1ac69`; `Cargo.toml` version `0.8.0`; Git commit **UNKNOWN**; archive is not a verified repository checkout. Project: https://github.com/charly-vibes/specodelic
- **S1** Same archive, `src/packs.rs:38–45`, `:54–115`, `:532–543`, `:664`; pack vocabulary and declaration-only empty checked-set.
- **S2** Same archive, `specs/theory.md` and `src/acset/schema.rs`, `src/acset/instance.rs`, `src/acset/query.rs`; structural category and typed instances; extracted subset examined, full build NOT RUN.
- **S3** Same archive, `src/model_check.rs:22–25`, `:95–111`, `:242–248`; exploration-only versus checking status.
- **S4** Same archive, `src/conform.rs`; conformance behavior/labels referred to from the previous analysis; specific command-line execution NOT RUN here.
- **B0** Uploaded `/mnt/data/software-design-substrate-2026-10-11(2).zip`, SHA-256 `54af2c389fb346e6580199b74084365ebef6643473f14b921d92daf3c97a9486`; eight bundled files: baseline `README/ARCHITECTURE/DESIGN-ACTIVITY/REQUIREMENTS/SCENARIOS/SOURCES/VALIDATION/manifest`; Git commit **UNKNOWN**. Original source narrative/provenance remains in `baseline-SOURCES.md`. All ten E01–E10 scenarios and 28 DS requirements retained in `baseline-` files.
- **R1** https://charly-vibes.github.io/incitaciones/content/distilled/pointers/rule-of-5-universal.md (external pointer; direct Markdown fetch unavailable in this run); and https://github.com/charly-vibes/incitaciones/tree/main/skills/review (consolidated method as reported in prior conversation); exact revision and applicability of external checker **UNKNOWN**.
- **T1** Current conversation: user proposals and prior assistant analyses of minimal model, category theory, Specodelic reuse, pack limitations, extraction and Rule-of-5 review. Dialogue is design input, not independent verification.

## Assumptions

1. We are designing a **general-purpose** software-design substrate, not merely a diagram plugin or transition-system DSL.
2. Incomplete drafts are legitimate persistent objects and must not be silently completed.
3. Formal guarantees apply to explicitly declared executable fragments, not arbitrary prose.
4. Category-theoretic institutions are a candidate semantic foundation, not an implementation mandate for every pack.
5. A Rust workspace/in-process adaptation is a plausible migration path for the supplied Rust Specodelic snapshot; it is not yet performance- or ergonomics-validated.
6. Design history and human interaction are important but not all belong in the trusted semantic core.
7. Independent examples are distinguished from model-generated cases; repeated use of one oracle does not create new independent evidence.

## Open questions (all unresolved)

- **Q01:** Which raw partial-graph encoding gives correct functorial laws after validation without losing conflicts?
- **Q02:** What minimal logical fragment should Semantic v1 execute (equations, first-order predicates, temporal properties)?
- **Q03:** How will different signature/theory translators demonstrate institution satisfaction?
- **Q04:** Which behavioral refinements are v1 (trace, simulation, bisimulation, failures/divergence, assume-guarantee)?
- **Q05:** What are the default observation/hiding rules and closed-world boundaries?
- **Q06:** What precise safe extension of current pack manifests is compatible with Specodelic source and CLI behavior?
- **Q07:** Which evaluator execution trust model (linked Rust, WASM sandbox, subprocess, remote proof service) is acceptable?
- **Q08:** What constitutes strong evidence versus sampled tests for a specific user-visible guarantee?
- **Q09:** What change impact model is sound for cross-pack dependent judgments?
- **Q10:** When does another UI/TUI client justify crate extraction, and what public API should stabilize?
- **Q11:** Which exact Git SHAs/releases correspond to provided ZIP archives?
- **Q12:** Can E01–E10 run against an actual `spk` binary without additional semantic extension, and if not which exact operations are unsupported?
- **Q13:** What quantitative performance limits and false-positive budgets are acceptable?
- **Q14:** Which semantic requirements should become native Specodelic `Intent/Constraints/Model/Properties` specs, versus pack-side vocabulary and executable evaluators?

## Integrity policy

Use `VERIFIED SOURCE FACT` only for file content actually inspected, `MATHEMATICAL DEFINITION` for adopted semantics, `PROPOSAL` for new architecture/features, `EXPECTED` for unrun acceptance outcomes, and `UNKNOWN` for unavailable evidence. Cite S/B/R identifiers above. No assertion of source checkout, test execution, syntax validity of conceptual snippets or proof certification without new evidence.
