---
title: "Categorical semantics for a software design substrate — consolidated specification and design review"
created: "2026-10-11T15:56:43+00:00"
model: "OpenAI GPT-6"
prov:wasGeneratedBy: "Interactive synthesis and local archive inspection; no automated semantic implementation"
prov:used:
  - "user-supplied software-design-substrate-2026-10-11(2).zip"
  - "user-supplied specodelic-main(1).zip"
  - "discussion of M0, M1, packs, extraction, and Rule of 5 review"
prov:wasAttributedTo: "OpenAI GPT-6"
specodelic_source_version: "0.8.0 (Cargo.toml in uploaded ZIP)"
specodelic_source_commit: "UNKNOWN"
baseline_source_commit: "UNKNOWN"
status: "DESIGN PROPOSAL — not implemented, linted or proved"
---
# Normative draft specification (not native Specodelic syntax)

Each `SEM-*` item is a **proposed SHALL**, not a statement of present functionality. Tests define an oracle and negative case.

| ID | Requirement / SHALL | Falsifiable check |
|---|---|---|
| SEM-001 | Preserve raw incomplete presentations without fabricating missing facts | Dangling edge round-trips and remains unresolved |
| SEM-002 | Validate before treating raw instances as lawful typed structures | Invalid source/target produces typed violation |
| SEM-003 | Identify semantic language and version for every theory | Ambiguous signature rejected/unsupported |
| SEM-004 | Preserve satisfaction under declared translations | Same supported sentence evaluation before and after reduction |
| SEM-005 | Permit unsupported logical fragments without false proofs | Prose-only claim yields unsupported/unresolved |
| SEM-006 | Require satisfiability assessment or explicit unknown before usable model-set refinement | Contradictory concrete theory never passes as success |
| SEM-007 | Require explicit abstraction/observation maps for cross-level refinement | Similar state names without mapping do not pass |
| SEM-008 | Select and record composition operator and synchronization rules | Same components with different operator produce distinct judgment metadata |
| SEM-009 | Check compatibility of shared interface semantics | Name collision or conflicting interpretation rejected |
| SEM-010 | Keep safety and liveness/refusal/fairness guarantees distinct | Trace-inclusion proof not labeled universal equivalence |
| SEM-011 | Preserve open/closed-world scope | Absent transition is not forbidden by default |
| SEM-012 | Preserve contradictions as explicit conflicts | Positive and negative declarations produce conflict |
| SEM-013 | Maintain typed evaluator capability IDs and semantic versions | Unknown evaluator cannot return verified |
| SEM-014 | Record scope, method, bounds, assumptions and trust for judgments | Bounded run not displayed as complete proof |
| SEM-015 | Preserve provenance and independence of evidence | Model-generated sample cannot masquerade as external oracle |
| SEM-016 | Invalidate dependent evidence after semantic mutation | Changed referenced contract marks affected evidence stale |
| SEM-017 | Distinguish semantic edits from presentation edits | Moving node does not change theory digest |
| SEM-018 | Preserve proposed/rejected changes and require human authority for committed edits | Reject leaves accepted model unchanged |
| SEM-019 | Keep structural, theory and behavioral composition separate | Pushout success cannot produce behavioral pass alone |
| SEM-020 | Support runtime observation adapters with loss reports | Unmappable runtime event remains unclassified |
| SEM-021 | Define scoped OCP and dependency policies | Stable core change on declared extension is surfaced |
| SEM-022 | Permit language-neutral models and model checking before implementation | E03 runs without application code |
| SEM-023 | Support tests from independent authored oracles | E04 shows different provenance and mismatch status |
| SEM-024 | Never infer architectural modularity from geometry only | E09 has unresolved dependency completeness |
| SEM-025 | Maintain backwards-compatible behavior for current Specodelic clients | Golden parity tests across integration changes |
| SEM-026 | Prevent semantic packs from silently redefining shared symbols | Same symbol/different semantics produces conflict |
| SEM-027 | Separate declaration from evaluator execution and authorization | Untrusted evaluator cannot execute implicitly |
| SEM-028 | Allow inspectable counterexamples and negative cases | E02 invalid mapping yields trace/counterexample when algorithm supports it |

## Conceptual API protocol — NOT existing Rust signatures

```text
parse_presentation(raw) -> RawPresentation
validate(raw, schema) -> ValidationResult<ValidatedInstance>
interpret(validated, semantic_profile) -> InterpretationResult | Unsupported
translate(signature_map, sentences, models) -> SatisfactionLawObligations
compose(inputs, operator, contracts) -> ModelOrObligations
assess(obligation, evaluator, scope, revision) -> Judgment
invalidate(old_digest, changed_dependencies) -> Set<StaleJudgmentId>
```

Every `Judgment` MUST include the subject claim ID, theory/model digest, evaluator semantics/version, outcome, completeness/bounds, assumptions, relevant evidence origin, timestamp and trust classification. Whether a concrete proof object is present is an additional field; absence must not be represented as proof.

## Acceptance harness

- A positive fixture, counterexample and incomplete fixture per semantic capability.
- A source-to-adapter round trip that reports semantic losses, if any.
- Distinct evidence types for `model_generated`, `independent_example`, `implementation_observed`, `formal_oracle`.
- Property and differential tests for composition laws and signature-translation satisfaction.
- Deterministic result equality for identical semantics/evaluator revisions and inputs, allowing only explicitly nondeterministic evidence metadata to vary.

No fixtures here are claimed executed.
