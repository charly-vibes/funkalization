---
title: "Categorical semantics for a software design substrate — consolidated specification and design review"
created: "2026-10-11T15:56:43+00:00"
model: "OpenAI GPT-6"
prov:wasGeneratedBy: "Interactive synthesis and local archive inspection; no automated semantic implementation"
prov:used:
  - "user-supplied software-design-substrate-2026-10-11(2).zip"
  - "user-supplied specodelic-main(1).zip"
  - "discussion of M0, M1, packs, extraction, and Rule of 5 review"
prov:wasAttributedTo: "OpenAI GPT-6"
specodelic_source_version: "0.8.0 (Cargo.toml in uploaded ZIP)"
specodelic_source_commit: "UNKNOWN"
baseline_source_commit: "UNKNOWN"
status: "DESIGN PROPOSAL — not implemented, linted or proved"
---
# TL;DR

**Decision recommended:** Use Specodelic as a first-class authoring, inspection, checking and evidence client; extend it with **typed semantic profiles** (packs) and independently versioned evaluators; specify a minimal semantics contract *before* extracting shared Rust crates. Retain Specodelic's five-kind structural vocabulary and ACSet-like machinery where useful, but do not confuse typed graph validity with architectural meaning, program behavior or formal proof. Establish a second consumer of the semantic API before extracting it into a shared kernel. Target architecture: **open semantic vocabulary, small trusted contract, explicitly scoped judgments**.

**Why:** Existing packs declare Sections/Kinds/References/Checkers/Floors/Requires, but in the supplied Specodelic snapshot checkers are declarations with an *empty checked-set*, not a general semantic evaluator. The native model checker distinguishes `exploration_only` from `no_counterexample`. A new interpretation/satisfaction contract is necessary for refinement, compositional behavior and cross-paradigm semantics; writing a pack manifest cannot itself establish these laws. [S1–S4]

**Critical limits:** This dossier defines a *candidate* formal design and acceptance specification, **not an implemented feature** or a verified mathematical proof. The uploaded ZIP is labeled Specodelic 0.8.0 by `Cargo.toml`; repository Git commit is **UNKNOWN**. No `cargo test`, `spk lint`, `spk conform`, executable refinement checker, or third-party Rule-of-5 validator was run for this bundle.

## Reading map

1. **[SEMANTICS.md](SEMANTICS.md)** — definitions, mathematical layers, equations, laws, partiality and refinement.
2. **[ARCHITECTURE-DECISION.md](ARCHITECTURE-DECISION.md)** — three implementation alternatives; why packs alone are insufficient; extraction strategy.
3. **[SPECIFICATION.md](SPECIFICATION.md)** — normative draft obligations, interfaces, verifiable requirements.
4. **[SCENARIO-MATRIX.md](SCENARIO-MATRIX.md)** — E01–E10 semantic mapping, oracle, negative test and caveats.
5. **[RULE-OF-5.md](RULE-OF-5.md)** — five review passes, corrections, convergence status.
6. **[RESEARCH-PLAN.md](RESEARCH-PLAN.md)** — vertical implementation path and evidence gates.
7. **[SOURCES.md](SOURCES.md)** — source anchors, provenance, assumptions, UNKNOWN register.
8. **`baseline-*.md`** — original uploaded software-design-substrate corpus, preserved unchanged for traceability. **`manifest.json`** — file hashes, sizes and origins.

## Glossary

- **Design substrate:** a persistent, revisable system for expressing and testing claims about a software design, rather than a diagram editor.
- **Signature (Σ):** typed vocabulary of symbols, operations and relations in which claims are formulated.
- **Theory (T):** signature plus propositions/constraints; its models are possible interpretations that satisfy those claims.
- **Model (M):** mathematical interpretation of the vocabulary, not necessarily executable source code.
- **Institution:** a formal apparatus relating signatures, sentences, models and a satisfaction relation in a translation-consistent way.
- **Satisfaction (⊨):** a model makes a sentence true under a specified semantics.
- **Category:** objects and composable arrows with associative composition and identity arrows.
- **Functor:** structure-preserving assignment between categories.
- **Natural transformation:** compatible family of maps between functors.
- **(Co)presheaf:** functor from a small category (or its opposite) to sets; a foundation for typed structural data.
- **ACSet:** attributed categorical set, a typed finite structural instance of a categorical schema.
- **Coalgebra:** mathematical structure specifying how a state reveals observations and evolves, useful for behavioral semantics.
- **Refinement:** a *scoped* relationship by which concrete models meet abstract obligations under an explicit translation/observation mapping.
- **Trace:** a sequence of externally relevant actions/observations.
- **Judgment:** assessed proposition with model revision, method, scope, assumptions and evidence.
- **Semantic pack/profile:** declarative domain vocabulary, laws and obligations referring to registered semantic capabilities.
- **Evaluator:** a separately implemented checker with a documented soundness/completeness envelope; not synonymous with a pack.
- **Open-world:** missing declarations are not presumed false/forbidden.
- **Closed-world:** completeness is explicitly declared for the relevant scope.
- **Tracer bullet:** deliberately thin, working end-to-end implementation slice; model-only simulation is a different kind of evidence.
- **OCP:** Open/Closed Principle: specified extensions need not modify a designated stable core, subject to a declared change class.
- **UNKNOWN:** unavailable or unverified evidence, not false.

## Scope

Cover design activity (top-down, bottom-up, middle-out, outside-in), progressive sketches, modularity, behavior, hierarchy, alternatives, model-only and implemented tracer slices, design simulation, external-oracle conformance, human authorization, diagram/view separation, and portability across languages/paradigms. The goal is to support all ten baseline scenarios **without claiming that merely storing a representation ensures it**.

## Non-goals

No categorical theorem prover is claimed. No arbitrary natural-language prose is treated as executable logic. No new diagram syntax or fully trusted plugin loader is specified. No replacement of Specodelic's native document format is required. No assumption that traces alone establish fairness/liveness/contextual equivalence.
