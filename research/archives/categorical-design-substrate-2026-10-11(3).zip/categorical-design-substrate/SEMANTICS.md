---
title: "Categorical semantics for a software design substrate — consolidated specification and design review"
created: "2026-10-11T15:56:43+00:00"
model: "OpenAI GPT-6"
prov:wasGeneratedBy: "Interactive synthesis and local archive inspection; no automated semantic implementation"
prov:used:
  - "user-supplied software-design-substrate-2026-10-11(2).zip"
  - "user-supplied specodelic-main(1).zip"
  - "discussion of M0, M1, packs, extraction, and Rule of 5 review"
prov:wasAttributedTo: "OpenAI GPT-6"
specodelic_source_version: "0.8.0 (Cargo.toml in uploaded ZIP)"
specodelic_source_commit: "UNKNOWN"
baseline_source_commit: "UNKNOWN"
status: "DESIGN PROPOSAL — not implemented, linted or proved"
---
# Candidate semantic kernel (M1)

## 1. Three levels of meaning

**Structural presentation:** typed entities, relations, constraints, references, and possibly incomplete links. **Logical theory:** what those declarations assert and which models satisfy them. **Evidence:** what a specified checking method has established for one model/version/scope. Layout and interaction are separate workspace projections. These layers must not silently collapse.

A *presentation* P may be raw/incomplete. A validated structural model V is obtained only after checking typing, reference integrity and applicable structural laws. A typed finite graph does not by itself entail component modularity or correct behavior.

## 2. Institution-based logical core

An institution is a tuple `I = (Sig, Sen, Mod, ⊨)`:

- `Sig`: category of typed signatures; `σ: Σ → Σ′` is a translation of vocabulary.
- `Sen: Sig → Set`: sentences over each signature with translation `Sen(σ)`.
- `Mod: Sig^op → Cat`: each signature has a category of models; `Mod(σ)` reduces a model over Σ′ to Σ.
- `⊨_Σ`: satisfaction between Σ-models and Σ-sentences.

**Obligatory satisfaction condition:** for every eligible σ, sentence φ and Σ′-model M′:

`M′ ⊨_{Σ′} Sen(σ)(φ)  iff  Mod(σ)(M′) ⊨_Σ φ`.

A theory `T=(Σ, Γ)` is a signature with a set of sentences. Its model class is `⟦T⟧ = { M in Ob(Mod(Σ)) | ∀φ in Γ, M ⊨_Σ φ }`. An incomplete *presentation* of a theory is distinct from a complete declared set of its axioms: missing facts should remain epistemically unknown where the selected logic requires that distinction. Not all natural-language requirements belong to an executable `Sen(Σ)` fragment; unsupported translations stay unsupported.

### Semantic portability

Portability across programming languages/paradigms is obtained through explicit interpretation/reduct maps satisfying the above condition (and relevant operation contracts), **not** merely from category-theory terminology or shared serialization. Where the condition cannot be established, mark the mapping unsupported or its result provisional.

## 3. Structural base and partial information

The uploaded Specodelic source documents a finite category with kinds `Intent`, `Constraint`, `State`, `Transition`, `Property`; it builds structural instances using ACSet-like representations [S1–S2]. Let K be the schema category. Covariant `K → Set` and presheaf `K^op → Set` are distinct formulations over K; switching variance requires explicitly reversing the indexing category. Do not casually assert equivalence over an unchanged K.

Raw input may have unresolved targets, collisions and not-yet-typed relations. Candidate designs should retain those facts as data. `RawPresentation → validation result → ValidatedInstance` is an explicit boundary; do **not** assert that dirty raw instances are lawful total Set-valued functors. Possible encodings (partial maps, typed relations, option-lifting) are OPEN QUESTIONS and should be experimentally compared.

## 4. Refinement and translations

For the *same signature*, one candidate safety-oriented refinement is `T_A ⪯ T_C iff ⟦T_C⟧ ⊆ ⟦T_A⟧`. This is insufficient alone: an inconsistent concrete theory has no models and vacuously satisfies inclusion; therefore require separate satisfiability or report `inconsistent` rather than usable refinement.

Across signatures, given `σ: Σ_A → Σ_C`, require `Mod(σ)(⟦T_C⟧) ⊆ ⟦T_A⟧` in the chosen model class, with declared assumptions, observations and satisfiability checks. A structural parent-child or traces-to edge alone is *not* such a proof.

A behavioral refinement may instead use observable-trace inclusion: `Traces_obs(C) ⊆ Traces(A)` under a declared observation map and treatment of internal/stuttering actions. This preserves only the properties justified by that specific semantic relation; fairness, divergence, deadlock, refusal and liveness may require stronger refinement notions.

## 5. Behavior as one semantic interpretation

A simple nondeterministic labeled transition system uses states S, actions A, initial states I, an observation map O, and relation `→ ⊆ S × A × S`. It can be presented coalgebraically, e.g. `c: S → O × (P(S))^A` for a chosen finite/powerset interpretation. This is *not* the universal model of software: actors, processes, reactive systems, functional semantics and dataflow may demand other interpreters.

**Partial knowledge is first class:** record (a) positively declared transitions, (b) explicitly excluded behavior, (c) the local completeness/closed-world declaration. If `Cancelled --ship--> ?` is absent, do not call it forbidden without applicable closure/prohibition. Positive/negative declarations can conflict; contradictions must be surfaced rather than overwritten.

## 6. Component composition

Composition has three independent layers: `structural` combination (typed signatures/relations), `theory` combination (sentences and satisfiability), and `behavioral` composition (explicit synchronization, hiding, interleaving, message exchange or another named operator). A cospan `A ← I → B` and its pushout `A +_I B` may combine compatible *structural* descriptions if it exists; it does not prove behavioral compatibility, safe substitution or global liveness.

Define *modularity* relative to a declared system boundary, its permitted dependencies and change scenarios. Define *OCP* relative to an extension class and stable designated core. Never infer either from visual grouping alone.

## 7. Judgments and evidence

A judgment record is conceptually `J=(claim, theory/model identity, revision/digest, evaluator+version, verdict, scope, assumptions, evidence, trust/provenance)`; fields are illustrative, not current Specodelic JSON syntax.

Independent axes include: truth finding (established/refuted/unresolved), support (supported/unsupported), knowledge (underspecified/complete/contradictory), evaluation method (simulation/bounded model check/complete decision/proof/runtime test), evidence origin (model-generated/human-authored/external observed), and trust level. Retain Specodelic `permitted`, `forbidden`, `underspecified`, `unknown`, `unsupported` for conformance where relevant rather than flattening these into a universal truth enum [S4]. `exploration_only` must never be promoted into property proof [S3].

## 8. Design activity and time

Versioned proposals, accepted changes, rejected alternatives, revisions and view geometry are workspace concerns. Semantic change operations are typed transformations with preconditions and obligations. Geometry-only changes must preserve the digest/identity of the underlying semantic theory. Runtime observation adapters must map actual implementation events to the declared model vocabulary and report mapping losses. Human approvals are workflow commitments, not categorical axioms.

## 9. Boundary laws to verify

**L1** identity/composition laws for typed morphisms; **L2** satisfaction preserved under signature translation; **L3** every accepted refinement has explicit assumptions, scope and non-vacuity treatment; **L4** composition declares its operator and checks interface compatibility; **L5** absent evidence never entails truth; **L6** version-changing edits invalidate affected judgments; **L7** presentation-only transformations preserve semantic interpretation; **L8** an evaluator can report inability to decide; **L9** all generated scenario evidence retains origin; **L10** additional semantic profiles cannot silently redefine established symbols.

These are **proposed laws and acceptance obligations**, not empirically proven laws of the existing tool.
