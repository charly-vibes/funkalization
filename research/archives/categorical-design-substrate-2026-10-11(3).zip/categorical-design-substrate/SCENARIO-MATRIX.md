---
title: "Categorical semantics for a software design substrate — consolidated specification and design review"
created: "2026-10-11T15:56:43+00:00"
model: "OpenAI GPT-6"
prov:wasGeneratedBy: "Interactive synthesis and local archive inspection; no automated semantic implementation"
prov:used:
  - "user-supplied software-design-substrate-2026-10-11(2).zip"
  - "user-supplied specodelic-main(1).zip"
  - "discussion of M0, M1, packs, extraction, and Rule of 5 review"
prov:wasAttributedTo: "OpenAI GPT-6"
specodelic_source_version: "0.8.0 (Cargo.toml in uploaded ZIP)"
specodelic_source_commit: "UNKNOWN"
baseline_source_commit: "UNKNOWN"
status: "DESIGN PROPOSAL — not implemented, linted or proved"
---
# E01–E10 categorical acceptance matrix

The exact original scenarios and supporting DS requirement IDs are in [baseline-SCENARIOS.md](baseline-SCENARIOS.md) and [baseline-REQUIREMENTS.md](baseline-REQUIREMENTS.md). This matrix gives the *new* semantic obligations. All outcomes below are **expected**, not tested.

| Scenario | Semantics and proposed operator | Pass oracle | Adversarial/negative oracle |
|---|---|---|---|
| E01 top-down/bottom-up conflict | Theory revision, typed contracts, conflict relation | Atomic-storage limitation challenges parent obligation without auto-changing it | Parent silently rewritten = fail |
| E02 semantic zoom | Signature morphism, observation abstraction, trace/refinement | Valid mapping preserves declared observable traces | Similar labels without mapping, extra externally visible behavior, or inconsistent concrete theory cannot pass |
| E03 model tracer | Partial transition/coalgebraic model | `Created-pay→Paid`, `Created-cancel→Cancelled`, `Paid-refund→Refunded` replay at model level | `Cancelled-ship` absent is underspecified absent prohibition/closure; evaluator-specific verdict UNKNOWN until run |
| E04 independent oracle | Evidence origin and satisfaction judgment | Model-derived tests separated from independently authored refund scenario | Self-generated cases misrepresented as independent validation = fail |
| E05 OCP backend extension | Interface contract and contextual observation relation | Third conforming backend does not modify designated processor core under scoped extension | Backend needs new processor method → challenge OCP obligation |
| E06 diagram vs semantics | Projection/view transformation | Layout-only edit keeps semantic digest stable | Node drag changes contract = fail |
| E07 implementation tracer | Runtime-to-model observation mapping | Real recorded traces plus adapter provenance distinguished from simulated traces | Mocks claimed as implementation evidence = fail |
| E08 human interaction/recovery | Proposed versus accepted morphism, commit authority | Rejected proposal leaves accepted design unchanged, recovery retained | Auto-apply without approval = fail |
| E09 modularity versus grouping | Theory of typed dependency boundaries and declared completeness | Modularity assessed only when dependency evidence adequate | Visual box alone yields no modularity proof |
| E10 model check versus conform | Scope-indexed judgments | Reachable violation survives passing sample corpus | Passing examples erase formal counterexample = fail |

## E02 canonical experimental fixture

Define abstract payment actions (e.g., request, pay, fail), concrete actions (request, authorize, capture, fail), observation/hiding mapping, and initial-state correspondence. Explicitly define whether `authorize` is hidden, whether `capture` projects to `pay`, whether failures may be observable, and what trace completeness is assumed.

Evaluate four branches:

1. **No abstraction map** → unresolved obligation (not equivalence).
2. **Valid mapping and verified inclusion within stated scope** → scoped pass.
3. **Concrete extra observable trace** → counterexample, fail where supported.
4. **Inconsistent concrete theory** → inconsistent/invalid refinement, not vacuous pass.

Do not claim one correct event abstraction before specifying what a payment represents in this domain; expected laws are dependent on those semantics.

## Cross-scenario traceability

The corpus preserves all original 28 DS requirements unchanged. SEM-001/002/011/012 support E01/E03; SEM-004/006/007/010/028 support E02; SEM-014/015 support E04/E10; SEM-008/009/019/021 support E05/E09; SEM-016/017/018 support E06/E08; SEM-020/022/023 support E07 and the tracer workflow. This mapping is descriptive and not an exhaustive automatically verified requirements graph.
