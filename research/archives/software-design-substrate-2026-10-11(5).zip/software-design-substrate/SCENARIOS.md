---
title: "Worked scenarios and design experiments"
created: "2026-10-11"
model: "OpenAI GPT-6"
provenance_format: "PROV-inspired, descriptive (not formal W3C PROV serialization)"
source_specodelic_commit: "UNKNOWN (archive has no .git metadata; ZIP comment is not verified commit provenance)"
source_wanna_commit: "UNKNOWN (archive has no .git metadata; ZIP comment is not verified commit provenance)"
status: "PROPOSAL — not implemented or lint-certified"
---

# Worked scenarios

Examples describe **desired future behavior**, not tests actually run. Format: context / action / expected observation / counterexample. IDs link to requirements.

## E01 — Greenfield top-down with bottom-up correction

Context: design order service with `Ingestion → Processing → Storage`. Add constraints 'processing must not import concrete storage' and 'storage can be replaced'. Action: implement a model-only save/retrieve vertical scenario, then investigate backend unable to support atomic update. Expected: unresolved contract conflict with alternatives (adapter, alternate backend, relaxed obligation) and no automatic rewrite. Counterexample: silently change parent guarantee. Covers DS-004,009–012.

## E02 — Semantic zoom without false equivalence

Context: abstract `Payment` component is expanded to `Requested → Authorized → Captured` plus failure. Action: zoom into model, relate abstract `Paid` to detailed observations. Expected: explicit abstraction function/trace relation needed; absent mapping flagged UNKNOWN; stuttering internal steps possible. Counterexample: similar-looking arrows counted as a proof of refinement. Covers DS-005,017.

## E03 — Model-only tracer slice and external cases

Context: no code. Model states `Created, Paid, Shipped, Cancelled, Refunded`. Transitions: `pay: Created→Paid`, `cancel: Created→Cancelled`, `ship: Paid→Shipped`, `refund: Paid→Refunded`. Proposed external examples:

| ID | Setup | Trace | Expected model outcome |
|---|---|---|---|
| X-01 | Created | pay | Paid |
| X-02 | Created | cancel | Cancelled |
| X-03 | Paid | refund | Refunded |
| X-04 | Cancelled | ship | Not declared; do not assert `forbidden` by absence under open-world semantics |

Execute graph stepping/model replay, then encode against the **actual** currently supported `spk conform` JSONL oracle schema before calling the CLI. Do not assume this table is valid JSONL syntax. X-04 should expose underspecification unless a concrete executable prohibition covers it. Exact output classification is **UNKNOWN until executed** because evaluator coverage matters. Covers DS-012–017.

## E04 — Model generation is not independent validation

Action: generate traces solely from the model and feed them back as examples. Expected: internal coverage/consistency only, origin recorded `model_generated`; NOT 'matches user requirements'. Add independently authored refund case absent from the model: expected gap/question surfaced. Covers DS-008,015,017.

## E05 — Open/Closed under a concrete change

Context: processor depends on a storage contract, two backends. Action: add third conforming backend. Expected: compute files/contract changes; processor designated core must remain unchanged for this *specified* extension scenario. Negative: add backend requiring new method in core; report OCP challenge rather than universal design failure. Covers DS-009–011,018.

## E06 — Diagram edit versus semantic edit

Action: drag component 100 pixels, then separately change relation from `uses` to `implements`. Expected: drag changes view revision only; relation edit changes semantic revision and may stale evidence. Covers DS-002,003,025.

## E07 — Implementation tracer bullet

Context: E03's `Created → Paid` exists in model; deploy narrow UI/API/storage path. Action: capture observed executable trace, compare against model and oracle. Expected: evidence tagged `implementation` with build/revision/environment; discrepancies have traceable conflicts. Simulated mocked payment is not real payment integration evidence. Covers DS-018,019,027.

## E08 — Human interaction and recovery

Action: AI suggests merging two components; user dismisses; session disconnects then resumes. Expected: dismissal is not approval, merge not applied; current alternatives/provenance preserved; textual interface can perform same approved semantic operation. Covers DS-022–025.

## E09 — Architectural property can't be inferred from a diagram alone

Action: group tightly coupled nodes into a rectangle labeled `modular`. Expected: region is not evidence of low coupling; tool requests actual dependency facts and scoped policy. Covers DS-009,011.

## E10 — Model checking versus conformance

Model allows an undesirable reachable `Paid → Shipped` without authorization guard. A hand-curated corpus tests only `Created → Paid`. Expected: corpus conformance may agree on selected examples while checker can still find model-internal violation; results remain separate. Covers DS-014–017.
