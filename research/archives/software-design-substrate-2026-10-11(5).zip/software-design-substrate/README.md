---
title: "Semantic software design substrate — concept and dossier"
created: "2026-10-11"
model: "OpenAI GPT-6"
provenance_format: "PROV-inspired, descriptive (not formal W3C PROV serialization)"
source_specodelic_commit: "UNKNOWN (archive has no .git metadata; ZIP comment is not verified commit provenance)"
source_wanna_commit: "UNKNOWN (archive has no .git metadata; ZIP comment is not verified commit provenance)"
status: "PROPOSAL — not implemented or lint-certified"
---

# TL;DR

Design a **low-friction graphical and textual substrate** for progressively discovering, describing, simulating, constraining, implementing, and verifying software systems. The core is *the act of designing*, not diagram chasing or any diagram notation. The substrate supports top-down, bottom-up, middle-out, outside-in and evolutionary movement; semantic zoom; reversible decisions; architectural constraints; model-only simulation and independent scenario conformance; and narrow end-to-end tracer bullets connecting design with running software. **Wanna** informs human need/contribution/workflow/presentation separation; **Specodelic** informs formal requirements, typed references, behavior models, model checking and external-oracle conformance. The substrate itself is a proposed addition, **not an existing capability** of those tools.

## How to read

1. [DESIGN-ACTIVITY.md](DESIGN-ACTIVITY.md): descriptive theory of designing, why and how.
2. [ARCHITECTURE.md](ARCHITECTURE.md): proposed semantic representation and interaction architecture.
3. [REQUIREMENTS.md](REQUIREMENTS.md): normative draft requirements and falsifiable acceptance criteria.
4. [SCENARIOS.md](SCENARIOS.md): worked examples, positive/negative cases, model/external evidence.
5. [VALIDATION.md](VALIDATION.md): staged experimental and verification plan.
6. [SOURCES.md](SOURCES.md): provenance, primary-source anchors, audit limits.
7. [manifest.json](manifest.json): machine-readable file inventory and checksums.

## Glossary

- **Design substrate:** a reusable representation and interaction foundation for constructing and reasoning about a system design.
- **Semantic sketch:** incomplete, manipulable design information rather than a fixed diagram type.
- **Semantic zoom:** switching the *abstraction and relevant information*, not only image magnification.
- **Boundary:** an explicitly defined interface or region separating responsibilities.
- **Refinement:** a declared relationship showing how a more detailed design realizes an abstract one; may require proof/evidence.
- **Model:** structured description of possible states, operations, constraints and observations, independent of application implementation.
- **Simulation:** stepping through one or more behaviors admitted by a model; not proof of completeness.
- **Model checking:** systematic exploration of model states/transitions relative to properties, subject to chosen semantics and bounds.
- **Conformance:** classifying externally supplied behavior against what a specification states and its checkers can interpret.
- **Oracle:** independent source of expected or observed behavior, e.g. curated examples or an existing system.
- **Tracer bullet:** narrow, working end-to-end slice providing rapid integration feedback; a **model tracer slice** is our proposed model-only analogue, not equivalent runtime evidence.
- **OCP:** Open/Closed Principle: stable software units should admit specified extensions without modification to a designated core.
- **Provenance:** where a fact, artifact, decision or test result came from and what it actually supports.
- **UNKNOWN:** not verified or not specified; not synonymous with false.

## Scope and non-goals

Included: human design activity, neutral graphical primitives, directional refinement, modularity/OCP as scoped policies, architecture change scenarios, interaction model, model/implementation tracer slices, simulations, examples, conformance, evidence and validation.

Not included as present fact: a working UI, a generic executable design semantics, automatic proof of modularity, formal translation into current `spk` schema, or verified lint-clean generated Specodelic files. Those are targets to implement/test.

## Key principles

1. Start with intention and uncertainty; progressively formalize, do not enforce premature notation.
2. Distinguish **layout**, **design meaning**, **claims**, **observations**, and **authorizations**.
3. Design moves top-down and bottom-up; contradictions must be visible and reconcilable.
4. Encourage modular boundaries and extension points through *explicit, falsifiable policies* rather than dogmatic box-counting.
5. Validate early with narrow model-only traces; connect to running tracer bullets as code appears.
6. No model-generated example may masquerade as independent evidence that the model matches reality.
7. Specification changes must preserve identity, provenance, history and outstanding obligations; no silent semantic loss.
8. Graphical interfaces are representations of a stable semantic model, with accessible text/TUI alternatives.

## Status

This bundle is a **research-informed design proposal** synthesizing the conversation, inspected uploaded source archives, and cited external references. It is not a conformance claim, upstream change, implementation, or proof.
