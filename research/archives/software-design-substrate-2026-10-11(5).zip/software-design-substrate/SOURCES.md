---
title: "Evidence and source ledger"
created: "2026-10-11"
model: "OpenAI GPT-6"
provenance_format: "PROV-inspired, descriptive (not formal W3C PROV serialization)"
source_specodelic_commit: "UNKNOWN (archive has no .git metadata; ZIP comment is not verified commit provenance)"
source_wanna_commit: "UNKNOWN (archive has no .git metadata; ZIP comment is not verified commit provenance)"
status: "PROPOSAL — not implemented or lint-certified"
---

# Source and provenance ledger

## Source archives directly inspected

- S1 Specodelic uploaded ZIP `specodelic-main.zip` SHA-256 `040d0f3673adf7fd084d40bb0b03473c9d1548530bad293bf4d7862dd2a1ac69` — `specs/theory.md`, `specs/graph.md`; theory claims fixed 5-kind schema and typed relationships; graph spec declares derived adjacency/blast-radius checks. Git commit **UNKNOWN**: no `.git` metadata.
- S2 Same ZIP `docs/src/conform.md`, `src/conform.rs`: `spk conform <spec-file> --oracle scenarios.jsonl [--closed-world]`, verdict taxonomy, open-world default and finite corpus evidence scope. Code inspected by file availability, but actual CLI not run in this task.
- S3 Same ZIP `src/model_check.rs`, `specs/model_check.md` — model-check subsystem exists; no claim of full generic simulation engine.
- S4 Same ZIP `docs/src/graph-views.md`, `src/graph.rs` — graph capability exists; not evidence of a general graphical design editor.
- W1 Wanna uploaded ZIP `wanna-main.zip` SHA-256 `aeb3cb57f4f79f33b49141263d3d8d24d433d66a631407b282e89e651a1e9569` — `openspec/specs/interaction-primitives/spec.md`: need/contribution/pattern/presentation/authority/evidence separated. Commit **UNKNOWN**: no `.git` metadata.
- W2 Same ZIP `openspec/specs/contribution-primitives/spec.md`: semantic contribution primitives separate from widgets and authority; versioned taxonomy.
- W3 Same ZIP `openspec/specs/interaction-need/spec.md`, `openspec/specs/interaction-patterns/spec.md`: needs and compound processes distinct.
- W4 Same ZIP `openspec/specs/interaction-policy/spec.md`, `openspec/specs/presentation-contract/spec.md`: policy and host presentation separation.
- W5 Same ZIP `README.md`, `openspec/specs/recovery-contract/spec.md`, `openspec/specs/evidence-provenance/spec.md`: spec-first harness, recovery and provenance. README says only two pilot runtime machines and additional composition/review prototypes; do not assume entire catalog implemented.

## External sources

- E1 Andrew Hunt and David Thomas, *The Pragmatic Programmer*, 20th anniversary edition, publisher listing: https://books.pragprog.com/titles/tpp20/the-pragmatic-programmer-20th-anniversary-edition/ — original tracer-bullet provenance; publisher confirms relevant chapter.
- E2 David Thomas/Andrew Hunt, “The Art in Programming,” published article: https://media.pragprog.com/articles/other-published-articles/ArtInProgramming.pdf — tracer-bullet end-to-end thin-system and feedback exposition.
- E3 `charly-vibes/specodelic` repository: https://github.com/charly-vibes/specodelic — target public source location; inspected evidence in this bundle derives from uploaded snapshot, not a verified public commit.
- E4 `charly-vibes/wanna` repository: https://github.com/charly-vibes/wanna — target public source location; inspected evidence in this bundle derives from uploaded snapshot, not a verified public commit.

## PROV-inspired record

- `prov:wasGeneratedBy`: GPT-6 synthesizing current conversation + local source inspection + external lookup on 2026-10-11.
- `prov:used`: uploaded ZIPs S1/W1, source paths above, external E1–E4, user's requirements as expressed in current thread.
- `prov:wasAttributedTo`: OpenAI GPT-6 as documentation author, user as source of design objectives.
- `prov:wasDerivedFrom`: prior discussion: simple graphical substrate; top-down/bottom-up; modularity/OCP; model and implementation tracer bullets; simulation; external conformance.
- `prov:generatedAtTime`: 2026-10-11 (precise completion timestamp in manifest).
- `prov:hadPrimarySourceCommit`: **UNKNOWN** for both ZIP inputs.

## Integrity and epistemic limits

- No CLI run or automated lint/model-check/conform result is asserted here.
- Examples are proposed acceptance tests, not observations of actual implementation behavior.
- No formal assertion of Specodelic spec format compliance is made for REQUIREMENTS.md.
- ZIP archive comments may look like SHAs; these are **not** accepted as authenticated commit identities without source verification.
- The system's correctness and design value remain empirical/hypothetical until explicit evaluation.
