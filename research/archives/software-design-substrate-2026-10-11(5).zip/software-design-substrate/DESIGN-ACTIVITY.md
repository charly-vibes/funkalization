---
title: "Descriptive model of software designing"
created: "2026-10-11"
model: "OpenAI GPT-6"
provenance_format: "PROV-inspired, descriptive (not formal W3C PROV serialization)"
source_specodelic_commit: "UNKNOWN (archive has no .git metadata; ZIP comment is not verified commit provenance)"
source_wanna_commit: "UNKNOWN (archive has no .git metadata; ZIP comment is not verified commit provenance)"
status: "PROPOSAL — not implemented or lint-certified"
---

# The act of designing

## Working definition

Software design is a non-linear activity of constructing, questioning, transforming, comparing and refining candidate system representations and commitments under goals and constraints, with feedback from models, concrete examples, implementations and people. This is a **working hypothesis**, not an empirically established universal theory.

## Directional movements

| Movement | Typical entry | Contribution | Failure mode |
|---|---|---|---|
| Top-down | desired system outcome | decompose goals, define contracts | speculative architecture without evidence |
| Bottom-up | feasible mechanisms or observations | compose implementations, challenge assumptions | accidental architecture |
| Middle-out | critical component/domain boundary | elaborate both ways | local optimization |
| Outside-in | user-visible behavior | derive externally observable contracts | hidden internal requirements |
| Inside-out | internal capabilities | discover possible services | unvalidated value |
| Exploratory | uncertainty or alternatives | provisional hypotheses | untracked choices |
| Evolutionary | existing implementation | change with contract preservation | drift and hidden coupling |

For greenfield work, top-down is often an effective *initial movement*, not an invariant. The system must support bottom-up reconciliation whenever discovered constraints challenge a higher-level decision.

## Cognitive activities and semantic operations

| Activity | Designer's question | Candidate operation / artifact |
|---|---|---|
| Externalize | What am I imagining? | express provisional thing/relationship |
| Interpret | What does this mean? | annotate or type a claim |
| Relate | What depends on what? | establish typed or unresolved link |
| Group | What belongs together? | region and provisional boundary |
| Decompose | What's inside? | child design and refinement obligation |
| Compose | What do these provide together? | composite capability and exposed interface |
| Abstract | What detail can be hidden? | view and abstraction mapping |
| Explore | What might happen? | simulation/scenario |
| Challenge | Where might it fail? | alternative, counterexample, question |
| Constrain | What must hold? | property/architectural policy |
| Propagate | What else is affected? | impact query with uncertainty |
| Reconcile | What needs to change? | explicit conflict and decision record |
| Compare | Which choice is better? | tradeoff/evidence matrix |
| Commit | What is accepted? | approved, versioned claim |
| Refine | How is it realized? | contract-preserving implementation mapping |
| Verify | What evidence supports it? | checker result + scope |
| Revisit | What assumption changed? | change transaction and history |

Wanna precedent: **need** (why human participation is needed) is distinct from **contribution primitive** (what is provided), **interaction pattern** (how contributions combine), and **presentation** (how rendered). Do not equate `drag` with `relate` or `click` with authorization. [W1–W4]

## Descriptive design situations

- D01 Ambiguous structure: express goal → sketch provisional decomposition → compare options → retain unknowns.
- D02 Unfamiliar subsystem: inspect region → choose relevant abstraction → trace observed relationships → record limits of understanding.
- D03 Suspected wrong architecture: identify counterexample → constrain → evaluate impact → revise design.
- D04 Unforeseen implementation limit: discover constraint → propagate up → compare relax/adapter/replace → record disposition.
- D05 Evolving extension point: introduce conforming alternative → check OCP scenario → detect forced core changes.
- D06 No code exists: simulate model slice → test independently curated examples → classify gaps.
- D07 Implementation appears: exercise same scenario end to end → distinguish simulated from real evidence → reconcile drift.
- D08 Cross-level contradiction: detail cannot satisfy parent contract → mark refinement failed; never silently rewrite parent.

## Interaction requirements derived from activity

- Direct manipulation, natural-language inquiry, and formal specification must be coequal ways of interacting.
- The user must freely move across levels and directions, and leave deliberate ambiguity unresolved.
- Operations must be undoable or explicitly irreversible with preview, scope, and appropriate authority.
- Present questions only when they unblock reasoning; do not demand exhaustive type annotation upfront.
- Multiple parallel representations must not imply multiple competing sources of semantic truth.

## Design quality dimensions

Correctness relative to declared properties; understandability; evolvability under named change scenarios; modularity/coupling; observable end-to-end integration; uncertainty visibility; traceability/evidence quality; human cognitive overhead. A single numeric score without assumptions is not an acceptable substitute.
