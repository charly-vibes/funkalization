---
title: "Proposed substrate semantics and architecture"
created: "2026-10-11"
model: "OpenAI GPT-6"
provenance_format: "PROV-inspired, descriptive (not formal W3C PROV serialization)"
source_specodelic_commit: "UNKNOWN (archive has no .git metadata; ZIP comment is not verified commit provenance)"
source_wanna_commit: "UNKNOWN (archive has no .git metadata; ZIP comment is not verified commit provenance)"
status: "PROPOSAL — not implemented or lint-certified"
---

# Semantic architecture

## Separation of responsibilities

```text
UI canvas / text / TUI / agent conversation
             ↕ view projections + validated semantic events
Semantic design store: identities, structures, assertions, alternatives, history
             ↕ explicit adapters, provenance and loss reports
Specodelic source + model check + conform + graph
             ↕ explicit tracer mappings
Model-only simulator | external oracle corpus | executable system evidence
```

Wanna informs host-neutral semantic events, presentation contracts, safety, authority, recovery, and continuity; the above adapter/integration is proposed, not already available [W1–W5]. Specodelic's schema, graph and conform behavior are inspected source facts [S1–S4].

## Minimal neutral semantic objects (proposed)

- `Thing`: identified meaningful entity; optional kind such as capability, component, data, state, goal.
- `Relation`: identified, optionally typed link; endpoints, directionality, assumptions and compatibility.
- `Region`: grouping/boundary with declared semantics distinct from visual clustering.
- `View`: filter, layout and abstraction projection; geometry alone is presentation.
- `Assertion`: typed claim, question, assumption, requirement, law, decision, or constraint; explicit provenance/status.
- `Scenario`: inputs/setup, actions, observations, expected/outcome, origin, evidence type and checker scope.
- `Slice`: narrow goal-connected traversal through selected boundaries, either model-only or implemented.
- `Refinement`: explicit parent-child realization mapping and proof/test obligations.
- `ChangeScenario`: hypothetical revision, expected stable/affected regions, observed delta and assessment.

The above is a candidate vocabulary, not proven minimal. In particular `View` is a projection, not necessarily a first-class domain entity; `Slice`/`ChangeScenario` may later be compound relations.

## Semantic statuses

`sketched` (untyped/incomplete); `proposed` (asserted hypothesis); `specified` (well-formed contract); `evidenced` (has checkable support within scope); `contradicted` (counterexample); `superseded` (replaced but provenance retained). Multiple independent evidence records must coexist; no single boolean "verified" flag may conflate testing, simulation, bounded checking and proof.

## Semantic zoom

A parent capability `P` can be expanded into `A → B → C`, but visibility alone does NOT claim equivalence. The expansion records (a) interface/observable mapping, (b) assumptions, (c) intended relation (composition, refinement, simulation, approximate equivalence, explanation-only), (d) obligations, (e) supported scope. Detail states may map to one abstract state; internal/stuttering transitions can be hidden. Unknown mappings remain UNKNOWN, not silently inferred.

## Bidirectional propagation

Top-down: requirement/constraint on parent yields specific obligations on selected children. Bottom-up: discovered capability/limitation yields a conflict, evidence or proposed parent revision. A dependency graph provides *candidate* blast radius, not necessarily semantic impact. Propagation is never an unreviewed authority to change unrelated commitments.

## Modularity & OCP policy

Allowed dependency directions, public contract visibility, forbidden concrete imports, declared extension points, substitutability scope, and representative extension/change scenarios become optional enforceable architectural policies. `Every box is modular` is invalid as a check. Exact analysis requires complete, typed dependency facts and executable contracts. OCP is evaluated relative to *anticipated extensions and designated stable cores*, not universally proven.

## Behavioral engine boundary

Separate model simulation (one legal trace), state-space/model checking (possible traces within assumptions), oracle conformance (independently observed cases), and implementation tests (real behavior). Preserve `spk conform` verdicts `permitted`, `forbidden`, `underspecified`, `unknown`, `unsupported` and its default open-world interpretation [S2]. A model-generated trace only demonstrates internal consistency, not external correctness.

## Source-to-target translation boundary

Mapping candidate:
- Design `Assertion(intent)` → Specodelic Intent candidate.
- Architectural constraint → Specodelic Constraint candidate, if expressible.
- Typed state/transition submodel → Specodelic Model candidate.
- Executable claim → Specodelic Property candidate, if evaluator supported.
- Scenario corpus → external oracle input for `spk conform` when compatible.
- View coordinates, untyped sketches, alternatives, layout history → separate design metadata.

No adapter has been implemented or lint-tested in this work. On every export/import, report exact mapped, skipped and semantically lossy elements. Specodelic currently defines a fixed five-kind schema (Intent/Constraint/State/Transition/Property) [S1]; do **not** pretend `Region` or `Scenario` is natively a sixth Specodelic kind.

## Security and human authority

Inferred AI suggestions are proposals, not approved system changes. Human authorizations, if needed for protected effects, must be separately recorded. Follow Wanna's separation of verification and authorization, typed events, escape semantics, continuity and evidence [W1–W5].

## Illustrative design data (not Specodelic syntax)

```yaml
schema: design-substrate-proposal/v0
things:
  - {id: order, kind: capability, status: sketched}
  - {id: payment, kind: component, status: proposed}
relations:
  - {id: uses_payment, from: order, to: payment, meaning: invokes, status: proposed}
assertions:
  - {id: payment_optional? , subject: payment, kind: question, status: sketched}
scenarios:
  - id: cancel_before_payment
    origin: independently_authored_example
    setup: {order: created}
    actions: [cancel]
    expected: {order: cancelled}
refinements: []
```
