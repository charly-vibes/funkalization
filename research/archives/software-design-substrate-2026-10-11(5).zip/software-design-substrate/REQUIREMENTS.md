---
title: "Normative design substrate draft requirements"
created: "2026-10-11"
model: "OpenAI GPT-6"
provenance_format: "PROV-inspired, descriptive (not formal W3C PROV serialization)"
source_specodelic_commit: "UNKNOWN (archive has no .git metadata; ZIP comment is not verified commit provenance)"
source_wanna_commit: "UNKNOWN (archive has no .git metadata; ZIP comment is not verified commit provenance)"
status: "PROPOSAL — not implemented or lint-certified"
---

# Normative draft — capability requirements

**Status:** DRAFT, not validated as a native Specodelic/OpenSpec corpus. Use `SHALL` for proposed obligations, with an explicit falsification oracle. IDs are stable within this bundle. Requirements are grouped by capability rather than by UI widget.

| ID | Requirement | Falsifiable acceptance criterion |
|---|---|---|
| DS-001 | The system SHALL accept incomplete, untyped sketches. | An unresolved relation can be saved/reopened without invented type. |
| DS-002 | The system SHALL distinguish geometry-only edits from semantic edits. | Moving a node preserves meaning and semantic version. |
| DS-003 | The system SHALL represent things, relations, regions, assertions, and views with stable identities. | Rename/re-layout preserves references and provenance. |
| DS-004 | The system SHALL support top-down, bottom-up and mixed-direction design movements. | A detailed limitation can challenge an ancestor without mutating it automatically. |
| DS-005 | The system SHALL support explicit abstraction/refinement mappings across levels. | Expansion missing mapping shows an unresolved obligation, not equivalence. |
| DS-006 | The system SHALL support provisional decomposition and reversible restructuring. | Undo split/merge returns semantically equivalent prior state. |
| DS-007 | The system SHALL retain alternatives, assumptions, rejections and decision history. | Choosing B does not delete A's rationale or evidence. |
| DS-008 | The system SHALL distinguish observations from claims and evidence from speculation. | Simulation cannot produce a real-implementation proof badge. |
| DS-009 | The system SHALL represent architectural policies for dependency directions and public boundaries. | Forbidden concrete dependency is surfaced with source edge. |
| DS-010 | The system SHALL represent extension points and scoped Open/Closed obligations. | Adding declared extension reports changes to designated stable core. |
| DS-011 | The system SHALL compute candidate change impact with provenance and limitations. | Missing reference data yields incomplete/UNKNOWN, not 'no impact'. |
| DS-012 | The system SHALL permit model-only end-to-end slices before implementation. | A scenario traverses component model boundaries with no app code. |
| DS-013 | The system SHALL support stepping, replay and branching of model traces. | Same deterministic model and inputs reproduce trace. |
| DS-014 | The system SHALL support property checking against model behavior. | Reachable counterexample includes path, assumptions and bounds. |
| DS-015 | The system SHALL accept independent external examples as separate evidence. | User-supplied trace is stored as external, not model-generated. |
| DS-016 | The system SHALL preserve five-way conformance verdicts where using `spk conform`. | Underspecified case is not mislabeled forbidden in open world. |
| DS-017 | The system SHALL distinguish simulated, bounded, proved and observed evidence. | Results display evidence scope and model/executable revisions. |
| DS-018 | The system SHALL connect design slices to implementation tracer bullets. | One scenario references design obligations and a real test result. |
| DS-019 | The system SHALL surface contract drift between design and observed implementation. | Failing trace names changed assertion and affected boundary. |
| DS-020 | The system SHALL never silently invent or change claims during import/export. | Unsupported semantics produce explicit loss report. |
| DS-021 | The system SHALL keep Specodelic as a separate target/source via versioned adapter. | Failed target validation leaves source design intact. |
| DS-022 | The system SHALL separate human need, contribution, pattern and presentation. | Same semantic operation works in canvas and text view. |
| DS-023 | The system SHALL require explicit authority for protected actions. | An AI suggestion cannot silently modify approved external artifacts. |
| DS-024 | The system SHALL support cancellation, recovery, resume and accessible alternative surfaces. | Interrupted interaction resumes with current context and unresolved decisions. |
| DS-025 | The system SHALL capture end-to-end provenance of decisions and test claims. | Any status can be traced to an artifact, person/tool, revision and run. |
| DS-026 | The system SHALL prioritize smallest meaningful tracer slices. | Initial project can exercise a system-level requirement before all modules exist. |
| DS-027 | The system SHALL distinguish implementation absent, stubbed, simulated, and exercised. | A mocked path cannot be reported as integrated production evidence. |
| DS-028 | The system SHALL allow alternative designs to be compared without merging their semantics. | Scenario comparison retains which model revision each result belongs to. |

## State-transition obligations (abstract, proposed)

- Sketch `empty → tentative` by express; `tentative → structured` by assign semantics; `structured → constrained` by constrain; `constrained → evaluated` by simulate/check; `evaluated → revised` by reconcile; `evaluated → provisionally_committed` by decision/authorization where applicable.
- Every transition MAY return to exploration; failures record uncertainty; no implicit global linear lifecycle.
- `claim.status = supported` only when an explicit evidence record exists, relevant version matches, and scope is displayed; changing the model invalidates or stales relevant evidence, never silently refreshes it.
- `change_scenario` MUST declare base revision and proposed delta before impact assertions may be attributed to it.

## Cross-cutting properties and negative checks

- P-01 **No silent semantic promotion**: layout gesture or AI suggestion alone cannot become a verified system contract.
- P-02 **Traceability conservation**: renaming a design entity does not orphan linked requirements/evidence.
- P-03 **Conformance honesty**: finite external corpus never yields universal behavioral equivalence claim.
- P-04 **Incomplete means incomplete**: missing dependency edges cannot prove modularity.
- P-05 **Refinement explicitness**: selecting an expansion never asserts parent–child equivalence automatically.
- P-06 **Authority separation**: verification does not grant authorization.
- P-07 **Scenario provenance**: generated cases cannot be silently reported as independent oracles.
- P-08 **Cross-surface consistency**: browser/TUI/text yield same semantic event effects, notwithstanding layout.

## Enforcement classification

Static/structural: DS-002, 003, 009 (if graph complete), 020, 022, 025. Executable model/scenario: DS-012–019 subject to chosen semantics/evaluators. Human judgment required: cohesion, quality of abstraction, correctness of scope and architectural tradeoffs. **UNKNOWN**: which of these are directly expressible/executable in current `spk` without extension. See validation plan.
