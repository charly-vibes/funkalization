---
title: "Validation and implementation research plan"
created: "2026-10-11"
model: "OpenAI GPT-6"
provenance_format: "PROV-inspired, descriptive (not formal W3C PROV serialization)"
source_specodelic_commit: "UNKNOWN (archive has no .git metadata; ZIP comment is not verified commit provenance)"
source_wanna_commit: "UNKNOWN (archive has no .git metadata; ZIP comment is not verified commit provenance)"
status: "PROPOSAL — not implemented or lint-certified"
---

# Empirical validation roadmap

## Gate 0: verify baseline tooling and pin versions

Obtain trustworthy repo revisions and binaries, `spk --version`, `spk explain`/`spk conform --help`, and Wanna runtime contracts; record commit SHAs. The uploaded ZIPs are not `.git` checkouts; source commit IDs are **UNKNOWN**. Validate this proposal against the actual CLI and tests before claiming compatibility.

## Gate 1: descriptive research

Observe practitioners performing greenfield decomposition, legacy-system comprehension, middle-out design and change-scenario evaluation; code observed actions with Wanna needs/contributions/patterns. Test whether proposed five primitives actually cover actions without awkward coercions; explicitly capture disagreements. Success: diverse examples can be described without losing important distinctions; no predetermined score threshold.

## Gate 2: smallest semantic core

Build identity-preserving versioned model with thing/relation/assertion/view, uncertainty, reversible transactions; text-first operations before canvas; tests for graph edits vs semantic edits, unresolved types and conflicts. Establish serialization and loss-reporting before Specodelic integration.

## Gate 3: model-only end-to-end slice

Implement minimal compositional state semantics, step/replay/branch, scenario generation, and bounded checking with explicit state-space assumptions. Run E03–E04 and negative counterexample tests. Distinguish simulator correctness from model adequacy.

## Gate 4: Specodelic adapter

Attempt export of one model and its constraints into valid Specodelic Intent/Constraints/Model/Properties; actually run lint/compile/model-check and `spk conform` against an independent JSONL oracle. Record exact commands, exit status, generated files, failing rows and semantic-loss inventory. **No such run has occurred in this dossier.**

## Gate 5: architectural and change-scenario checks

Represent dependency policy, contract substitutability and scoped OCP with formal observable thresholds (e.g. stable core touched? yes/no); adversarial cases include incomplete edges, backdoor imports and contract changes. Evaluate false positive/negative rate.

## Gate 6: vertical implementation tracer

Implement one narrow UI-to-storage feature, capture source/test provenance and real evidence, replay shared scenarios, surface design drift. Mark mocks and stubs clearly. Verify independent examples are not quietly replaced with model-generated ones.

## Gate 7: graphical interaction and Wanna integration

Add canvas projection, semantic zoom, component drilldown, alternatives and scenario trace highlighting; compare with text/TUI paths; check accessibility, recoverability, authorizations, and cost of interaction. Human evaluation: can designers understand changed constraints and evidence better than with diagrams and test reports alone?

## Candidate quality metrics

Time to first falsifiable model slice; time to identify a contradictory requirement; rate of unintentional semantic edits; alternative retention; cross-level traceability completeness; scenario provenance completeness; frequency of unsupported claims; extensions touching designated stable core; user comprehension and recovery after interruption. Metrics are research proposals, NOT measured results.

## Explicit open questions

1. **UNKNOWN** best behavior semantics across synchronous functions, effects, asynchronous protocols, nondeterministic/distributed systems.
2. **UNKNOWN** minimal semantic core and whether proposed primitives are independent.
3. **UNKNOWN** whether native `spk` supports suitable refinement representations or requires extension.
4. **UNKNOWN** lossless mapping from model-only scenario schema into currently supported `spk conform` oracle format for all behaviors.
5. **UNKNOWN** what sound guarantees can be supplied for modularity/OCP without full source/dependency models.
6. **UNKNOWN** how to bound state explosion while maintaining useful exploration.
7. **UNKNOWN** best approach for keeping multi-level abstraction maps coherent after edits.
8. **UNKNOWN** which decisions need user authority versus reversible AI-proposed operations.
9. **UNKNOWN** accessibility and usability across canvas, keyboard, touch and TUI.
10. **UNKNOWN** whether a graphical approach improves design quality versus simpler textual workflows.

## Assumptions

A1. Exploration needs incompleteness as first-class data. A2. The user prefers greenfield top-down as an initial heuristic, not fixed waterfall process. A3. Modularity/OCP are optimization goals under change scenarios, not universal automatically provable facts. A4. Independent examples are possible to gather from users/oracles. A5. Source archives are useful snapshot evidence but do not prove the active upstream head. A6. Design is allowed to revise initial architecture based on observed feasibility.
