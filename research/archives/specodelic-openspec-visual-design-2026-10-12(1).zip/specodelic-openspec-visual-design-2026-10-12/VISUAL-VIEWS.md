---
title: "Minimal architectural visualization requirements"
status: "MIXED: documented existing projections and proposed views"
model: "OpenAI GPT-6"
date: "2026-10-12"
source_commits: "UNKNOWN"
---

# Visual/diagrammatic requirements

The diagram should help a human **reason about the system**, not simply decorate the documentation. Each edge must indicate whether it is accepted/derived, hand-authored/proposed, observed, or unknown.

## The four desired views, with honest availability

| View | Question answered | MVP source and status | Limit |
|---|---|---|---|
| **Contracts/wiring** | Which spec files declare they satisfy whose published contract? | **VERIFIED-SNAPSHOT** `spk graph ... --view wiring --format mermaid`. [S2] | `satisfies` relationships only; not arbitrary `requires` or imports. |
| **Behavior/states** | What lifecycle and transitions does one modeled capability declare? | **VERIFIED-SNAPSHOT** `graph_views.py states` from graph exports. [S2] | Only for declared, parseable state/transition models; not proof of real behavior. |
| **Capability/decomposition** | Which responsibilities and subcomponents form the system? | **PROPOSED** hand-authored design sketch for MVP. | Not currently a native generic hierarchy edge in the inspected typed graph. |
| **Change/impact** | Which declared links, scenarios or interfaces are affected by a change? | **PROPOSED** before/after comparison from graph exports + manual scenario review. | Graph impact is limited to declared references; code/runtime impact unknown without more evidence. |

The inspected Specodelic snapshot documents additional trace and schema-derived views. Those are useful but do not imply a universal software architecture ontology. [S2]

## 1. PROPOSED architecture sketch (illustration ONLY)

```mermaid
flowchart TB
    ORDER["Order Processor"]
    CONTRACT["Storage Contract"]
    SQL["SQLite Adapter"]
    REMOTE["Proposed Remote Adapter"]
    ORDER -->|requires — proposed design relation| CONTRACT
    SQL -.->|claims satisfies| CONTRACT
    REMOTE -.->|claims satisfies — not validated| CONTRACT
```

**Interpretation:** The `requires` edge and component labels are authored as a design proposal, not read from the current native `spk graph` schema. The `claims satisfies` edges are proposed declarations; even if a typed reference is lint-clean, that proves neither interface implementation nor runtime conformance.

## 2. DERIVED accepted wiring (shape only; NOT tool output)

```mermaid
flowchart LR
    CONSUMER["Adapter spec: consumer"] -->|satisfies ref| PRODUCER["Storage spec: published contract"]
```

The direction follows the inspected source documentation: consumer spec → provider contract. The exact node labels, edge multiplicity, and output syntax must come from **running the documented command on a real corpus**. This diagram is explanatory, not a fabricated captured output.

## 3. PROPOSED design change view (illustrative only)

```mermaid
flowchart LR
   BEFORE["Before: SQLite"] --> CONTRACT["Stable Storage Contract"]
   AFTER["After: Remote DB"] --> CONTRACT
   CONTRACT --> VERIFY["Replay same observable scenarios"]
```

The edges here communicate an intention for humans, not that the contract is preserved. Verified or failed status must be attached only after actual checker evidence.

## 4. Diagram generation and freshness

- **Accepted/wiring diagram:** regenerate from accepted source on every relevant spec change (or produce as CI artifact). Do not edit output files by hand.
- **Proposed design sketch:** authored in change folder; visually labeled `PROPOSED`, separate from the accepted view.
- **Behavior diagrams:** only generated from actual declared Model states/transitions; simulations require separate explicit semantics and evidence.
- **Change diff:** initially put before/after captures next to a plain-text change matrix. Do **not** invent an automatic semantic impact result.
- **Text alternative:** all diagrams accompanied by textual description and source references. Do not require an interactive canvas for MVP.

## 5. Requirements for a future interactive surface (DEFERRED)

If text/Mermaid proves insufficient, an interface MAY support selecting nodes and opening their source spec/constraint/scenario, displaying evidence and diffs, and opening an OpenSpec change proposal from a proposed edit. It must NOT make dragging or relabeling a node silently rewrite accepted specifications. This is a future extension, not a claimed feature of Specodelic, OpenSpec, or Wanna.
