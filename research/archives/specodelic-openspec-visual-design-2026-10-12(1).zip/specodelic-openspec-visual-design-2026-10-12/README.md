---
title: "Minimal visual design workflow — OpenSpec + Specodelic"
artifact_id: VDS-2026-10-12
version: "0.1.0-draft"
status: "PROPOSAL — not implemented or CLI-tested"
prov:type: "prov:Entity / design-requirements-bundle"
prov:wasGeneratedBy: "requirements synthesis and source inspection"
prov:wasAttributedTo: "OpenAI GPT-6"
prov:generatedAtTime: "2026-10-12T11:48:56Z"
prov:wasDerivedFrom:
  - "User's requested visual, constraint-driven design workflow (conversation, 2026-10-12)"
  - "Uploaded Specodelic source ZIP (version 0.8.0 declared in Cargo.toml; commit UNKNOWN)"
  - "Uploaded software-design-substrate and categorical-design-substrate ZIP dossiers (2026-10-11)"
  - "OpenSpec upstream CLI and customization documentation (read 2026-10-12; commit UNKNOWN)"
source_specodelic_git_commit: "UNKNOWN"
source_openspec_git_commit: "UNKNOWN"
validation_status: "Document consistency checks only; neither spk nor openspec CLI available in authoring environment"
---

# Minimal visual design workflow using OpenSpec and Specodelic

## TL;DR

Build a **small, visual, constraint-driven software-design workflow** by reusing existing tools rather than creating a new semantic runtime:

- **OpenSpec** owns proposed changes, decisions, implementation tasks, and human-authored requirements/scenarios.
- **Specodelic (`spk`)** expresses structured constraints, typed specification references, applicable behavioral models, and machine-checkable properties.
- **Diagrams are projections** of accepted structured specs where supported. Draft sketches are visibly labeled *proposed*, never confused with derived architecture.
- **Evidence** (tests, simulations, reviews, tracers) is linked to scenarios and revisions; describing a guarantee does not prove it.
- **Git + CI + review** enforce different classes of rule: machine-enforceable constraints in CI; architectural judgments and uncovered cases in review.

The initial milestone is one design-change pilot: **replace a storage adapter while preserving observable behavior**. Do not build a generic categorical kernel, separate graph database, custom design engine, or live diagram editor without demonstrated need.

## Problem and intended outcome

A human or AI designer needs to see the current candidate architecture, understand which constraints govern it, propose a change, detect its consequences, test representative scenarios before/after implementation, and retain a traceable decision. This must support both top-down decomposition and bottom-up corrections, without treating a diagram as proof.

**Success looks like this:** From one repository, another designer can answer (1) what the capabilities are, (2) which published contracts connect them, (3) what behaviors/constraints matter, (4) which scenarios and evidence support them, and (5) what changed—without maintaining multiple contradictory architecture models.

## What is authoritative?

| Information | Authority | Visual/derived representation | What the tool does *not* prove |
|---|---|---|---|
| Accepted capability requirements/scenarios | Deployed OpenSpec capability specifications (`openspec/specs/`) | Scenario and change documentation | Implementation correctness |
| Machine-readable constraints and typed reference relationships | Specodelic's structured layers embedded in **valid dual-format specs**, or standalone Specodelic corpus | `spk graph`, wiring diagram, state views | The truth of a behavioral contract or completeness of architecture |
| Proposed modifications, rationale, alternatives | Active OpenSpec change folder | Clearly labeled **proposal sketch** | Accepted architecture |
| Execution, review, simulations, tests | Actual checker/test output with recorded scope/revision | Evidence links and verdicts | Global proof outside the run's scope |
| Change history | Git, plus OpenSpec archived changes | Git diffs and derived before/after views | Automatic semantic preservation |

**Authority rule:** do not hand-edit a generated diagram as though it were the canonical model. Do not infer runtime `calls`, `requires`, component containment, or source imports merely from Specodelic's `satisfies` edge. [S1][S2]

## The tiny conceptual vocabulary

These are *concepts*, **not a proposal for a new storage schema**:

1. **Capability** — an externally meaningful responsibility with requirements, constraints, optional behavior model and published contract(s).
2. **Scenario** — a concrete input/trigger, context, and expected/forbidden/unresolved observable outcome.
3. **Evidence** — a provenance-bearing result relevant to a scenario or constraint, with method, version and limits.

A **design change** is an OpenSpec proposal plus updated/added specification material, evaluated against relevant scenarios and checks. The workflow is **Propose → Check → Decide → Learn**.

## Cold-read glossary

- **OpenSpec:** change-oriented specification workflow built around proposal, specs, design and tasks artifacts; supports custom workflow schemas.
- **Specodelic / `spk`:** structured Markdown specification format and CLI with Intent / Constraints / Model / Properties layers, typed references, linting and graph projections.
- **Dual-format spec:** a specification written so OpenSpec requirements/scenarios and Specodelic's additional structured layers coexist in a compatible file. Ordinary OpenSpec files are not automatically valid Specodelic files.
- **Capability:** useful responsibility such as `storage` or `payment`; not automatically equivalent to a code module.
- **Contract / extension point:** an explicitly published interface/expectation that another specification may declare it `satisfies`.
- **Scenario:** an example of expected system behavior, including exceptional and unknown cases.
- **Evidence:** observation/check with origin and scope; a passing lint run is structural evidence, not behavioral conformance.
- **Wiring view:** graph of declared cross-file `satisfies` references (consumer → provider's published contract), not a general dependency/import graph.
- **Derived diagram:** deterministically rendered representation computed from a source artifact; if stale, regenerate from the source.
- **Draft sketch:** hand-authored proposed diagram, visually labeled as non-authoritative.
- **Tracer bullet:** narrow end-to-end implementation slice linking design to observed execution.
- **Open/Closed Principle (OCP):** evaluate whether a *specified kind of extension* can be added while keeping a *declared stable core* unchanged; not a universal inferred property.
- **UNKNOWN:** not established from the available source/evidence; neither success nor failure.
- **PROPOSED / VERIFIED-DOC / VERIFIED-SNAPSHOT / UNKNOWN:** evidence labels used in this package; see SOURCES.md.

## Package contents

1. [REQUIREMENTS.md](REQUIREMENTS.md) — normative proposed requirements, scope, acceptance scenarios, enforceability.
2. [WORKFLOW.md](WORKFLOW.md) — file ownership, OpenSpec + Specodelic workflow, CI/checks and small example.
3. [VISUAL-VIEWS.md](VISUAL-VIEWS.md) — diagram contracts, examples, generated vs sketched views and visual interaction boundary.
4. [VALIDATION.md](VALIDATION.md) — pilot, test cases, completion gates, failure cases, non-goals.
5. [SOURCES.md](SOURCES.md) — evidence ledger, concrete source anchors, known limits, assumptions/open questions.
6. [manifest.json](manifest.json) — provenance, input and output checksums, reproducibility status.

## Explicit boundaries

- **In scope (MVP):** template guidance, dual-format source-of-truth discipline, Specodelic typed-reference lint, OpenSpec structural validation, existing wiring/state diagrams, an architecture sketch when needed, manual scenario↔evidence references, pilot CI, human review.
- **Later only if the pilot demands it:** typed ownership/decomposition and arbitrary dependency edges, graph diffs, diagrams editable as first-class actions, scenario↔test automation, dynamic interaction/canvas, richer behavior semantics.
- **Out of scope:** new categorical semantics, new design event algebra, general-purpose obligation engine, proof of arbitrary implementation substitutability, fully automated architecture design.

## Reading the evidence correctly

The Specodelic source ZIP identifies itself as **0.8.0 in `Cargo.toml`**, but the precise Git commit is **UNKNOWN**; the archive lacks verifiable Git commit metadata. OpenSpec claims are based on publicly available documentation read on 2026-10-12, not a pinned binary. No runnable CLI was available here, and **no `spk` or `openspec` command in this package was executed**. See [SOURCES.md](SOURCES.md) and [VALIDATION.md](VALIDATION.md). Existing tool behavior is separate from the requirements we propose to impose.

