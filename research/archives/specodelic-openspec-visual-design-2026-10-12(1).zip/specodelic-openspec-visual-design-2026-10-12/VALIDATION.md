---
title: "Validation and acceptance plan"
status: "PROPOSED; no CLI or behavior testing executed"
model: "OpenAI GPT-6"
date: "2026-10-12"
source_commits: "UNKNOWN"
---

# Validation: one vertical pilot, no framework expansion

## Pilot: replace a storage adapter

**Intent:** An order-processing capability should depend on a stable storage abstraction so two implementations can be compared without silently changing user-observable requirements. The reference design may begin with SQLite and propose a remote database. This is a **hypothetical fixture**, not a claim about an existing project.

**Core observable scenarios (independently written when used):**

| Scenario | Stimulus | Expected or unresolved outcome | Status in this report |
|---|---|---|---|
| S-01 Save/Load | Save order X; load X | Same accepted logical order contents | NOT RUN |
| S-02 Interrupted write | Interrupt save midway | Either atomicity promised by accepted contract or explicit revision/conflict | NOT RUN |
| S-03 Backend replacement | Switch from SQLite to remote adapter | Same specified external behavior for the declared scenario set | NOT RUN |
| S-04 Retry/timeout | Remote request times out | Must state whether retry is idempotent; currently **UNKNOWN** | UNKNOWN |
| S-05 Forbidden dependency | Processor imports concrete remote database class | Reject only if source-level dependency policy and checker are configured | NOT RUN |

## Test gates

**Gate A — Existing formats and single source of truth.** Pin `openspec --version`, `spk --version`, deployed corpus and actual Git commit SHA; construct one valid dual-format OpenSpec+Specodelic capability. Run the exact relevant commands. **Pass:** no ambiguous ownership, no loss of additional layers, lint/validation reports captured. **Fail:** incompatible format or untraceable active file.

**Gate B — Visual correctness.** Generate wiring from accepted specs; edit one declared cross-file `satisfies` link; rerun. **Pass:** only grounded wiring is shown and the regenerated view reflects the change; draft `requires` arrows remain labeled proposal-only. **Fail:** view invents generic dependency edges or claims no impact while reference information is missing.

**Gate C — Design change.** Propose replacing backend without editing accepted specs; review alternatives, scenarios, known impacts and unknowns. **Pass:** accepted/proposed distinction survives and rejected choices remain traceable. **Fail:** silent weakening of atomicity.

**Gate D — Evidence.** Run available scenario tests (and later a narrow implementation tracer). **Pass:** observed test outputs carry exact tool versions, repository revision, relevant scenario ID and bounded scope; untested aspects remain UNKNOWN. **Fail:** lint-green is described as behavioral proof.

**Gate E — Archive.** Use `spk archive-companion <CHANGE_ID> --dry-run`, then a reviewed archive operation. **Pass:** accepted deployed dual-format spec retains structured layers and diagram regeneration succeeds. **Fail:** plain `openspec archive` strips Specodelic structure or a companion refusal is bypassed. [S1]

## Negative tests / potential falsification

- `satisfies` resolves but adapter violates atomic-write scenario → **typed graph succeeds, behavioral validation fails**.
- A source import violates dependency policy without a corresponding Specodelic typed edge → **the graph alone cannot detect it**.
- A draft Mermaid link depicts a new component but accepted specs lack it → **must remain proposed, not deployed**.
- Generated scenario uses the same model as its oracle → **may show consistency, not independent domain adequacy**.
- An OpenSpec archive merges requirements but drops Specodelic structured layers → **integrity failure; do not accept**.
- Missing test for timeout → **UNKNOWN, not PASS**.

## Freeze criteria: no further abstractions unless motivated

All MUST requirements in REQUIREMENTS.md have credible acceptance evidence or are explicitly blocked; the pilot can be explained visually and textually; the source-of-truth boundary is maintained; commands are actually executed on pinned versions with reproducible outputs; all known semantic gaps are listed. Only then decide whether new typed `decomposes`/`requires` relations, an automated graph diff, or a richer visual editor is necessary.

## Current validation status

- Document structure and checksum manifest: checked during bundle assembly.
- Specodelic source files: inspected from uploaded snapshot; `Cargo.toml` declares version 0.8.0; **commit UNKNOWN**.
- OpenSpec workflow/CLI: confirmed from upstream documentation read 2026-10-12; **commit UNKNOWN**.
- `spk` and `openspec` availability in authoring runtime: **not installed / not found on PATH**.
- `openspec validate`, `spk lint`, `spk graph`, and `spk archive-companion`: **NOT EXECUTED**.
- Pilot corpus, wiring output, behavioral scenario checks, implementation tracer: **NOT BUILT / NOT EXECUTED**.

**This is a requirements and validation plan, not a certificate of implementation, conformance, completeness, or formal correctness.**

## Traceability to the original ten design scenarios (S5)

The simplified workflow **does not silently claim full coverage** of the original design-substrate brief. The relationship is explicit:

| Original scenario | Minimal pilot coverage | Remaining gap |
|---|---|---|
| E01 Top-down + bottom-up correction | **Pilot:** accepted requirements and backend limitation challenge | General automated decomposition analysis deferred |
| E02 Semantic zoom/refinement | **Deferred** | No automatic abstraction/refinement check |
| E03 Model-only tracer | **Partial:** scenario definition and explicit `NOT RUN` evidence | Executable model-only stepping deferred until justified |
| E04 Independent examples vs model-generated | **Policy covered:** provenance distinguishes origins | Automated checking of independent examples unimplemented |
| E05 Open/Closed backend extension | **Pilot:** stable storage contract and alternative adapter | Strong general OCP inference intentionally out of scope |
| E06 Layout vs semantic changes | **Policy covered:** hand sketch vs accepted source | Live semantic diagram editor deferred |
| E07 Implementation tracer bullet | **Pilot:** narrow save/load path planned | Real implementation/test run not yet produced |
| E08 Interaction/recovery | **Deferred:** OpenSpec/Git review fallback | Interactive session recovery not in MVP |
| E09 Modularity not inferred from a box | **Pilot:** typed wiring vs unverified architecture claims | Generic measurable coupling analysis deferred |
| E10 Model checking vs scenario conformance | **Policy covered:** distinguish checker and test evidence | Integrated checker-to-conformance pipeline unimplemented |

This table prevents the MVP from being described as a replacement for every original research goal. Extending scope requires a concrete failing pilot or separate user prioritization.
