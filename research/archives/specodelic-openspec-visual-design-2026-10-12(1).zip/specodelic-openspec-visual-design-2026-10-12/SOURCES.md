---
title: "Source ledger, provenance, assumptions and unknowns"
status: "EVIDENCE LEDGER — mixed snapshot/doc sources"
model: "OpenAI GPT-6"
date: "2026-10-12"
source_commits: "UNKNOWN"
---

# Source ledger and integrity notes

## Provenance model

This is **PROV-inspired descriptive provenance**, not a serialized W3C PROV record. The generated files are entities attributed to OpenAI GPT-6; their activity was synthesis of the user's requirements, inspection of locally uploaded archives, and reading specified upstream documentation. Source Git revisions cannot be reconstructed from archive names, download dates or branch labels.

### Inspected primary sources

| ID | Evidence and exact anchor | Status | Supports | Limit |
|---|---|---|---|---|
| **S1** | User-uploaded `specodelic-main(2).zip` (SHA-256 `040d0f3673adf7fd084d40bb0b03473c9d1548530bad293bf4d7862dd2a1ac69`), files `Cargo.toml`, `docs/src/commands.md`, `docs/src/architecture.md` | VERIFIED-SNAPSHOT | `version = "0.8.0"`; `spk lint`, graph, archive companion and dual-format warnings | ZIP commit UNKNOWN; no CLI executed |
| **S2** | Same ZIP, `docs/src/graph-views.md`, `src/graph.rs`, `scripts/graph_views.py`, `specs/graph.md` | VERIFIED-SNAPSHOT | `--view wiring` is `satisfies` projection; derived diagrams, state and trace views | Does not establish generic code dependency or component hierarchy |
| **S3** | [OpenSpec upstream CLI reference](https://github.com/Fission-AI/OpenSpec/blob/main/docs/cli.md), [OpenSpec repository](https://github.com/Fission-AI/OpenSpec) | VERIFIED-DOC | `openspec validate`, OpenSpec change/archive workflow and supported flags | Live `main` docs, read 2026-10-12; commit & installed version UNKNOWN |
| **S4** | [OpenSpec customization documentation](https://github.com/Fission-AI/OpenSpec/blob/main/docs/customization.md), [schema documentation](https://github.com/Fission-AI/OpenSpec/blob/main/docs-lab/customize/schemas.md) | VERIFIED-DOC | Custom schemas, templates, `openspec schema fork`/`validate` | Template instructions guide authors; do not automatically enforce domain rules |
| **S5** | User-uploaded `software-design-substrate-2026-10-11(3).zip` (SHA-256 `54af2c389fb346e6580199b74084365ebef6643473f14b921d92daf3c97a9486`), `REQUIREMENTS.md` and `SCENARIOS.md` | USER-SUPPLIED-BASELINE | Original ten scenarios E01–E10, design goals and tracer discipline | Earlier proposal, not implementation evidence |
| **S6** | User-uploaded `categorical-design-substrate-2026-10-11(1).zip` (SHA-256 `08cbd5752370c17daaa290004df6bdd98d8f11bfe0fea18e884250eab61ecaba`), `README.md`, `ARCHITECTURE-DECISION.md` | USER-SUPPLIED-BASELINE | Context motivating simplification; formal kernel is explicitly deferred in this proposal | Not needed as runtime dependency |

Other stable project locations (not immutable versions): [Specodelic GitHub](https://github.com/charly-vibes/specodelic) and [Specodelic documentation](https://charly-vibes.github.io/specodelic/).

### Tool capability claims vs solution requirements

- **Verified from snapshot/documentation:** typed `satisfies` projection, OpenSpec validation and custom workflow schema machinery, `spk archive-companion` documented behavior.
- **Proposed:** capability/scenario/evidence conventions, evidence-table template, human review policy, version/diagram gate, side-by-side change view, diagram-edit interactions.
- **Not demonstrated:** cross-tool validity for a new example corpus, actual implementation semantics, automatic code-import enforcement, automated scenarios-to-tests correspondence, graph-derived full architecture composition.

## Assumptions

**A1.** The user wants *minimal additional modeling burden*: reuse OpenSpec/Specodelic before introducing new schema kinds or executables.

**A2.** Text and Mermaid are acceptable as the first visualization surface; a live canvas is a possible later improvement, not an MVP prerequisite.

**A3.** At least one compatible dual-format file can be made to parse with selected tool versions, but this **has not been tested in this report**.

**A4.** Git and repository CI are available or can be added to the target project; no specific CI provider is assumed.

**A5.** A pilot project can obtain independently authored behavioral scenarios and, eventually, implementation evidence.

**A6.** Modularity/OCP policies are scoped to particular extension scenarios and declared stable cores; they are not inferred from diagrams alone.

## Open questions (UNKNOWN unless decided or verified)

1. **UNKNOWN** exact compatible OpenSpec + Specodelic release pair and pinned SHAs for target repo.
2. **UNKNOWN** whether OpenSpec custom-schema templates alone provide enough authoring discipline, or a small policy checker is needed.
3. **UNKNOWN** best location/format for persistent evidence links; initial design uses a Markdown table.
4. **UNKNOWN** which architecture relationships beyond `satisfies` (`requires`, `contains`, `calls`) prove necessary in the first pilot.
5. **UNKNOWN** whether manually comparing two derived wiring views is sufficient or a graph-diff tool is justified.
6. **UNKNOWN** which scenarios can be checked without implementation in the chosen project, using the actual deployed spec semantics.
7. **UNKNOWN** code language and repository tool needed to enforce architectural import rules.
8. **UNKNOWN** whether the default OpenSpec archive workflow is safe for every variety of target dual-format delta; use the documented companion and test before deployment.
9. **UNKNOWN** how change proposals should express unresolved conflicts in the project's review process.
10. **UNKNOWN** whether users benefit measurably from an interactive architecture UI over generated Mermaid + source navigation.

## Integrity / cold-read checklist

- [x] TL;DR first in README; package is self-contained and links to files by stable local paths.
- [x] Terms defined; scope and non-goals included; sources cited with source IDs.
- [x] PROV-inspired attribution, ISO 8601 generation time, model, source hashes.
- [x] Git commits not inferred: explicitly **UNKNOWN**.
- [x] Tool capabilities clearly separated from new SHALL requirements.
- [x] Hypothetical examples and unexecuted commands marked as such.
- [x] Assumptions, open questions, negative examples and falsifiable criteria included.
- [ ] New example corpus validated by `openspec` + `spk`: **NOT RUN**.
- [ ] External runtime evidence: **NOT RUN**.
- [ ] User acceptance and independent practitioner evaluation: **NOT RUN**.
