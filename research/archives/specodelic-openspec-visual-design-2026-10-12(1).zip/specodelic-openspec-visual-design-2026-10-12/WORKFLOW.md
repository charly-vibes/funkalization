---
title: "Operational workflow, ownership and enforcement"
status: "PROPOSED workflow; CLI invocations documented, not executed"
model: "OpenAI GPT-6"
date: "2026-10-12"
source_commits: "UNKNOWN"
---

# Workflow: Propose → Check → Decide → Learn

## 1. Suggested repository layout

```text
project/
  AGENTS.md                          # project/agent authoring conventions, not proof
  openspec/
    specs/
      storage/spec.md                # accepted, dual-format when spk is used
      order-processing/spec.md       # accepted capability
    changes/
      replace-storage/
        proposal.md                  # WHY and scope
        design.md                    # alternatives, draft Mermaid, assumptions
        tasks.md                     # concrete implementation work
        specs/
          storage/spec.md            # compatible delta/spec material
  tests/                              # actual scenario/tracer tests, as available
  docs/architecture/                 # generated render outputs, optional
```

This is a *suggested* layout. The exact placement of OpenSpec change artifacts is controlled by the versioned schema; a custom schema may differ. `AGENTS.md` and diagrams do not automatically become enforceable checks.

## 2. Ownership and discipline

- **OpenSpec accepted requirements:** business-visible SHALL statements and scenarios.
- **Specodelic structured layers:** mechanical constraints, typed `satisfies` wiring, declared lifecycle/state properties.
- **Proposal `design.md`:** alternatives, rationale, migration plans, provisional relationships, affected scenarios, open questions, hand-authored **draft** Mermaid sketch.
- **Tests/CI artifacts:** evidence from actual runs; each refers to an applicable requirement/scenario and revision where feasible.
- **Derived views:** generated (and reproducible) from structured specs; never authoritative edited source.
- **Git:** diffs and change lineage. Do not invent a second event store.

The simplest compatible representation is **one dual-format specification file per capability** when it passes both tools' format rules. Do not assume arbitrary vanilla OpenSpec requirement Markdown is valid `spk` input. The exact coexistence constraints must be checked using the installed versions. [S1][S3]

## 3. Concrete workflow

1. **Propose:** create an OpenSpec change `replace-storage` with motivation, alternatives, affected capabilities and scenarios. Leave existing accepted specs intact.
2. **Describe:** express the intended public storage contract in the relevant accepted/proposed capability spec. Declare an adapter's **claimed** `satisfies` reference if it meets the Specodelic format; do not assert behavioral proof.
3. **Visualize:** sketch an intended architecture (clearly **PROPOSED**) in `design.md`; render current accepted wiring from `spk graph` (clearly **DERIVED**).
4. **Check:** run OpenSpec format validation, Specodelic lint/typing, inspect changes to wiring, then execute independent relevant scenario checks where they exist. Put `UNKNOWN` on unchecked claims.
5. **Decide:** review diff, scenarios, regressions, unknowns and architectural policy. Accept, reject, or revise the change. Neither a clean graph nor a green lint automatically approves it.
6. **Learn:** for compatible dual-format archival, use Specodelic's archive companion rather than assuming the normal OpenSpec archiver preserves extra layers; capture outputs, revision and exceptions.

## 4. Example command plan (NOT executed in this report)

```bash
# Run inside the project with the actual tools installed and versions recorded.
openspec validate --all --strict
spk lint openspec

# Accepted wiring: file-level projection of declared satisfies references.
spk graph openspec/specs --view wiring --format mermaid \
  > docs/architecture/accepted-wiring.mmd

# Inspect the graph and typing information when needed.
spk graph openspec/specs --format edges \
  > docs/architecture/accepted-edges.tsv

# For dual-format changes only: preview, review, then archive with companion.
spk archive-companion replace-storage --dry-run
# spk archive-companion replace-storage   # only after explicit approval
```

The lines above are **documented invocation candidates** from the inspected Specodelic v0.8.0 source and upstream OpenSpec docs. They have **not** been executed here; no version compatibility or sample lint-clean corpus is asserted. Ensure output directories exist before redirection. [S1][S2][S3]

If the repository deploys extra source-format layers through its custom schema, verify `spk archive-companion` accepts that precise layout. Do not bypass an archive refusal.

## 5. Enforcement policy: what's automatic and what's not?

| Example policy | Source representation | Actual enforcement level |
|---|---|---|
| Well-formed OpenSpec requirements/deltas | OpenSpec specs | CLI structural check [S3] |
| Specodelic typed `satisfies` references | Dual-format Specodelic constraints | CLI typed-reference lint [S1][S2] |
| Backend actually honors atomic writes | Contract claim + behavioral scenario | **NOT** established by `satisfies`; requires test/model proof/observation |
| Processor does not import `SQLiteAdapter` | Repo source/import graph | **NOT** established by `spk graph`; requires language-specific checker |
| Stable core unchanged for backend extension | Designated file set + git diff + scenario | Checkable only after explicitly naming core and extension scenario |
| No unchecked design decision | Change template + reviewer | Human convention unless separate policy checker written |
| A diagram represents accepted state | Generated from accepted corpus | Reproducible through generator; freshness check needs CI if required |

## 6. Practical agent guidance for `AGENTS.md` (proposal, not installed)

```markdown
# Design changes
- First locate accepted OpenSpec capabilities and scenarios.
- Create or update a change proposal rather than silently editing approved behavior.
- Keep Specodelic relationships limited to their documented typed meaning.
- Identify affected scenarios and mark untested behaviors UNKNOWN/NOT RUN.
- Generate accepted wiring diagrams from the accepted spec corpus.
- Label hand-authored sketches PROPOSED; never present as derived proof.
- A passing lint/graph check is not proof of behavioral correctness.
- When archiving dual-format changes, use the verified companion workflow.
- Do not invent tests, command outputs, checker behavior or commit IDs.
```

**Hardening later:** If the pilot shows missed rules, add a small CI policy check targeted at that rule—not a generalized design engine.
