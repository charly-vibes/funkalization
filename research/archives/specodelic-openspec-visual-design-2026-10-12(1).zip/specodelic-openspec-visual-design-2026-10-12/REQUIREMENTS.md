---
title: "Normative draft requirements — minimal visual design workflow"
status: "PROPOSED; acceptance scenarios unexecuted"
model: "OpenAI GPT-6"
date: "2026-10-12"
provenance: "See README.md and SOURCES.md; source commits UNKNOWN"
---

# Requirements

**Interpretation:** `SHALL` describes the **proposed solution**, not a present feature of Specodelic/OpenSpec. Each criterion is falsifiable. "Enforceable now" means a documented mechanism exists *in principle*, **not that this repository has configured or tested it**.

## A. Source of truth and change discipline

| ID | Priority | Proposed requirement (SHALL) | Acceptance scenario / falsification criterion | Enforcement candidate |
|---|---|---|---|---|
| VD-01 | MUST | Keep an authoritative accepted capability/requirements corpus separate from pending design proposals. | Given a proposed backend replacement, before approval, accepted specs remain unchanged; after approved archive, accepted specs reflect the approved change. | OpenSpec change/spec workflow and review; CI on accepted corpus. [S3] |
| VD-02 | MUST | Express accepted structured constraints and cross-file contract relations in one compatible Specodelic corpus rather than duplicate architectural truth in diagrams. | Renaming/deleting a published contract causes typed-reference lint or a surfaced unresolved relation; a manually altered diagram cannot change the constraint. | `spk lint`; `spk graph`. [S1][S2] |
| VD-03 | MUST | Distinguish a guarantee **claim** from evidence that it holds. | Given an untested `atomic_save` claim, UI/report displays `UNVERIFIED`, not `PASS`; lint success does not upgrade it. | Evidence convention and human review (NOT built-in behavioral proof). |
| VD-04 | MUST | Record alternatives, assumptions, rationale, and unresolved questions for architectural changes. | A rejected remote adapter remains traceable with why it was rejected, and an unresolved timeout remains `UNKNOWN`. | OpenSpec `design.md` template + review. [S4] |
| VD-05 | MUST | Never silently weaken approved constraints as a side effect of a bottom-up discovery. | A backend unable to provide atomic writes produces an explicit proposed revision or open conflict; the accepted requirement is not silently edited. | Diff review + policy + scenario checks. |

## B. Enforcement and correctness boundaries

| ID | Priority | Proposed requirement (SHALL) | Acceptance scenario / falsification criterion | Enforcement candidate |
|---|---|---|---|---|
| VD-06 | MUST | Run OpenSpec structural validation and Specodelic typed/format lint for relevant changes and accepted specs. | Invalid OpenSpec change or dangling/wrongly typed Specodelic reference fails the corresponding configured gate. | `openspec validate --all --strict` and `spk lint openspec`; ensure dual-format inputs. [S1][S3] |
| VD-07 | MUST | Interpret `satisfies` only as a **declared contract reference** and avoid inferring behavioral conformance or source-code dependency constraints from it. | A consumer with a `satisfies` edge but failing behavioral test is reported as structurally wired and behaviorally failed—not certified compatible. | Separation of structural gate and tests. [S1][S2] |
| VD-08 | MUST | Attach each substantial change to at least one positive, one negative/exceptional, and one unresolved-or-boundary scenario where applicable. | Storage replacement considers successful save/load, interrupted write, and unverified retry; missing scenario is visible rather than implicitly passed. | OpenSpec scenario-writing convention + review; optional future automation. |
| VD-09 | MUST | Record evidence with source, method, checked claim/scenario, design revision, scope, and outcome including `UNKNOWN`/`NOT RUN`. | A passing unit test for mock storage cannot be presented as proof of production database atomicity. | Evidence table / test artifacts; not a built-in OpenSpec or Specodelic feature. |
| VD-10 | SHOULD | Enforce code-level dependency-direction constraints only with evidence from a suitable language-aware checker, where the rule is materially important. | A forbidden concrete import is found by an actual source checker, not reported absent because wiring graph lacks that edge. | External language-specific dependency tool; implementation UNKNOWN. |

## C. Diagrams and interaction

| ID | Priority | Proposed requirement (SHALL) | Acceptance scenario / falsification criterion | Enforcement candidate |
|---|---|---|---|---|
| VD-11 | MUST | Provide an **accepted wiring view** derived from structured `satisfies` references; do not hand-author it as canonical. | Change a cross-file `satisfies` reference and regenerate: diagram changes correspondingly; absent edges show no wiring rather than an invented dependency. | `spk graph <corpus> --view wiring --format mermaid`. [S2] |
| VD-12 | MUST | Support an **explicitly labeled proposal sketch** for relationships not representable by the current typed graph. | A proposed `OrderProcessor requires Storage` arrow cannot be mistaken for a verified native Specodelic graph edge. | Mermaid inside change `design.md`; review. |
| VD-13 | SHOULD | Expose relevant per-file state machines and traceability from Specodelic's existing graph projections, where structured models exist. | Given declared states/transitions, rendered state view matches the extracted graph; no states means no behavioral diagram is asserted. | `spk graph` exports + bundled `graph_views.py`; script prerequisites apply. [S2] |
| VD-14 | SHOULD | Explain change impact as **known affected references + explicit incompleteness** rather than guaranteed full runtime impact. | Removing a contract shows consumers reachable through known refs; an unknown runtime call relationship remains `UNKNOWN`, not `unaffected`. | Graph edges + review; automated before/after diff proposed, not present. |
| VD-15 | SHOULD | Keep diagrams useful without a visual editor: text/Mermaid is sufficient for MVP, and diagram layout does not modify specification semantics. | Editing node placement in a proposal sketch does not mutate a contract, and viewing can occur through Markdown/code review. | Documentation convention; interactive editor deferred. |

## D. Integration, change acceptance and lifecycle

| ID | Priority | Proposed requirement (SHALL) | Acceptance scenario / falsification criterion | Enforcement candidate |
|---|---|---|---|---|
| VD-16 | MUST | Preserve compatible Specodelic layers when archiving dual-format OpenSpec changes; fail closed if preservation is uncertain. | Before archiving, preview with companion; deployed spec retains frontmatter/Constraints/Model/Properties, or archive is not accepted. | `spk archive-companion <CHANGE_ID> --dry-run`, then approved companion archive. [S1] |
| VD-17 | MUST | Link design scenarios to at least one reproducible model check, implementation tracer, or explicit `NOT RUN/UNKNOWN` entry; distinguish each evidence kind. | A model-only payment trace is not labeled as implementation evidence; a small real tracer has test command, code revision and environment. | Manual evidence table initially; future tooling optional. |
| VD-18 | MUST | Demonstrate a complete storage-backend replacement in one pilot before adding schema features or a bespoke design runtime. | Pilot has OpenSpec proposal, accepted dual-format specs, wiring view, scenario matrix, actual command logs, test evidence and archive preservation. | Validation gate described in VALIDATION.md. |

### Minimum mandatory controls (not all machine-enforceable)

- **Hard CI gates, once configured and verified:** OpenSpec structure; Specodelic format/references; existing tests applicable to touched scenarios.
- **Human policy gates:** no silent weakening, review unknowns, trace design rationale, distinguish draft from derived diagrams, evaluate evidence scope.
- **Optional code-analysis gate:** only if the language/repository provides a dependency checker whose inputs and interpretation can be verified.

### Requirement-to-evidence mapping

The pilot MUST maintain a small table (in its change `design.md` or linked Markdown artifact):

| Requirement/scenario ID | Check/evidence artifact | Observed outcome | Revision | Limit |
|---|---|---|---|---|
| `storage-save-success` | `NOT RUN` | `UNKNOWN` | `UNKNOWN` | No implementation evidence yet |
| `storage-interrupted-write` | `NOT RUN` | `UNKNOWN` | `UNKNOWN` | Atomicity not established |
| `storage-retry-timeout` | `NOT RUN` | `UNKNOWN` | `UNKNOWN` | Semantics undecided |

**Do not add a separate evidence database unless this simple table proves inadequate.**
